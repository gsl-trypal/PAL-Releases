"use strict";
(() => {
  // src/lib/frames.ts
  var HOST_NAME = true ? "com.pal.desktop.bridge" : "com.pal.desktop.bridge";
  var MAX_FRAME_BYTES = 1024 * 1024;
  var BridgeError = class extends Error {
    kind;
    reason;
    constructor(kind, message, reason) {
      super(message);
      this.name = "BridgeError";
      this.kind = kind;
      if (reason) this.reason = reason;
    }
  };
  function hello(browser, extensionVersion, incognitoAllowed) {
    return { type: "hello", browser, extensionVersion, incognitoAllowed };
  }
  function parseRequest(raw) {
    if (!raw || typeof raw !== "object") return null;
    const r = raw;
    if (r.type !== "request") return null;
    if (typeof r.id !== "number" || !Number.isInteger(r.id)) return null;
    if (typeof r.op !== "string" || !r.op) return null;
    const args = r.args && typeof r.args === "object" && !Array.isArray(r.args) ? r.args : {};
    return { type: "request", id: r.id, op: r.op, args };
  }
  function okResponse(id, data = {}) {
    return { type: "response", id, ok: true, data };
  }
  function errorResponse(id, err) {
    if (err instanceof BridgeError) {
      const error = { kind: err.kind, message: err.message };
      if (err.reason) error.reason = err.reason;
      return { type: "response", id, ok: false, error };
    }
    const message = err instanceof Error ? err.message : String(err);
    return { type: "response", id, ok: false, error: { kind: "app_error", message: message || "Something went wrong." } };
  }
  function event(name, data) {
    return { type: "event", name, data };
  }
  var encoder = new TextEncoder();
  var decoder = new TextDecoder("utf-8", { fatal: true });
  function utf8Length(s) {
    return encoder.encode(s).length;
  }
  function frameBytes(frame) {
    return utf8Length(JSON.stringify(frame));
  }
  function capUtf8(s, maxBytes) {
    if (maxBytes <= 0) return "";
    if (utf8Length(s) <= maxBytes) return s;
    let lo = Math.floor(maxBytes / 3);
    let hi = Math.min(s.length, maxBytes);
    while (lo < hi) {
      const mid = Math.ceil((lo + hi) / 2);
      if (utf8Length(s.slice(0, mid)) <= maxBytes) lo = mid;
      else hi = mid - 1;
    }
    let cut = s.slice(0, lo);
    const last = cut.charCodeAt(cut.length - 1);
    if (last >= 55296 && last <= 56319) cut = cut.slice(0, -1);
    return cut;
  }
  function fitText(frame, key, slack = 1024) {
    const data = frame.data;
    if (!data || typeof data[key] !== "string") return false;
    const total = frameBytes(frame);
    if (total + 4 <= MAX_FRAME_BYTES - slack) return false;
    const text = data[key];
    data[key] = "";
    const rest = frameBytes(frame);
    const budget = MAX_FRAME_BYTES - slack - rest - 4;
    let cut = capUtf8(text, budget);
    data[key] = cut;
    while (frameBytes(frame) + 4 > MAX_FRAME_BYTES - slack && cut.length > 0) {
      cut = cut.slice(0, Math.floor(cut.length * 0.9));
      data[key] = cut;
    }
    return true;
  }

  // src/lib/bridge.ts
  function backoffDelay(attempt) {
    return Math.min(6e4, 1e3 * 2 ** Math.max(0, Math.min(attempt, 6)));
  }
  var STEADY_MS = 3e3;
  var QUEUE_MAX = 5;
  var QUEUE_KEEP_MS = 6e4;
  var Bridge = class {
    state = "idle";
    attempts = 0;
    port = null;
    /** The hello went out on this port: events may follow it. */
    ready = false;
    retry = null;
    steady = null;
    queue = [];
    generation = 0;
    opts;
    constructor(opts) {
      this.opts = opts;
    }
    /** Connect now unless connected, connecting or waiting to retry. */
    start() {
      if (this.port || this.retry) return;
      void this.open();
    }
    /** Connect now even if a retry is waiting (a wake, a person's click). */
    ensure() {
      if (this.port) return;
      if (this.retry) {
        this.opts.clearTimer(this.retry);
        this.retry = null;
      }
      void this.open();
    }
    /** Send an event; kept for a minute when the port is down. */
    sendEvent(frame) {
      if (this.port && this.ready) {
        this.post(frame);
        return true;
      }
      const now = this.now();
      this.queue = this.queue.filter((q) => now - q.at < QUEUE_KEEP_MS);
      if (frame.name === "tab.active") this.queue = this.queue.filter((q) => q.frame.name !== "tab.active");
      this.queue.push({ frame, at: now });
      while (this.queue.length > QUEUE_MAX) this.queue.shift();
      this.ensure();
      return false;
    }
    now() {
      return this.opts.now ? this.opts.now() : Date.now();
    }
    log(message) {
      this.opts.log?.(message);
    }
    post(frame) {
      try {
        this.port?.postMessage(frame);
      } catch (err) {
        this.log(`post failed: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
    async open() {
      const generation = ++this.generation;
      this.state = "connecting";
      let port;
      try {
        port = this.opts.connect();
      } catch (err) {
        this.log(`connect failed: ${err instanceof Error ? err.message : String(err)}`);
        this.dropped(generation);
        return;
      }
      this.port = port;
      port.onMessage.addListener((message) => {
        if (generation !== this.generation) return;
        this.markSteady();
        void this.onMessage(message);
      });
      port.onDisconnect.addListener(() => {
        if (generation !== this.generation) return;
        const why = this.opts.lastError?.();
        this.log(`port closed${why ? `: ${why}` : ""}`);
        this.dropped(generation);
      });
      let hello2;
      try {
        hello2 = await this.opts.hello();
      } catch (err) {
        this.log(`hello failed: ${err instanceof Error ? err.message : String(err)}`);
        return;
      }
      if (generation !== this.generation || !this.port) return;
      this.post(hello2);
      this.ready = true;
      const now = this.now();
      const queued = this.queue.filter((q) => now - q.at < QUEUE_KEEP_MS);
      this.queue = [];
      for (const q of queued) this.post(q.frame);
      this.steady = this.opts.setTimer(() => this.markSteady(), STEADY_MS);
    }
    markSteady() {
      if (!this.port) return;
      if (this.state !== "connected") this.log("connected");
      this.state = "connected";
      this.attempts = 0;
      if (this.steady) {
        this.opts.clearTimer(this.steady);
        this.steady = null;
      }
    }
    dropped(generation) {
      if (generation !== this.generation) return;
      this.generation++;
      try {
        this.port?.disconnect();
      } catch {
      }
      this.port = null;
      this.ready = false;
      this.state = "idle";
      if (this.steady) {
        this.opts.clearTimer(this.steady);
        this.steady = null;
      }
      const delay = backoffDelay(this.attempts);
      this.attempts += 1;
      if (this.retry) this.opts.clearTimer(this.retry);
      this.retry = this.opts.setTimer(() => {
        this.retry = null;
        void this.open();
      }, delay);
    }
    async onMessage(message) {
      const request = parseRequest(message);
      if (!request) {
        const id = message?.id;
        if (typeof id === "number") this.post(errorResponse(id, new BridgeError("invalid", "That is not a request.")));
        return;
      }
      try {
        const data = await this.opts.handle(request.op, request.args);
        this.post(okResponse(request.id, data));
      } catch (err) {
        this.post(errorResponse(request.id, err));
      }
    }
    /** Close the port for good (tests; the extension being turned off). */
    stop() {
      this.generation++;
      if (this.retry) this.opts.clearTimer(this.retry);
      if (this.steady) this.opts.clearTimer(this.steady);
      this.retry = null;
      this.steady = null;
      try {
        this.port?.disconnect();
      } catch {
      }
      this.port = null;
      this.ready = false;
      this.state = "idle";
    }
  };

  // src/lib/browser.ts
  function detectBrowser(info, target) {
    if (target === "safari") return "safari";
    const brands = (info.brands ?? []).map((b) => b.brand.toLowerCase());
    const ua = info.userAgent;
    if (info.brave || brands.includes("brave")) return "brave";
    if (brands.includes("microsoft edge") || /\bEdg\//.test(ua)) return "edge";
    if (/\bVivaldi\//.test(ua) || brands.includes("vivaldi")) return "vivaldi";
    if (/\bArc\//.test(ua) || brands.includes("arc")) return "arc";
    if (brands.includes("google chrome")) return "chrome";
    if (brands.includes("chromium")) return "chromium";
    return "chrome";
  }

  // src/lib/config.ts
  var SAFARI_APP_ID = "com.trypal.ai";
  var SAFARI_POLL_SECONDS = 20;
  var BADGE_LINGER_MS = 2e3;
  var SENT_MAX_CHARS = 4e5;

  // src/lib/rules.ts
  var ALLOWED_SCHEMES = /* @__PURE__ */ new Set(["http:", "https:", "file:"]);
  var WEB_STORES = [
    { host: "chromewebstore.google.com" },
    { host: "chrome.google.com", path: "/webstore" },
    { host: "microsoftedge.microsoft.com", path: "/addons" },
    { host: "addons.opera.com" },
    { host: "addons.mozilla.org" }
  ];
  function pageRefusal(url) {
    if (!url) return "PAL can't see this tab's address, so it doesn't read it.";
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return "PAL can't read a page at that address.";
    }
    if (!ALLOWED_SCHEMES.has(parsed.protocol)) {
      return `PAL doesn't read or use the browser's own pages (${parsed.protocol}//\u2026).`;
    }
    const host = parsed.hostname.toLowerCase();
    for (const store of WEB_STORES) {
      if (host === store.host && (!store.path || parsed.pathname.startsWith(store.path))) {
        return "PAL doesn't read or use the browser's extension store.";
      }
    }
    return null;
  }
  function checkTab(tab) {
    if (tab.incognito) {
      throw new BridgeError("refused", "That is a private (incognito) tab. PAL never reads or uses it.", "incognito");
    }
    const why = pageRefusal(tab.url);
    if (why) throw new BridgeError("refused", why, "page");
  }

  // src/lib/ops.ts
  var READ_MAX_CHARS = 25e4;
  var SELECTION_MAX_CHARS = 2e4;
  var SNAPSHOT_MAX_CHARS = 6e4;
  function tabSummary(tab) {
    return {
      tabId: tab.id ?? -1,
      windowId: tab.windowId,
      active: tab.active,
      url: tab.incognito ? "" : tab.url ?? "",
      title: tab.incognito ? "" : tab.title ?? "",
      incognito: tab.incognito
    };
  }
  function intArg(args, key) {
    const v = args[key];
    return typeof v === "number" && Number.isFinite(v) ? Math.trunc(v) : void 0;
  }
  function pageError(result) {
    const err = result?.__error;
    if (!err) return null;
    const kind = err.kind ?? "app_error";
    return new BridgeError(kind, err.message ?? "The page said no.", err.reason);
  }
  function navigatedAway(err) {
    const msg = err instanceof Error ? err.message : String(err);
    return /frame with id \d+ was removed|frame was removed|page has been closed|navigat/i.test(msg);
  }
  function makeOps(api2) {
    const acting = /* @__PURE__ */ new Set();
    async function resolveTab(args) {
      const tabId = intArg(args, "tabId");
      const tab = tabId !== void 0 ? await api2.getTab(tabId) : await api2.activeTab();
      if (!tab || tab.id === void 0) {
        throw new BridgeError("not_found", tabId !== void 0 ? `There is no tab ${tabId} any more.` : "No tab is open.");
      }
      checkTab(tab);
      return tab;
    }
    async function call(tab, what, args, inject) {
      let result;
      try {
        result = await api2.inPage(tab.id, what, args, inject);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        if (/cannot access|cannot be scripted|extensions gallery|permission/i.test(msg)) {
          throw new BridgeError("refused", "The browser doesn't let extensions read this page.", "page");
        }
        if (/no tab with id/i.test(msg)) throw new BridgeError("not_found", "That tab has closed.");
        throw err;
      }
      const failed = pageError(result);
      if (failed) throw failed;
      if (!result || typeof result !== "object") throw new BridgeError("app_error", "The page gave no answer.");
      return result;
    }
    return async function handle2(op, args) {
      switch (op) {
        case "tabs.list": {
          const [tabs, focused] = await Promise.all([api2.allTabs(), api2.focusedWindowId()]);
          const first = tabs.filter((t) => t.active && t.windowId === focused);
          const rest = tabs.filter((t) => !first.includes(t));
          return { tabs: [...first, ...rest].map(tabSummary) };
        }
        case "tabs.activate": {
          const tabId = intArg(args, "tabId");
          if (tabId === void 0) throw new BridgeError("invalid", "tabs.activate needs a tabId.");
          const tab = await api2.getTab(tabId);
          if (!tab) throw new BridgeError("not_found", `There is no tab ${tabId} any more.`);
          if (tab.incognito) {
            throw new BridgeError("refused", "That is a private (incognito) tab. PAL never reads or uses it.", "incognito");
          }
          await api2.activate(tab);
          return {};
        }
        case "page.read": {
          const tab = await resolveTab(args);
          const maxChars = Math.max(1, Math.min(READ_MAX_CHARS, intArg(args, "maxChars") ?? 12e3));
          const page = await call(tab, "read", {}, true);
          const full = String(page.markdown ?? "");
          const selection = String(page.selection ?? "").slice(0, SELECTION_MAX_CHARS);
          const data = {
            url: String(page.url ?? tab.url ?? ""),
            title: String(page.title ?? tab.title ?? ""),
            text: full.length > maxChars ? full.slice(0, maxChars) : full,
            selection,
            words: Number(page.words ?? 0),
            chars: full.length,
            truncated: full.length > maxChars,
            tabId: tab.id,
            windowId: tab.windowId
          };
          if (fitText({ data }, "text")) data.truncated = true;
          return data;
        }
        case "page.snapshot": {
          const tab = await resolveTab(args);
          const maxNodes = Math.max(20, Math.min(2e3, intArg(args, "maxNodes") ?? 400));
          const snap = await call(tab, "snapshot", { maxNodes, maxChars: SNAPSHOT_MAX_CHARS }, true);
          return {
            url: String(snap.url ?? tab.url ?? ""),
            title: String(snap.title ?? tab.title ?? ""),
            text: String(snap.text ?? ""),
            refs: Number(snap.refs ?? 0),
            truncated: snap.truncated === true,
            tabId: tab.id,
            windowId: tab.windowId
          };
        }
        case "page.act": {
          const tab = await resolveTab(args);
          if (acting.has(tab.id)) throw new BridgeError("busy", "PAL is already doing something on that page.");
          acting.add(tab.id);
          try {
            const step = {};
            for (const key of ["ref", "action", "text", "option", "key", "direction", "amount"]) {
              if (args[key] !== void 0 && args[key] !== null) step[key] = args[key];
            }
            if (typeof step.text === "string") step.text = capUtf8(step.text, 64e3);
            try {
              const out = await call(tab, "act", step, false);
              return { effect: String(out.effect ?? "unverifiable"), detail: String(out.detail ?? "") };
            } catch (err) {
              if (navigatedAway(err)) {
                return { effect: "confirmed", detail: "The page went to a new address." };
              }
              throw err;
            }
          } finally {
            acting.delete(tab.id);
          }
        }
        default:
          throw new BridgeError("invalid", `The extension doesn't know "${op}".`);
      }
    };
  }

  // src/lib/safari-port.ts
  var SafariPort = class {
    session;
    send;
    wait;
    outbox = [];
    messageListeners = [];
    disconnectListeners = [];
    closed = false;
    polling = false;
    flushing = false;
    constructor(send, wait, session) {
      this.send = send;
      this.wait = wait;
      this.session = session ?? Math.random().toString(36).slice(2, 12);
      queueMicrotask(() => void this.poll());
    }
    onMessage = { addListener: (listener) => {
      this.messageListeners.push(listener);
    } };
    onDisconnect = { addListener: (listener) => {
      this.disconnectListeners.push(listener);
    } };
    postMessage(message) {
      if (this.closed) throw new Error("The Safari port is closed.");
      this.outbox.push(message);
      void this.flush();
    }
    disconnect() {
      this.closed = true;
    }
    deliver(reply) {
      if (reply.error) throw new Error(reply.error);
      for (const frame of reply.frames ?? []) {
        for (const listener of this.messageListeners) listener(frame);
      }
    }
    fail() {
      if (this.closed) return;
      this.closed = true;
      for (const listener of this.disconnectListeners) listener();
    }
    async flush() {
      if (this.flushing || this.closed) return;
      this.flushing = true;
      try {
        while (this.outbox.length && !this.closed) {
          const frames = this.outbox.splice(0);
          const reply = await this.send({ session: this.session, frames, wait: 0 });
          this.deliver(reply ?? {});
        }
      } catch {
        this.fail();
      } finally {
        this.flushing = false;
      }
    }
    async poll() {
      if (this.polling) return;
      this.polling = true;
      try {
        while (!this.closed) {
          const reply = await this.send({ session: this.session, frames: [], wait: this.wait });
          if (this.closed) break;
          this.deliver(reply ?? {});
        }
      } catch {
        this.fail();
      } finally {
        this.polling = false;
      }
    }
  };

  // src/background/service-worker.ts
  var TARGET = "chromium";
  var CONTEXT_MENU_ID = "pal-send-to-pal";
  var KEEPALIVE_ALARM = "pal-bridge-keepalive";
  function log(message) {
    console.info(`[PAL bridge] ${message}`);
  }
  function toTab(t) {
    return { id: t.id, windowId: t.windowId, active: t.active, url: t.url, title: t.title, incognito: t.incognito };
  }
  function runInPage(call, args) {
    const w = window;
    if (call === "read") {
      return w.__palExtract ? w.__palExtract() : { __error: { kind: "app_error", message: "The page reader didn't load." } };
    }
    if (!w.__palPage) {
      return call === "act" ? { __error: { kind: "changed", message: "The page changed since the snapshot (it loaded again). Take a new snapshot." } } : { __error: { kind: "app_error", message: "The page agent didn't load." } };
    }
    return call === "snapshot" ? w.__palPage.snapshot(args) : w.__palPage.act(args);
  }
  var api = {
    async allTabs() {
      return (await chrome.tabs.query({})).map(toTab);
    },
    async activeTab() {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      return tab ? toTab(tab) : null;
    },
    async focusedWindowId() {
      try {
        return (await chrome.windows.getLastFocused()).id ?? null;
      } catch {
        return null;
      }
    },
    async getTab(tabId) {
      try {
        return toTab(await chrome.tabs.get(tabId));
      } catch {
        return null;
      }
    },
    async activate(tab) {
      if (tab.id === void 0) return;
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
    },
    async inPage(tabId, call, args, inject) {
      if (inject) {
        await chrome.scripting.executeScript({ target: { tabId }, files: [call === "read" ? "content.js" : "page.js"] });
      }
      const [result] = await chrome.scripting.executeScript({ target: { tabId }, func: runInPage, args: [call, args] });
      return result?.result;
    }
  };
  var handle = makeOps(api);
  function connect() {
    if (TARGET === "safari") {
      const send = (message) => chrome.runtime.sendNativeMessage(SAFARI_APP_ID, message);
      return new SafariPort(send, SAFARI_POLL_SECONDS);
    }
    return chrome.runtime.connectNative(HOST_NAME);
  }
  async function makeHello() {
    const nav = navigator;
    const browser = detectBrowser({ userAgent: nav.userAgent, brands: nav.userAgentData?.brands, brave: !!nav.brave }, TARGET);
    let incognitoAllowed = false;
    try {
      incognitoAllowed = await chrome.extension.isAllowedIncognitoAccess();
    } catch {
    }
    return hello(browser, chrome.runtime.getManifest().version, incognitoAllowed);
  }
  var bridge = new Bridge({
    connect,
    hello: makeHello,
    handle,
    setTimer: (fn, ms) => setTimeout(fn, ms),
    clearTimer: (h) => clearTimeout(h),
    lastError: () => chrome.runtime.lastError?.message,
    log
  });
  bridge.start();
  chrome.runtime.onStartup.addListener(() => bridge.ensure());
  chrome.alarms?.onAlarm.addListener((alarm) => {
    if (alarm.name === KEEPALIVE_ALARM) bridge.start();
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: CONTEXT_MENU_ID, title: "Send to PAL", contexts: ["page", "selection"] });
    });
    chrome.alarms?.create(KEEPALIVE_ALARM, { periodInMinutes: 1 });
    bridge.ensure();
  });
  async function sendTabActive(tab) {
    const t = tab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!t) return;
    const summary = tabSummary(toTab(t));
    bridge.sendEvent(event("tab.active", {
      tabId: summary.tabId,
      windowId: summary.windowId,
      url: summary.url,
      title: summary.title,
      incognito: summary.incognito
    }));
  }
  chrome.tabs.onActivated.addListener(({ tabId }) => {
    chrome.tabs.get(tabId).then((t) => sendTabActive(t), () => void 0);
  });
  chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) return;
    void sendTabActive();
  });
  chrome.tabs.onUpdated.addListener((_tabId, change, tab) => {
    if (tab.active && (change.url !== void 0 || change.title !== void 0 || change.status === "complete")) {
      void sendTabActive(tab);
    }
  });
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id != null) void sendPage(tab);
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== CONTEXT_MENU_ID || tab?.id == null) return;
    const selection = typeof info.selectionText === "string" && info.selectionText.trim() ? info.selectionText.trim() : void 0;
    void sendPage(tab, selection);
  });
  chrome.commands.onCommand.addListener(async (command) => {
    if (command !== "send-to-pal") return;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id != null) await sendPage(tab);
  });
  async function sendPage(tab, selectionOverride) {
    if (tab.incognito || pageRefusal(tab.url)) {
      void flashBadge("!");
      return;
    }
    let page;
    try {
      const result = await api.inPage(tab.id, "read", {}, true);
      if (!result || typeof result !== "object" || result.__error) throw new Error("no page");
      page = result;
    } catch (err) {
      log(`reading the page failed: ${err instanceof Error ? err.message : String(err)}`);
      void flashBadge("!");
      return;
    }
    const markdown = page.markdown.length > SENT_MAX_CHARS ? page.markdown.slice(0, SENT_MAX_CHARS) : page.markdown;
    const frame = event("page.sent", {
      url: page.url,
      title: page.title,
      markdown,
      selection: selectionOverride ?? page.selection ?? "",
      words: page.word_count,
      author: page.author,
      published: page.published,
      domain: page.domain,
      favicon: page.favicon,
      capturedAt: page.captured_at,
      tabId: tab.id
    });
    fitText(frame, "markdown");
    const sent = bridge.sendEvent(frame);
    void flashBadge(sent ? "\u2713" : "!");
  }
  var badgeTimer;
  async function flashBadge(text) {
    const color = text === "\u2713" ? "#1a8917" : "#c1442e";
    try {
      await chrome.action.setBadgeBackgroundColor({ color });
      await chrome.action.setBadgeText({ text });
    } catch {
      return;
    }
    if (badgeTimer) clearTimeout(badgeTimer);
    badgeTimer = setTimeout(() => {
      void chrome.action.setBadgeText({ text: "" });
    }, BADGE_LINGER_MS);
  }
})();
