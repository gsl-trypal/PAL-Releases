// A failed op, as the response frame's `error` (office_bridge.json `errors`):
// {kind, message, candidates?, nextStep?}. Kinds: not_found, ambiguous,
// unsupported, busy, app_error, invalid, changed.

export class OpError extends Error {
  constructor(kind, message, { candidates, nextStep } = {}) {
    super(message)
    this.kind = kind
    if (candidates) this.candidates = candidates
    if (nextStep) this.nextStep = nextStep
  }

  get frame() {
    const out = { kind: this.kind, message: this.message }
    if (this.candidates) out.candidates = this.candidates
    if (this.nextStep) out.nextStep = this.nextStep
    return out
  }
}

/** The requirement set an op needs is missing: the Mac falls back to AppleScript. */
export function unsupported(message) {
  return new OpError('unsupported', message)
}

/** Any error as a response frame's `error`. Office.js errors carry a `code`. */
export function errorFrame(error) {
  if (error instanceof OpError) return error.frame
  const code = error && error.code
  const message = (error && error.message) || String(error)
  if (code === 'InvalidOperationInCellEditMode') {
    return { kind: 'busy', message: 'Excel is busy: someone is typing in a cell. Finish the cell, then try again.' }
  }
  if (code === 'ApiNotFound' || code === 'NotImplemented') {
    return { kind: 'unsupported', message: `This version of Office can't do that (${message}).` }
  }
  if (code === 'ItemNotFound') return { kind: 'not_found', message }
  return { kind: 'app_error', message: code ? `${message} (${code})` : message }
}
