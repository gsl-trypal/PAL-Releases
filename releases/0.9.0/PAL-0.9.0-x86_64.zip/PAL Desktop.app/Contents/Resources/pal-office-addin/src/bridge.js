// PAL for Office's bridge (office_bridge.json): the add-in side of the
// WebSocket to the PAL app on this Mac. Plain ES modules, no build step.
//
// It connects to wss://localhost:47615/office/bridge?k=<token>, says
// `hello` with the host, the document and the requirement sets this Office
// has, answers the Mac's requests one at a time, pings every 20 s (and
// closes when it has heard nothing for 60 s), reconnects with backoff, and
// tells the Mac when the document's name or place changes and when it
// closes. Every op lives in its host's module; the Mac owns every decision
// about which rung runs.

import { errorFrame, OpError } from './errors.js'
import { wordEdit, wordRead, wordUndo } from './word.js'
import { excelEdit, excelRead, excelUndo } from './excel.js'
import { pptEdit, pptRead, pptUndo } from './ppt.js'

export const ADDIN_VERSION = '1.0.0'
export const PING_EVERY = 20000
export const SILENT_LIMIT = 60000
export const WATCH_EVERY = 5000
export const BACKOFF_MAX = 30000
export const QUEUE_MAX = 8

/** The versions each requirement set is asked about, newest first. */
export const SET_VERSIONS = {
  WordApi: ['1.9', '1.8', '1.7', '1.6', '1.5', '1.4', '1.3', '1.2', '1.1'],
  ExcelApi: ['1.20', '1.19', '1.18', '1.17', '1.16', '1.15', '1.14', '1.13', '1.12', '1.11', '1.10', '1.9', '1.8', '1.7', '1.6', '1.5', '1.4', '1.3', '1.2', '1.1'],
  PowerPointApi: ['1.10', '1.9', '1.8', '1.7', '1.6', '1.5', '1.4', '1.3', '1.2', '1.1'],
  SharedRuntime: ['1.2', '1.1'],
}

export const OPS = {
  'word.read': { host: 'word', run: wordRead },
  'word.edit': { host: 'word', run: wordEdit },
  'word.undo': { host: 'word', run: wordUndo },
  'excel.read': { host: 'excel', run: excelRead },
  'excel.edit': { host: 'excel', run: excelEdit },
  'excel.undo': { host: 'excel', run: excelUndo },
  'ppt.read': { host: 'powerpoint', run: pptRead },
  'ppt.edit': { host: 'powerpoint', run: pptEdit },
  'ppt.undo': { host: 'powerpoint', run: pptUndo },
}

/** The highest version of a set this Office supports, or "". */
export function highestSet(isSetSupported, name) {
  for (const v of SET_VERSIONS[name] || []) {
    try {
      if (isSetSupported(name, v)) return v
    } catch {
      return ''
    }
  }
  return ''
}

export function hostName(host) {
  switch (String(host || '').toLowerCase()) {
    case 'word': case 'document': return 'word'
    case 'excel': case 'workbook': return 'excel'
    case 'powerpoint': case 'presentation': return 'powerpoint'
    default: return ''
  }
}

/** The document as Office names it: its URL (a file path or a OneDrive URL) and its file name. */
export function docInfo(Office) {
  let url = ''
  try {
    url = (Office && Office.context && Office.context.document && Office.context.document.url) || ''
  } catch {
    url = ''
  }
  let name = ''
  if (url) {
    const bare = url.split(/[?#]/)[0].replace(/\/+$/, '')
    const last = bare.split(/[/\\]/).pop() || ''
    try {
      name = decodeURIComponent(last)
    } catch {
      name = last
    }
  }
  return { name, url }
}

/** What the ops are given: the host's namespace, the set check and the document's name. */
export function makeEnv(Office, scope = globalThis) {
  const supports = (name, version) => {
    try {
      return !!Office.context.requirements.isSetSupported(name, version)
    } catch {
      return false
    }
  }
  return {
    Word: scope.Word,
    Excel: scope.Excel,
    PowerPoint: scope.PowerPoint,
    supports,
    docName: () => docInfo(Office).name,
  }
}

export class Bridge {
  /**
   * @param {object} o
   * @param {string} o.url the wss URL with the token
   * @param {Function} o.WebSocket
   * @param {object} o.Office
   * @param {object} o.env what the ops are given (makeEnv)
   * @param {string} o.host word | excel | powerpoint
   */
  constructor({ url, WebSocket, Office, env, host, timers = globalThis, now = () => Date.now(), onStatus = () => {}, log = () => {} }) {
    this.url = url
    this.WebSocket = WebSocket
    this.Office = Office
    this.env = env
    this.host = host
    this.timers = timers
    this.now = now
    this.onStatus = onStatus
    this.log = log
    this.socket = null
    this.attempt = 0
    this.stopped = true
    this.lastHeard = 0
    this.pending = 0
    this.queue = Promise.resolve()
    this.doc = docInfo(Office)
    this.status = 'idle'
  }

  setStatus(status) {
    if (this.status === status) return
    this.status = status
    this.onStatus(status, this)
  }

  start() {
    if (!this.stopped) return
    this.stopped = false
    this.connect()
    this.watchTimer = this.timers.setInterval(() => this.checkDoc(), WATCH_EVERY)
  }

  stop() {
    this.stopped = true
    this.timers.clearInterval(this.watchTimer)
    this.timers.clearInterval(this.pingTimer)
    this.timers.clearTimeout(this.retryTimer)
    if (this.socket) {
      try { this.socket.close() } catch { /* already closed */ }
    }
    this.socket = null
    this.setStatus('stopped')
  }

  connect() {
    if (this.stopped) return
    this.setStatus('connecting')
    let socket
    try {
      socket = new this.WebSocket(this.url)
    } catch (error) {
      this.log('connect failed', error)
      this.retry()
      return
    }
    this.socket = socket
    socket.onopen = () => this.opened(socket)
    socket.onmessage = (event) => this.received(socket, event)
    socket.onclose = () => this.closed(socket)
    socket.onerror = () => {}
  }

  sets() {
    const check = (name, version) => this.env.supports(name, version)
    return {
      WordApi: highestSet(check, 'WordApi'),
      ExcelApi: highestSet(check, 'ExcelApi'),
      PowerPointApi: highestSet(check, 'PowerPointApi'),
      SharedRuntime: highestSet(check, 'SharedRuntime'),
    }
  }

  hello() {
    return { type: 'hello', host: this.host, addinVersion: ADDIN_VERSION, doc: this.doc, sets: this.sets(), platform: 'Mac' }
  }

  send(frame, socket = this.socket) {
    if (!socket || socket.readyState !== 1) return false
    socket.send(JSON.stringify(frame))
    return true
  }

  opened(socket) {
    if (socket !== this.socket) return
    this.attempt = 0
    this.lastHeard = this.now()
    this.send(this.hello())
    this.timers.clearInterval(this.pingTimer)
    this.pingTimer = this.timers.setInterval(() => this.tick(), PING_EVERY)
    this.setStatus('connected')
  }

  /** Every 20 s: a ping, unless nothing has been heard for 60 s — then close and start again. */
  tick() {
    if (!this.socket) return
    if (this.now() - this.lastHeard > SILENT_LIMIT) {
      this.log('nothing heard for 60 s; reconnecting')
      try { this.socket.close() } catch { /* gone */ }
      this.closed(this.socket)
      return
    }
    this.send({ type: 'ping' })
  }

  closed(socket) {
    if (socket !== this.socket) return
    this.socket = null
    this.timers.clearInterval(this.pingTimer)
    if (this.stopped) return
    this.setStatus('waiting')
    this.retry()
  }

  /** 1 s, 2 s, 4 s … at most 30 s between tries. */
  retryDelay() {
    return Math.min(BACKOFF_MAX, 1000 * 2 ** Math.min(this.attempt, 5))
  }

  retry() {
    if (this.stopped) return
    const delay = this.retryDelay()
    this.attempt += 1
    this.timers.clearTimeout(this.retryTimer)
    this.retryTimer = this.timers.setTimeout(() => this.connect(), delay)
  }

  received(socket, event) {
    if (socket !== this.socket) return
    this.lastHeard = this.now()
    let frame
    try {
      frame = JSON.parse(typeof event.data === 'string' ? event.data : String(event.data))
    } catch {
      return
    }
    switch (frame && frame.type) {
      case 'ping':
        this.send({ type: 'pong' })
        break
      case 'request':
        this.enqueue(frame)
        break
      default:
        break
    }
  }

  /** Requests run one at a time, in order; a long queue answers busy. */
  enqueue(frame) {
    if (this.pending >= QUEUE_MAX) {
      this.send({ type: 'response', id: frame.id, ok: false, error: { kind: 'busy', message: 'PAL for Office is still doing earlier requests.' } })
      return
    }
    this.pending += 1
    this.queue = this.queue.then(() => this.handle(frame)).finally(() => { this.pending -= 1 })
    return this.queue
  }

  async handle(frame) {
    const socket = this.socket
    const respond = (body) => this.send({ type: 'response', id: frame.id, ...body }, socket)
    try {
      const data = await this.run(frame.op, frame.args || {})
      respond({ ok: true, data })
    } catch (error) {
      this.log('op failed', frame.op, error)
      respond({ ok: false, error: errorFrame(error) })
    }
  }

  async run(op, args) {
    if (op === 'doc.info') {
      return { ...docInfo(this.Office), host: this.host, sets: this.sets() }
    }
    const entry = OPS[op]
    if (!entry) throw new OpError('invalid', `PAL for Office doesn't know ${op}.`)
    if (entry.host !== this.host) throw new OpError('unsupported', `${op} is for ${entry.host}, and this is ${this.host}.`)
    return entry.run(this.env, args)
  }

  /** The document's name or place changed (saved as, renamed): tell the Mac. */
  checkDoc() {
    const now = docInfo(this.Office)
    if (now.url === this.doc.url && now.name === this.doc.name) return
    this.doc = now
    this.send({ type: 'event', name: 'doc.changed', data: now })
  }

  closing() {
    this.send({ type: 'event', name: 'closing', data: this.doc })
  }
}

/** The token from the page's own address (the manifest's SourceLocation carries it). */
export function tokenFrom(location) {
  try {
    return new URL(location.href).searchParams.get('k') || ''
  } catch {
    return ''
  }
}

export function bridgeURL(location, token) {
  return `wss://${location.host}/office/bridge?k=${encodeURIComponent(token)}`
}

/**
 * Load the bridge with every document from now on, so it runs without the
 * pane being opened (SharedRuntime 1.1). Answers what it did.
 */
export async function keepLoading(Office) {
  try {
    if (!Office.context.requirements.isSetSupported('SharedRuntime', '1.1')) return 'no shared runtime'
    const now = await Office.addin.getStartupBehavior()
    if (now === Office.StartupBehavior.load) return 'already'
    await Office.addin.setStartupBehavior(Office.StartupBehavior.load)
    return 'set'
  } catch (error) {
    return `failed: ${error && error.message}`
  }
}

/** The task pane page's start: called once Office.js is loaded. */
export async function boot(scope = globalThis) {
  const { Office, document: page, location, WebSocket } = scope
  const say = (id, text) => {
    const el = page && page.getElementById(id)
    if (el) el.textContent = text
  }
  const info = await Office.onReady()
  const host = hostName(info && info.host)
  const token = tokenFrom(location)
  if (!host) {
    say('status', 'PAL for Office works in Word, Excel and PowerPoint.')
    return null
  }
  if (!token) {
    say('status', 'PAL for Office needs setting up again from the PAL app (Your Mac).')
    return null
  }
  const env = makeEnv(Office, scope)
  const words = {
    connecting: 'Looking for PAL on this Mac…',
    connected: 'Connected to PAL on this Mac.',
    waiting: "PAL isn't answering on this Mac. Is the PAL app open?",
    stopped: 'Stopped.',
  }
  const bridge = new Bridge({
    url: bridgeURL(location, token), WebSocket, Office, env, host,
    onStatus: (status) => {
      say('status', words[status] || status)
      if (page && page.body) page.body.dataset.status = status
    },
    log: (...parts) => scope.console && scope.console.log('[PAL]', ...parts),
  })
  const sets = bridge.sets()
  say('doc', bridge.doc.name || 'This document')
  say('sets', Object.entries(sets).filter(([, v]) => v).map(([k, v]) => `${k} ${v}`).join(' · '))
  scope.addEventListener && scope.addEventListener('pagehide', () => bridge.closing())
  bridge.start()
  const startup = await keepLoading(Office)
  say('startup', startup === 'set' || startup === 'already' ? 'PAL loads with every document.' : '')
  return bridge
}
