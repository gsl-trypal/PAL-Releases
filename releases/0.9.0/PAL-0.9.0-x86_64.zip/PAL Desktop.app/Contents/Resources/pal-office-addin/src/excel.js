// Excel through Office.js: excel.read, excel.edit, excel.undo, with
// mac.sheet.read / mac.sheet.edit's semantics (the Mac's SheetVerbs.swift):
// the used range by default, values as text, formulas when asked; set,
// fill, append_rows, insert_rows, insert_columns; every changed cell's old
// value or formula recorded for undo. The >200-cell ask stays on the Mac
// (it counts before sending). PAL never saves.

import { OpError, unsupported } from './errors.js'
import { A1Range, capped, cellA1, columnNumber, letters, lenientRange, parseCell, parseRange, rowNumber } from './a1.js'
import { LIMITS, cut } from './text-match.js'

export const SHEET_READ_CELLS_MAX = 2000
export const SHEET_CELLS_MAX = 5000

// MARK: - Values

/** CellValue.parse: =… a formula, TRUE/FALSE a boolean, a plain number a number, else text; blank clears. */
export function parseValue(raw) {
  const text = String(raw ?? '')
  const trimmed = text.trim()
  if (!trimmed) return { t: 'e' }
  if (trimmed.startsWith('=') && trimmed.length > 1) return { t: 'f', v: trimmed }
  if (trimmed.toLowerCase() === 'true') return { t: 'b', v: true }
  if (trimmed.toLowerCase() === 'false') return { t: 'b', v: false }
  if (/^[0-9.+\-eE]+$/.test(trimmed)) {
    const n = Number(trimmed)
    if (Number.isFinite(n)) return { t: 'n', v: n }
  }
  return { t: 's', v: text }
}

/** What Excel's `formulas` is set to for a parsed value. */
export function excelInput(value) {
  switch (value.t) {
    case 'e': return ''
    case 'b': return value.v
    case 'n': return value.v
    default: return value.v
  }
}

export function numberText(n) {
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return String(n)
  return String(n)
}

/** A number format that shows a date or time (ignoring quoted text and [colour] codes). */
export function isDateFormat(format) {
  if (!format || typeof format !== 'string' || format === 'General') return false
  const bare = format.replace(/"[^"]*"/g, '').replace(/\[[^\]]*\]/g, '').replace(/\\./g, '')
  return /[dy]/i.test(bare) || /h+:m+/i.test(bare)
}

/** An Excel date serial (1900 system) as yyyy-MM-dd, with the time when it has one. */
export function serialDate(serial) {
  const ms = Math.round((serial - 25569) * 86400000)
  const d = new Date(ms)
  const pad = (n) => String(n).padStart(2, '0')
  const day = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`
  if (d.getUTCHours() === 0 && d.getUTCMinutes() === 0 && d.getUTCSeconds() === 0) return day
  return `${day} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`
}

/** A cell as it reads in `values` and `changes`. */
export function cellText(value, type, format) {
  if (value === '' || value === null || value === undefined) return ''
  if (typeof value === 'boolean') return value ? 'TRUE' : 'FALSE'
  if (typeof value === 'number') {
    if (type === 'Double' && isDateFormat(format)) return serialDate(value)
    return numberText(value)
  }
  return String(value)
}

/** One cell as it stands: what it holds and its fingerprint (has the person changed it?). */
export function cellState(value, formula, type, format) {
  const f = typeof formula === 'string' ? formula.trim() : ''
  const isFormula = f.startsWith('=') && f.length > 1
  const text = cellText(value, type, format)
  return {
    value: value === undefined || value === null ? '' : value,
    formula: isFormula ? f : '',
    text,
    content: isFormula ? f : text,
    fingerprint: isFormula ? f : text,
  }
}

function states(range) {
  return range.values.map((row, r) => row.map((v, c) =>
    cellState(v, range.formulas?.[r]?.[c], range.valueTypes?.[r]?.[c], range.numberFormat?.[r]?.[c])))
}

// MARK: - The workbook

function needs(env) {
  if (!env.supports('ExcelApi', '1.4')) throw unsupported('This Excel is older than ExcelApi 1.4.')
}

/** The sheets, the one in front and each one's used range. */
async function outline(context) {
  const sheets = context.workbook.worksheets
  sheets.load('items/name')
  const active = sheets.getActiveWorksheet()
  active.load('name')
  await context.sync()
  const used = sheets.items.map((s) => {
    const u = s.getUsedRangeOrNullObject()
    u.load('address')
    return u
  })
  await context.sync()
  return {
    active: active.name,
    sheets: sheets.items.map((s, i) => ({ name: s.name, sheet: s, used: used[i].isNullObject ? null : lenientRange(used[i].address) })),
  }
}

function outlineJSON(book) {
  return book.sheets.map((s) => ({
    name: s.name,
    tables: [{ name: s.name, used: s.used ? s.used.a1 : '', rows: s.used ? s.used.end.row : 0, columns: s.used ? s.used.end.column : 0 }],
  }))
}

/** `sheet` as given ("" = the one in front), checked against the workbook. */
function place(book, sheet, name) {
  const want = sheet || book.active || (book.sheets[0] && book.sheets[0].name) || ''
  const found = book.sheets.find((s) => s.name === want) || book.sheets.find((s) => s.name.toLowerCase() === want.toLowerCase())
  if (!found) {
    throw new OpError('not_found', `${name} has no sheet called ${want}.`, { candidates: book.sheets.slice(0, 30).map((s) => s.name) })
  }
  return found
}

// MARK: - excel.read

export async function excelRead(env, args = {}) {
  needs(env)
  const name = env.docName() || 'the workbook'
  return env.Excel.run(async (context) => {
    const book = await outline(context)
    const sheet = place(book, args.sheet || '', name)
    const data = { sheets: outlineJSON(book), sheet: sheet.name }
    let full = null
    if (args.range) {
      full = parseRange(args.range)
      if (!full) throw new OpError('invalid', `"range" ${args.range} isn't A1 notation.`)
    } else {
      full = sheet.used
    }
    if (!full) return { ...data, range: '', values: [], truncated: false }
    const { range, truncated } = capped(full, SHEET_READ_CELLS_MAX)
    const r = sheet.sheet.getRange(range.a1)
    r.load('values,formulas,valueTypes,numberFormat')
    await context.sync()
    const cells = states(r)
    data.range = range.a1
    data.values = cells.map((row) => row.map((c) => c.text))
    if (args.formulas === true) data.formulas = cells.map((row) => row.map((c) => c.formula))
    data.truncated = truncated
    return data
  })
}

// MARK: - excel.edit

/** One mac.sheet.edit edit, checked as SheetEdit.init does. */
export function parseEdit(item, index) {
  const at = `edits[${index}]`
  const sheet = typeof item.sheet === 'string' ? item.sheet : ''
  switch (item.op) {
    case 'set': {
      const cell = parseCell(item.cell || '')
      if (!cell) throw new OpError('invalid', `${at} needs one cell, like B4.`)
      return { op: 'write', sheet, range: new A1Range(cell), values: [[parseValue(item.value)]] }
    }
    case 'fill': {
      const range = parseRange(item.range || '')
      const rows = Array.isArray(item.rows) ? item.rows : null
      if (!range || !rows) throw new OpError('invalid', `${at} needs a range and rows.`)
      const width = rows[0] ? rows[0].length : 0
      if (rows.length !== range.rows || width !== range.columns || !rows.every((r) => Array.isArray(r) && r.length === range.columns)) {
        throw new OpError('invalid', `${at}: rows is ${rows.length}×${width} but ${range.a1} is ${range.rows}×${range.columns}.`,
          { nextStep: 'Give exactly one value per cell of the range, row by row.' })
      }
      return { op: 'write', sheet, range, values: rows.map((r) => r.map(parseValue)) }
    }
    case 'append_rows': {
      const rows = Array.isArray(item.rows) ? item.rows.filter(Array.isArray) : []
      if (!rows.length || !rows.some((r) => r.length)) throw new OpError('invalid', `${at} has no rows to add.`)
      const width = Math.max(...rows.map((r) => r.length))
      return { op: 'append', sheet, rows: rows.map((r) => [...r, ...Array(width - r.length).fill('')].map(parseValue)) }
    }
    case 'insert_rows': {
      const row = rowNumber(String(item.at ?? ''))
      if (!row) throw new OpError('invalid', `${at}: insert_rows needs at as a row number, like "12".`)
      return { op: 'insertRows', sheet, at: row, count: Number.isInteger(item.count) ? item.count : 1 }
    }
    case 'insert_columns': {
      const column = columnNumber(String(item.at ?? ''))
      if (!column) throw new OpError('invalid', `${at}: insert_columns needs at as column letters, like "C".`)
      return { op: 'insertColumns', sheet, at: column, count: Number.isInteger(item.count) ? item.count : 1 }
    }
    default:
      throw new OpError('invalid', `${at} has no op PAL knows.`)
  }
}

export function cellCount(edit) {
  if (edit.op === 'write') return edit.range.count
  if (edit.op === 'append') return edit.rows.reduce((n, r) => n + r.length, 0)
  return 0
}

export async function excelEdit(env, args = {}) {
  needs(env)
  const items = Array.isArray(args.edits) ? args.edits : []
  if (!items.length) throw new OpError('invalid', 'edits is empty.')
  const edits = items.map(parseEdit)
  const total = edits.reduce((n, e) => n + cellCount(e), 0)
  if (total > SHEET_CELLS_MAX) {
    throw new OpError('invalid', `That changes ${total} cells; PAL changes at most ${SHEET_CELLS_MAX} at once.`,
      { nextStep: 'Split it into smaller edits.' })
  }
  const name = env.docName() || 'the workbook'
  return env.Excel.run(async (context) => {
    let book = await outline(context)
    // Every sheet named exists before anything changes.
    const places = edits.map((e) => place(book, e.sheet, name).name)
    const prefix = new Set(places).size > 1
    const changes = []
    const notes = []
    const undo = { cells: [], rows: [], columns: [] }
    let cells = 0
    let inserted = 0
    let seq = 0
    for (let i = 0; i < edits.length; i++) {
      const edit = edits[i]
      const sheetName = places[i]
      const label = prefix ? `${sheetName}!` : ''
      try {
        if (i > 0) book = await outline(context)
        const sheet = place(book, sheetName, name)
        seq += 1
        switch (edit.op) {
          case 'write':
            await write(context, sheet, edit.range, edit.values, { label, seq, changes, undo })
            cells += edit.range.count
            break
          case 'append': {
            const width = edit.rows[0].length
            const top = await appendTop(context, sheet)
            const range = A1Range.top(top, edit.rows.length, width)
            await write(context, sheet, range, edit.rows, { label, seq, changes, undo })
            cells += range.count
            break
          }
          case 'insertRows': {
            sheet.sheet.getRange(`${edit.at}:${edit.at + edit.count - 1}`).insert('Down')
            await context.sync()
            undo.rows.push({ seq, sheet: sheetName, at: edit.at, count: edit.count })
            changes.push({
              where: label + (edit.count === 1 ? `row ${edit.at}` : `rows ${edit.at}–${edit.at + edit.count - 1}`),
              before: '', after: edit.count === 1 ? 'a new row' : `${edit.count} new rows`,
            })
            inserted += 1
            break
          }
          case 'insertColumns': {
            const first = letters(edit.at)
            const last = letters(edit.at + edit.count - 1)
            sheet.sheet.getRange(`${first}:${last}`).insert('Right')
            await context.sync()
            undo.columns.push({ seq, sheet: sheetName, at: edit.at, count: edit.count })
            changes.push({
              where: label + (edit.count === 1 ? `column ${first}` : `columns ${first}–${last}`),
              before: '', after: edit.count === 1 ? 'a new column' : `${edit.count} new columns`,
            })
            inserted += 1
            break
          }
        }
      } catch (error) {
        if (undo.cells.length + undo.rows.length + undo.columns.length === 0) throw error
        notes.push(`Stopped at edit ${i + 1} of ${edits.length}: ${error.message}`)
        break
      }
    }
    const data = {
      changes: changes.slice(0, LIMITS.changesShown).map((c) => ({ where: c.where, before: cut(c.before), after: cut(c.after) })),
      changeCount: cells + inserted,
      cells,
      undo,
    }
    if (notes.length) data.notes = notes
    return data
  })
}

/** Below the last used row (A1 on an empty sheet). */
async function appendTop(context, sheet) {
  const used = sheet.used
  if (!used) return { column: 1, row: 1 }
  if (used.isCell && used.start.column === 1 && used.start.row === 1) {
    const a1 = sheet.sheet.getRange('A1')
    a1.load('values,formulas')
    await context.sync()
    if (cellState(a1.values[0][0], a1.formulas[0][0]).fingerprint === '') return { column: 1, row: 1 }
  }
  return { column: used.start.column, row: used.end.row + 1 }
}

/** Write values into a range, reading it before and after: the undo record and a change row per cell. */
async function write(context, sheet, range, values, { label, seq, changes, undo }) {
  const before = sheet.sheet.getRange(range.a1)
  before.load('values,formulas,valueTypes,numberFormat')
  const target = sheet.sheet.getRange(range.a1)
  target.formulas = values.map((row) => row.map(excelInput))
  const after = sheet.sheet.getRange(range.a1)
  after.load('values,formulas,valueTypes,numberFormat')
  await context.sync()
  const old = states(before)
  const now = states(after)
  range.cells.forEach((row, r) => row.forEach((cell, c) => {
    const a1 = cellA1(cell)
    changes.push({ where: label + a1, before: old[r][c].content, after: now[r][c].content })
    undo.cells.push({
      seq, sheet: sheet.name, cell: a1,
      value: old[r][c].value, formula: old[r][c].formula, after: now[r][c].fingerprint,
    })
  }))
}

// MARK: - excel.undo

/**
 * Newest first: cells the person hasn't touched since get their old value or
 * formula back (the rest are left, and said); rows and columns PAL inserted
 * are removed while they are still empty.
 */
export async function excelUndo(env, args = {}) {
  needs(env)
  const undo = args.undo || {}
  const name = env.docName() || 'the workbook'
  const steps = [
    ...(undo.cells || []).map((c, i) => ({ kind: 'cell', order: i, ...c })),
    ...(undo.rows || []).map((r, i) => ({ kind: 'rows', order: i, ...r })),
    ...(undo.columns || []).map((r, i) => ({ kind: 'columns', order: i, ...r })),
  ].sort((a, b) => (b.seq ?? 0) - (a.seq ?? 0) || b.order - a.order)
  return env.Excel.run(async (context) => {
    const book = await outline(context)
    const notes = []
    let undone = 0
    let skipped = 0
    const sheetOf = (sheetName) => {
      const s = book.sheets.find((x) => x.name === sheetName)
      return s ? s.sheet : null
    }
    // Cells of one write together: one read, one write.
    let i = 0
    while (i < steps.length) {
      const step = steps[i]
      if (step.kind === 'cell') {
        const group = []
        while (i < steps.length && steps[i].kind === 'cell' && steps[i].seq === step.seq) group.push(steps[i++])
        const reads = group.map((c) => {
          const ws = sheetOf(c.sheet)
          if (!ws) return null
          const r = ws.getRange(c.cell)
          r.load('values,formulas,valueTypes,numberFormat')
          return r
        })
        await context.sync()
        group.forEach((c, j) => {
          const r = reads[j]
          if (!r) { skipped += 1; return }
          const now = cellState(r.values[0][0], r.formulas[0][0], r.valueTypes?.[0]?.[0], r.numberFormat?.[0]?.[0])
          if (now.fingerprint !== (c.after ?? '')) { skipped += 1; return }
          r.formulas = [[c.formula ? c.formula : (c.value ?? '')]]
          undone += 1
        })
        await context.sync()
        continue
      }
      i += 1
      const rows = step.kind === 'rows'
      const ws = sheetOf(step.sheet)
      if (!ws || !(step.at > 0) || !(step.count > 0)) continue
      const address = rows ? `${step.at}:${step.at + step.count - 1}` : `${letters(step.at)}:${letters(step.at + step.count - 1)}`
      const used = ws.getRange(address).getUsedRangeOrNullObject(true)
      used.load('address')
      await context.sync()
      if (used.isNullObject) {
        ws.getRange(address).delete(rows ? 'Up' : 'Left')
        await context.sync()
        undone += 1
      } else {
        const what = rows ? (step.count === 1 ? 'row' : `${step.count} rows`) : (step.count === 1 ? 'column' : `${step.count} columns`)
        const spot = rows ? `row ${step.at}` : `column ${letters(step.at)}`
        notes.push(`PAL left the ${what} it added at ${spot} of ${step.sheet}: something is in them now.`)
      }
    }
    if (skipped > 0) {
      notes.unshift(`${skipped} cell${skipped === 1 ? ` in ${name} had` : `s in ${name} had`} been changed since, so PAL left ${skipped === 1 ? 'it' : 'them'}.`)
    }
    return { undone, notes }
  })
}
