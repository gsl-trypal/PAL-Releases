// A1 notation as verbs.json's `a1` argType has it (the Mac's A1.swift):
// column letters upper case, 1–3 of them; a row 1–9,999,999; one cell or
// `start:end`.

export function letters(column) {
  let n = column
  let out = ''
  while (n > 0) {
    const r = (n - 1) % 26
    out = String.fromCharCode(65 + r) + out
    n = Math.floor((n - 1) / 26)
  }
  return out
}

export function columnNumber(text) {
  if (!/^[A-Z]{1,3}$/.test(text)) return null
  let n = 0
  for (const ch of text) n = n * 26 + (ch.charCodeAt(0) - 64)
  return n
}

export function rowNumber(text) {
  return /^[1-9][0-9]{0,6}$/.test(text) ? Number(text) : null
}

function strictCell(text) {
  const m = /^([A-Z]{1,3})([1-9][0-9]{0,6})$/.exec(text)
  return m ? { column: columnNumber(m[1]), row: Number(m[2]) } : null
}

export class A1Range {
  constructor(a, b = a) {
    this.start = { column: Math.min(a.column, b.column), row: Math.min(a.row, b.row) }
    this.end = { column: Math.max(a.column, b.column), row: Math.max(a.row, b.row) }
  }

  static top(cell, rows, columns) {
    return new A1Range(cell, { column: cell.column + Math.max(1, columns) - 1, row: cell.row + Math.max(1, rows) - 1 })
  }

  get rows() { return this.end.row - this.start.row + 1 }
  get columns() { return this.end.column - this.start.column + 1 }
  get count() { return this.rows * this.columns }
  get isCell() { return this.rows === 1 && this.columns === 1 }

  get a1() {
    const s = cellA1(this.start)
    return this.isCell ? s : `${s}:${cellA1(this.end)}`
  }

  /** Row by row. */
  get cells() {
    const out = []
    for (let r = this.start.row; r <= this.end.row; r++) {
      const row = []
      for (let c = this.start.column; c <= this.end.column; c++) row.push({ column: c, row: r })
      out.push(row)
    }
    return out
  }
}

export function cellA1(cell) {
  return letters(cell.column) + String(cell.row)
}

/** A cell or range from PAL (strict), or null. */
export function parseRange(text) {
  if (typeof text !== 'string') return null
  const parts = text.split(':')
  if (parts.length < 1 || parts.length > 2) return null
  const cells = parts.map(strictCell)
  if (cells.some((c) => !c)) return null
  return new A1Range(cells[0], cells[1] || cells[0])
}

export function parseCell(text) {
  const r = parseRange(text)
  return r && r.isCell ? r.start : null
}

/** What Excel answers ("Sheet1!$A$1:$F$40", "'My sheet'!B2"), read leniently. */
export function lenientRange(address) {
  if (!address) return null
  const bare = String(address).split('!').pop().replace(/\$/g, '').toUpperCase()
  return parseRange(bare)
}

/** At most `max` cells: whole rows from the top (and columns from the left when one row is already too wide). */
export function capped(range, max = 2000) {
  if (range.count <= max) return { range, truncated: false }
  const columns = Math.min(range.columns, max)
  const rows = Math.max(1, Math.floor(max / columns))
  return { range: A1Range.top(range.start, Math.min(rows, range.rows), columns), truncated: true }
}
