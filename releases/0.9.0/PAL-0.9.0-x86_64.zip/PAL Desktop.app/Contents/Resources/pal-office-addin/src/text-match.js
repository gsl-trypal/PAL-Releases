// The pure part of editing text, exactly as the Mac's TextEdits.swift does it
// (contract README "Phase 4: editing in place"): `find` matches exactly after
// folding line endings and curly quotes on both sides; one match or
// `occurrence`/`all`, else `ambiguous` with at most 5 snippets; every edit is
// tried on a copy before anything changes. Offsets are UTF-16 units, as in
// Swift's NSString, so a JS string index is the same number.

import { OpError } from './errors.js'

export const LIMITS = { changesShown: 20, changeTextMax: 300 }
const SNIPPET_SIDE = 24
const CONTEXT_SIDE = 40

/** One UTF-16 unit, folded: line breaks to \n, curly quotes to straight. */
export function foldUnit(c) {
  switch (c) {
    case 0x0d: case 0x0b: case 0x2028: case 0x2029: return 0x0a
    case 0x2018: case 0x2019: case 0x201a: case 0x201b: case 0x2032: return 0x27
    case 0x201c: case 0x201d: case 0x201e: case 0x201f: case 0x2033: return 0x22
    default: return c
  }
}

/** Text as `find` matches it, with a map from every folded unit back. */
export class FoldedText {
  constructor(text) {
    const n = text.length
    const out = []
    const starts = []
    let i = 0
    while (i < n) {
      starts.push(i)
      const c = text.charCodeAt(i)
      if (c === 0x0d && i + 1 < n && text.charCodeAt(i + 1) === 0x0a) {
        out.push(0x0a)
        i += 2
        continue
      }
      out.push(foldUnit(c))
      i += 1
    }
    starts.push(n)
    this.original = text
    this.folded = fromUnits(out)
    this.starts = starts
  }

  static fold(text) {
    return new FoldedText(text).folded
  }

  /** A folded range as the original range it came from. */
  originalRange(location, length) {
    const start = this.starts[location]
    return { location: start, length: this.starts[location + length] - start }
  }

  /** Every match of `needle`, folded, left to right, not overlapping. */
  matches(needle) {
    const want = FoldedText.fold(needle)
    if (!want) return []
    const out = []
    let from = 0
    while (from < this.folded.length) {
      const at = this.folded.indexOf(want, from)
      if (at < 0) break
      out.push({ location: at, length: want.length })
      from = at + Math.max(1, want.length)
    }
    return out
  }
}

// String.fromCharCode with one argument per unit overflows the stack on a
// long document; this builds the string in pieces.
function fromUnits(units) {
  let s = ''
  for (let i = 0; i < units.length; i += 8192) s += String.fromCharCode(...units.slice(i, i + 8192))
  return s
}

/** One edit from `mac.document.edit`'s `edits`, checked as TextEdit.init does. */
export function checkEdit(item, index) {
  const at = `edits[${index}]`
  const op = item.op
  if (!['replace', 'insert', 'replace_selection', 'append', 'comment'].includes(op)) {
    throw new OpError('invalid', `${at} has no op PAL knows.`)
  }
  const edit = {
    op,
    find: typeof item.find === 'string' ? item.find : null,
    text: typeof item.text === 'string' ? item.text : '',
    all: item.all === true,
    occurrence: Number.isInteger(item.occurrence) ? item.occurrence : null,
    at: typeof item.at === 'string' ? item.at : null,
  }
  if (edit.all && edit.occurrence !== null) {
    throw new OpError('invalid', `${at} gives both occurrence and all; give one.`)
  }
  switch (op) {
    case 'replace':
      if (!edit.find) throw new OpError('invalid', `${at} has nothing to find.`)
      break
    case 'insert':
      if ((edit.at === 'before' || edit.at === 'after') && !edit.find) {
        throw new OpError('invalid', `${at} inserts ${edit.at} a find it doesn't give.`)
      }
      if (!edit.text) throw new OpError('invalid', `${at} inserts nothing.`)
      break
    case 'append':
      if (!edit.text) throw new OpError('invalid', `${at} appends nothing.`)
      break
    case 'comment':
      if (!edit.find) throw new OpError('invalid', `${at} has nothing to comment on.`)
      if (!edit.text) throw new OpError('invalid', `${at} has no comment text.`)
      break
  }
  return edit
}

export function times(n) {
  return n === 1 ? 'once' : n === 2 ? 'twice' : `${n} times`
}

export function oneLine(text) {
  return text.replace(/\r\n/g, ' ').split(/[\n\r\u000b\u2028\u2029\t]/).join(' ')
}

/** At most `n` code points, the last one "…" when cut. */
export function cut(text, n = LIMITS.changeTextMax) {
  const points = Array.from(text)
  if (points.length <= n) return text
  return points.slice(0, Math.max(0, n - 1)).join('') + '…'
}

export function quote(text) {
  return `"${cut(oneLine(text), 60)}"`
}

/** "…grew 12% in the quarter. Costs…": a match with a little either side. */
export function snippet(match, folded) {
  const s = folded.folded
  const start = Math.max(0, match.location - SNIPPET_SIDE)
  const end = Math.min(s.length, match.location + match.length + SNIPPET_SIDE)
  const piece = oneLine(s.slice(start, end))
  return (start > 0 ? '…' : '') + piece + (end < s.length ? '…' : '')
}

/** The original ranges a needle picks, or not_found / ambiguous. */
export function targets(needle, text, { all = false, occurrence = null, name }) {
  const folded = new FoldedText(text)
  const found = folded.matches(needle)
  const quoted = quote(needle)
  if (found.length === 0) {
    throw new OpError('not_found', `${quoted} isn't in ${name}.`,
      { nextStep: 'Read it again and quote the text exactly as it is.' })
  }
  const original = (m) => folded.originalRange(m.location, m.length)
  if (all) return found.map(original)
  if (occurrence !== null) {
    if (occurrence > found.length) {
      throw new OpError('not_found', `${quoted} is in ${name} only ${times(found.length)}.`,
        { nextStep: `Give an occurrence from 1 to ${found.length}.` })
    }
    return [original(found[occurrence - 1])]
  }
  if (found.length !== 1) {
    throw new OpError('ambiguous', `${quoted} is in ${name} ${times(found.length)}.`, {
      candidates: found.slice(0, 5).map((m) => snippet(m, folded)),
      nextStep: 'Quote more of the sentence, or give `occurrence` or `all`.',
    })
  }
  return [original(found[0])]
}

/**
 * The splices one edit makes in `text`, left to right: {range, old, new,
 * anchor?, comment?}. A comment changes no text (old === new) and carries
 * its comment text.
 */
export function splices(edit, text, { selection = null, end = null, name }) {
  const endOffset = Math.min(text.length, Math.max(0, end ?? text.length))
  const sub = (r) => text.slice(r.location, r.location + r.length)
  const opts = { all: edit.all, occurrence: edit.occurrence, name }
  switch (edit.op) {
    case 'replace':
      return targets(edit.find, text, opts).map((r) => ({ range: r, old: sub(r), new: edit.text, anchor: r }))
    case 'comment':
      return targets(edit.find, text, opts).map((r) => ({ range: r, old: sub(r), new: sub(r), anchor: r, comment: edit.text }))
    case 'insert': {
      const at = edit.at || 'end'
      if (at === 'start') return [{ range: { location: 0, length: 0 }, old: '', new: edit.text }]
      if (at === 'end') return [{ range: { location: endOffset, length: 0 }, old: '', new: edit.text }]
      const after = at === 'after'
      return targets(edit.find, text, opts).map((found) => ({
        range: { location: after ? found.location + found.length : found.location, length: 0 },
        old: '', new: edit.text, anchor: found, side: after ? 'After' : 'Before',
      }))
    }
    case 'append':
      return [{ range: { location: endOffset, length: 0 }, old: '', new: edit.text }]
    case 'replace_selection': {
      if (!selection || selection.length === 0 || selection.location + selection.length > text.length) {
        throw new OpError('not_found', `Nothing is selected in ${name}.`,
          { nextStep: 'Ask them to select the text to rewrite, or quote it with find.' })
      }
      return [{ range: selection, old: sub(selection), new: edit.text, anchor: selection, selection: true }]
    }
  }
  return []
}

export function delta(splice) {
  return splice.new.length - splice.range.length
}

/** Splices (left to right, not overlapping) made in `text`. */
export function apply(list, text) {
  let out = text
  for (const s of [...list].sort((a, b) => b.range.location - a.range.location)) {
    out = out.slice(0, s.range.location) + s.new + out.slice(s.range.location + s.range.length)
  }
  return out
}

/** Where the selection is after `list` (null when they cut into it). */
export function shift(selection, list) {
  if (!selection) return null
  let d = 0
  let length = selection.length
  const selEnd = selection.location + selection.length
  for (const s of [...list].sort((a, b) => a.range.location - b.range.location)) {
    const r = s.range
    const rEnd = r.location + r.length
    const same = r.location === selection.location && r.length === selection.length
    const before = r.length === 0 ? r.location <= selection.location : rEnd <= selection.location
    if (before) d += delta(s)
    else if (r.location >= selEnd && !same) continue
    else if (same) length = s.new.length
    else return null
  }
  return { location: selection.location + d, length }
}

/** Every edit tried on a copy first. Answers each edit's splices and the text after them all. */
export function simulate(edits, text, { selection = null, end = null, name }) {
  let current = text
  let sel = selection
  const out = []
  edits.forEach((edit, i) => {
    if (edit.op === 'replace_selection' && selection && !sel) {
      throw new OpError('invalid', `Edit ${i + 1} rewrites the selection after an earlier edit changed it.`)
    }
    let planned
    try {
      planned = splices(edit, current, { selection: sel, end: end ? end(current) : null, name })
    } catch (error) {
      if (error instanceof OpError && edits.length > 1) {
        throw new OpError(error.kind, `Edit ${i + 1} of ${edits.length}: ${error.message}`, {
          candidates: error.candidates,
          nextStep: `${error.nextStep || ''} Nothing was changed.`.trim(),
        })
      }
      throw error
    }
    out.push(planned)
    current = apply(planned, current)
    sel = shift(sel, planned)
  })
  return { planned: out, text: current }
}

/** "paragraph 3": counted by line breaks before `offset`. */
export function place(offset, text) {
  const upTo = FoldedText.fold(text.slice(0, Math.min(Math.max(0, offset), text.length)))
  let n = 1
  for (let i = 0; i < upTo.length; i++) if (upTo.charCodeAt(i) === 0x0a) n++
  return `paragraph ${n}`
}

/**
 * What splices did, once made: where each one's new text is in the text
 * after them all, and a little either side — the records undo finds them by.
 */
export function records(list, before, after) {
  let s = 0
  const out = []
  for (const sp of [...list].sort((a, b) => a.range.location - b.range.location)) {
    const offset = sp.range.location + s
    const newLength = sp.new.length
    const leftStart = Math.max(0, offset - CONTEXT_SIDE)
    const rightEnd = Math.min(after.length, offset + newLength + CONTEXT_SIDE)
    out.push({
      offset,
      old: sp.old,
      new: sp.new,
      left: after.slice(leftStart, offset),
      right: after.slice(offset + newLength, Math.max(offset + newLength, rightEnd)),
      place: place(sp.range.location, before),
    })
    s += delta(sp)
  }
  return out
}

/** Where a record's new text is now (nearest to where it was put), or null. */
export function locate(record, text) {
  const folded = new FoldedText(text)
  const nearest = (ranges) => {
    let best = null
    for (const r of ranges) {
      if (!best || Math.abs(r.location - record.offset) < Math.abs(best.location - record.offset)) best = r
    }
    return best
  }
  if (record.new) {
    return nearest(folded.matches(record.new).map((m) => folded.originalRange(m.location, m.length)))
  }
  const left = Array.from(record.left || '').slice(-12).join('')
  const right = Array.from(record.right || '').slice(0, 12).join('')
  if (!(left + right)) return null
  const leftLength = FoldedText.fold(left).length
  const joins = folded.matches(left + right).map((m) => {
    const p = folded.originalRange(m.location + leftLength, 0)
    return { location: p.location, length: 0 }
  })
  return nearest(joins)
}

/** `changes` for a result: at most changesShown, each side cut. */
export function changesData(list) {
  return list.slice(0, LIMITS.changesShown).map((c) => ({
    where: c.where, before: cut(c.before), after: cut(c.after),
  }))
}
