// Word through Office.js: word.read, word.edit, word.undo
// (office_bridge.json `ops`). Matching is the Phase 4 rules (text-match.js),
// worked out on the document's text as the person sees it — tracked
// deletions left out (`getReviewedText('Current')`, WordApi 1.4) — and only
// then turned into Word ranges.
//
// **Word's search takes at most 255 characters**, so a `find` is never
// searched for as it is. The text is read paragraph by paragraph; a match is
// an offset range in that text; each end of it becomes a Word range by
// searching its own paragraph for a short piece (≤ 250 characters, escaped)
// that ends or starts exactly there — falling back to one character, which
// always lines up — and the two ends are joined with `expandTo`. Search
// results are counted the way Word counts them (left to right, not
// overlapping) and kept only when their text is exactly the piece and none
// of it is a tracked deletion, so the n-th result is the n-th occurrence in
// the text PAL matched on. Every range is read back before anything changes.

import { OpError, unsupported } from './errors.js'
import * as tm from './text-match.js'

export const MAX_PIECE = 250

// MARK: - Search pieces

/** A piece as Word's search wants it, or null when it can't be searched for. */
export function escapeSearch(piece) {
  let out = ''
  for (const ch of piece) {
    const c = ch.charCodeAt(0)
    if (ch === '^') out += '^^'
    else if (c === 0x0b) out += '^l'
    else if (c === 0x09) out += '^t'
    else if (c < 0x20 || c === 0x2028 || c === 0x2029) return null
    else out += ch
  }
  return out.length > 0 && out.length <= 255 ? out : null
}

function escapedLength(ch) {
  return ch === '^' || ch === '\u000b' || ch === '\t' ? 2 : 1
}

function searchable(ch) {
  const c = ch.charCodeAt(0)
  return !(c < 0x20 && c !== 0x09 && c !== 0x0b) && c !== 0x2028 && c !== 0x2029
}

const isLow = (c) => c >= 0xdc00 && c <= 0xdfff

/** Where `needle` starts in `text`, the way Word's search finds them. */
export function nonOverlapping(text, needle) {
  const out = []
  if (!needle) return out
  let from = 0
  for (;;) {
    const at = text.indexOf(needle, from)
    if (at < 0) return out
    out.push(at)
    from = at + needle.length
  }
}

/** The longest searchable piece of `text` that ends at `end` (start ≥ `floor`). */
export function pieceEndingAt(text, end, floor = 0, max = MAX_PIECE) {
  let start = end
  let length = 0
  while (start > floor) {
    const ch = text[start - 1]
    if (!searchable(ch)) break
    const add = escapedLength(ch)
    if (length + add > max) break
    start -= 1
    length += add
  }
  // Never split a surrogate pair.
  if (start < end && isLow(text.charCodeAt(start))) start += 1
  return start < end ? { start, end } : null
}

/** The longest searchable piece of `text` that starts at `start` (end ≤ `ceiling`). */
export function pieceStartingAt(text, start, ceiling = text.length, max = MAX_PIECE) {
  let end = start
  let length = 0
  while (end < ceiling) {
    const ch = text[end]
    if (!searchable(ch)) break
    const add = escapedLength(ch)
    if (length + add > max) break
    end += 1
    length += add
  }
  if (end > start && end < text.length && isLow(text.charCodeAt(end))) end -= 1
  return end > start ? { start, end } : null
}

// MARK: - The document as text

/** Text as Word answers it across paragraphs: its marks (\r) as \n. */
export function plain(text) {
  return (text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n')
}

function stripMark(text) {
  return (text || '').replace(/[\r\n]$/, '')
}

/**
 * The body's paragraphs and the text PAL matches on: each paragraph's text
 * as the person sees it (tracked deletions left out when WordApi 1.4 can say
 * which they are), joined by \n.
 */
export async function readModel(context, { reviewed }) {
  const paragraphs = context.document.body.paragraphs
  paragraphs.load('items/text')
  await context.sync()
  const items = paragraphs.items
  let texts = items.map((p) => p.text)
  if (reviewed) {
    const results = items.map((p) => p.getReviewedText('Current'))
    await context.sync()
    texts = results.map((r) => stripMark(r.value))
  }
  const starts = []
  let at = 0
  for (const t of texts) {
    starts.push(at)
    at += t.length + 1
  }
  return { paragraphs: items, texts, starts, text: texts.join('\n') }
}

/** Paragraph and offset in it of a position in the model's text. */
export function pointAt(model, position) {
  let low = 0
  let high = model.starts.length - 1
  while (low < high) {
    const mid = (low + high + 1) >> 1
    if (model.starts[mid] <= position) low = mid
    else high = mid - 1
  }
  return { index: low, local: Math.min(position - model.starts[low], model.texts[low].length) }
}

// MARK: - From offsets to Word ranges

/**
 * Turns offset ranges and points in `model` into Word ranges, a few batched
 * searches at a time. Throws `changed` when Word doesn't hold what the model
 * says it does.
 */
export class Locator {
  constructor(context, model, { reviewed, name }) {
    this.context = context
    this.model = model
    this.reviewed = reviewed
    this.name = name
  }

  changed() {
    return new OpError('changed', `${this.name} changed while PAL was editing it.`,
      { nextStep: 'Read it again, then try the edit again.' })
  }

  /** The strategies for a point, best first: {index, piece, k, side}. */
  pointPlans(position) {
    const { index, local } = pointAt(this.model, position)
    const text = this.model.texts[index]
    if (local === 0) return [{ edge: 'start', index }]
    if (local === text.length) return [{ edge: 'end', index }]
    const plans = []
    const add = (r, side) => {
      if (!r) return
      const piece = text.slice(r.start, r.end)
      const starts = nonOverlapping(text, piece)
      const k = starts.indexOf(r.start)
      if (k >= 0) plans.push({ index, piece, k, count: starts.length, side })
    }
    add(pieceEndingAt(text, local), 'End')
    add(pieceStartingAt(text, local), 'Start')
    add(pieceEndingAt(text, local, Math.max(0, local - (isLow(text.charCodeAt(local - 1)) ? 2 : 1))), 'End')
    add(pieceStartingAt(text, local, Math.min(text.length, local + (isLow(text.charCodeAt(local + 1)) ? 2 : 1))), 'Start')
    return plans
  }

  /** The one-search plan for a range inside one paragraph, if there is one. */
  directPlan(start, end) {
    const a = pointAt(this.model, start)
    const b = pointAt(this.model, end)
    if (a.index !== b.index) return null
    const text = this.model.texts[a.index]
    const piece = text.slice(a.local, b.local)
    if (!piece || !escapeSearch(piece)) return null
    const starts = nonOverlapping(text, piece)
    const k = starts.indexOf(a.local)
    return k >= 0 ? { index: a.index, piece, k, count: starts.length, side: 'Whole' } : null
  }

  /** Run plans (one per job): each answers a Word range or null. */
  async runPlans(jobs) {
    const searches = jobs.map((plan) => {
      if (!plan || plan.edge) return null
      const results = this.model.paragraphs[plan.index].search(escapeSearch(plan.piece), { matchCase: true })
      results.load('items/text')
      return results
    })
    if (searches.some(Boolean)) await this.context.sync()
    const reviews = searches.map((results) =>
      results && this.reviewed ? results.items.map((r) => r.getReviewedText('Current')) : null)
    if (reviews.some(Boolean)) await this.context.sync()
    return jobs.map((plan, i) => {
      if (!plan) return null
      const paragraph = this.model.paragraphs[plan.index]
      if (plan.edge === 'start') return paragraph.getRange('Start')
      if (plan.edge === 'end') return paragraph.getRange('Content').getRange('End')
      const items = searches[i].items
      const live = items.filter((r, j) =>
        r.text === plan.piece && (!reviews[i] || stripMark(reviews[i][j].value) === plan.piece))
      if (live.length !== plan.count) return null
      const hit = live[plan.k]
      return plan.side === 'Whole' ? hit : hit.getRange(plan.side)
    })
  }

  /** A point (a collapsed range) at each position. */
  async points(positions) {
    const plans = positions.map((p) => this.pointPlans(p))
    const out = positions.map(() => null)
    for (let round = 0; round < 4; round++) {
      const todo = plans.map((list, i) => (out[i] ? null : list[round] || null))
      if (!todo.some(Boolean)) break
      const got = await this.runPlans(todo)
      got.forEach((r, i) => { if (r) out[i] = r })
    }
    if (out.some((r) => !r)) throw this.changed()
    return out
  }

  /**
   * Word ranges for offset ranges ({location, length} in the model's text),
   * each read back and checked against the text PAL expects there.
   */
  async ranges(list) {
    const out = list.map(() => null)
    const direct = list.map((r) => (r.length > 0 ? this.directPlan(r.location, r.location + r.length) : null))
    if (direct.some(Boolean)) {
      const got = await this.runPlans(direct)
      got.forEach((r, i) => { if (r) out[i] = r })
    }
    const rest = list.map((r, i) => (out[i] ? null : r)).filter(Boolean)
    if (rest.length) {
      const ends = await this.points(rest.flatMap((r) => [r.location, r.location + r.length]))
      let j = 0
      list.forEach((r, i) => {
        if (out[i]) return
        const [a, b] = [ends[j], ends[j + 1]]
        j += 2
        out[i] = r.length > 0 ? a.expandTo(b) : a
      })
    }
    await this.check(list, out)
    return out
  }

  /** Each range holds what the model says, as the person sees it. */
  async check(list, ranges) {
    const reads = ranges.map((r, i) => {
      if (list[i].length === 0) return null
      if (this.reviewed) return r.getReviewedText('Current')
      r.load('text')
      return r
    })
    if (!reads.some(Boolean)) return
    await this.context.sync()
    reads.forEach((read, i) => {
      if (!read) return
      const want = this.model.text.slice(list[i].location, list[i].location + list[i].length)
      const got = plain(this.reviewed ? read.value : read.text)
      if (tm.FoldedText.fold(stripMark(got)) !== tm.FoldedText.fold(want)
        && tm.FoldedText.fold(got) !== tm.FoldedText.fold(want)) {
        throw this.changed()
      }
    })
  }
}

// MARK: - word.read

export async function wordRead(env, args = {}) {
  const { Word, supports } = env
  if (!supports('WordApi', '1.1')) throw unsupported('This Word has no WordApi.')
  const maxChars = Math.max(1, Math.min(2000000, Number.isInteger(args.maxChars) ? args.maxChars : 12000))
  const reviewed = supports('WordApi', '1.4')
  return Word.run(async (context) => {
    const body = context.document.body
    let text
    let paragraphs
    if (args.scope === 'selection') {
      const selection = context.document.getSelection()
      selection.load('text')
      selection.paragraphs.load('items')
      const review = reviewed ? selection.getReviewedText('Current') : null
      await context.sync()
      text = plain(review ? review.value : selection.text)
      paragraphs = selection.paragraphs.items.length
    } else {
      const model = await readModel(context, { reviewed })
      text = model.text
      paragraphs = model.texts.length
    }
    let tables = []
    let trackedChanges = -1
    let comments = -1
    const tableList = supports('WordApi', '1.3') ? body.tables : null
    if (tableList) tableList.load('items/values')
    const tracked = supports('WordApi', '1.6') ? body.getTrackedChanges() : null
    if (tracked) tracked.load('items/type')
    const commentList = reviewed ? body.getComments() : null
    if (commentList) commentList.load('items/id')
    if (tableList || tracked || commentList) await context.sync()
    if (tableList) {
      tables = tableList.items.slice(0, 10).map((t, index) => ({
        index, rows: (t.values || []).slice(0, 50).map((row) => row.map(String)),
      }))
    }
    if (tracked) trackedChanges = tracked.items.length
    if (commentList) comments = commentList.items.length
    return {
      text: text.length > maxChars ? text.slice(0, maxChars) : text,
      paragraphs,
      chars: text.length,
      truncated: text.length > maxChars,
      tables,
      trackedChanges,
      comments,
    }
  })
}

// MARK: - word.edit

/** The selection's place in the model's text (for planning; the edit itself uses the selection). */
async function selectionIn(context, model, { reviewed }) {
  const body = context.document.body
  const selection = context.document.getSelection()
  selection.load('text')
  const before = body.getRange('Start').expandTo(selection.getRange('Start'))
  before.load('text')
  const reviews = reviewed ? [selection.getReviewedText('Current'), before.getReviewedText('Current')] : null
  await context.sync()
  const text = plain(reviews ? reviews[0].value : selection.text)
  if (!text) return { range: selection, at: null }
  const lead = plain(reviews ? reviews[1].value : before.text)
  if (model.text.substr(lead.length, text.length) === text) {
    return { range: selection, at: { location: lead.length, length: text.length } }
  }
  const found = nonOverlapping(model.text, text)
  if (found.length === 0) return { range: selection, at: null }
  return { range: selection, at: { location: found[0], length: text.length } }
}

function needsSets(env, edits, track) {
  const { supports } = env
  if (!supports('WordApi', '1.3')) throw unsupported('This Word is older than WordApi 1.3.')
  if (track && !supports('WordApi', '1.4')) {
    throw unsupported("This Word can't turn on Track Changes from PAL for Office (WordApi 1.4).")
  }
  if (edits.some((e) => e.op === 'comment') && !supports('WordApi', '1.4')) {
    throw unsupported("This Word can't add comments from PAL for Office (WordApi 1.4).")
  }
}

/**
 * One splice queued in Word; answers the comment (its id loads at the next
 * sync) for a comment. With no range, the text goes at the body's start or
 * end (`edge`).
 */
function make(splice, range, body, edge) {
  if (splice.comment !== undefined) {
    const comment = range.insertComment(splice.comment)
    comment.load('id')
    return comment
  }
  if (!range) {
    body.insertText(splice.new, edge)
    return null
  }
  if (splice.side) {
    range.insertText(splice.new, splice.side)
  } else if (splice.new === '') {
    range.delete()
  } else {
    range.insertText(splice.new, 'Replace')
  }
  return null
}

export async function wordEdit(env, args = {}) {
  const { Word, supports } = env
  const items = Array.isArray(args.edits) ? args.edits : []
  if (items.length === 0) throw new OpError('invalid', 'edits is empty.')
  const edits = items.map((item, i) => tm.checkEdit(item, i))
  const track = args.track !== false
  needsSets(env, edits, track)
  const reviewed = supports('WordApi', '1.4')
  const name = env.docName() || 'the document'
  return Word.run(async (context) => {
    const doc = context.document
    const body = doc.body
    let model = await readModel(context, { reviewed })
    let selection = null
    let selected = null
    if (edits.some((e) => e.op === 'replace_selection')) {
      const s = await selectionIn(context, model, { reviewed })
      selected = s.range
      selection = s.at
    }
    // Every edit tried on a copy first: nothing changes unless all can be made.
    const simulated = tm.simulate(edits, model.text, { selection, end: (t) => t.length, name })

    let wasMode = null
    if (reviewed) {
      doc.load('changeTrackingMode')
      await context.sync()
      wasMode = doc.changeTrackingMode
      if (track && wasMode !== 'TrackAll') doc.changeTrackingMode = 'TrackAll'
      if (!track && wasMode !== 'Off') doc.changeTrackingMode = 'Off'
    }
    const restore = async () => {
      // PAL turns Track Changes on and leaves it on; `track: false` turns it
      // off only for its own edits.
      if (!track && wasMode && wasMode !== 'Off') {
        doc.changeTrackingMode = wasMode
        await context.sync()
      }
    }

    const changes = []
    const undoChanges = []
    const comments = []
    const commentTexts = []
    const notes = []
    let made = 0
    for (let i = 0; i < edits.length; i++) {
      const edit = edits[i]
      try {
        if (i > 0) model = await readModel(context, { reviewed })
        const planned = tm.splices(edit, model.text, { selection, end: model.text.length, name })
        const locator = new Locator(context, model, { reviewed, name })
        const wanted = planned.map((sp) => (sp.selection || (!sp.anchor) ? null : sp.anchor))
        const found = await locator.ranges(wanted.filter(Boolean))
        let j = 0
        const ranges = wanted.map((w) => (w ? found[j++] : null))
        // Right to left, so nothing made moves what is still to be made.
        const order = planned.map((sp, k) => k).sort((a, b) => planned[b].range.location - planned[a].range.location)
        const edge = edit.op === 'insert' && edit.at === 'start' ? 'Start' : 'End'
        const commentProxies = []
        for (const k of order) {
          const sp = planned[k]
          const c = make(sp, sp.selection ? selected : ranges[k], body, edge)
          if (c) commentProxies.push({ proxy: c, text: sp.comment })
        }
        await context.sync()
        for (const c of commentProxies) {
          comments.push(c.proxy.id)
          commentTexts.push(c.text)
        }
        const after = tm.apply(planned, model.text)
        const recs = tm.records(planned, model.text, after)
        planned.forEach((sp, k) => {
          const r = recs[k]
          if (sp.comment !== undefined) {
            changes.push({ where: r.place, before: sp.old, after: `${sp.old} [comment: ${sp.comment}]` })
          } else {
            changes.push({ where: r.place, before: r.old, after: r.new })
            undoChanges.push({ text: r.new, old: r.old, start: r.offset, left: r.left, right: r.right, place: r.place })
          }
        })
        made += planned.length
        selection = tm.shift(selection, planned)
      } catch (error) {
        if (made === 0) {
          await restore().catch(() => {})
          throw error
        }
        notes.push(`Stopped at edit ${i + 1} of ${edits.length}: ${error.message}`)
        break
      }
    }
    await restore()
    if (notes.length === 0) {
      const now = await readModel(context, { reviewed })
      if (tm.FoldedText.fold(now.text) !== tm.FoldedText.fold(simulated.text)) {
        notes.push(`${name} doesn't read back exactly as expected; ask them to check it.`)
      }
    }
    const data = {
      changes: tm.changesData(changes),
      changeCount: made,
      tracked: track,
      // commentTexts: so AppleScript can find them when the add-in is gone.
      undo: { changes: undoChanges, comments, commentTexts, tracked: track },
    }
    if (notes.length) data.notes = notes
    return data
  })
}

// MARK: - word.undo

/**
 * Takes back one word.edit: PAL's tracked changes rejected where they still
 * stand (WordApi 1.6), else PAL's text found near where it was put and the
 * old text put back; its comments deleted. What the person has changed since
 * is left and said.
 */
export async function wordUndo(env, args = {}) {
  const { Word, supports } = env
  const undo = args.undo || {}
  const changes = Array.isArray(undo.changes) ? undo.changes : []
  const commentIds = Array.isArray(undo.comments) ? undo.comments : []
  const tracked = undo.tracked !== false
  if (!supports('WordApi', '1.4')) throw unsupported('This Word is older than WordApi 1.4.')
  if (tracked && changes.length > 0 && !supports('WordApi', '1.6')) {
    throw unsupported("This Word can't reject tracked changes from PAL for Office (WordApi 1.6).")
  }
  const name = env.docName() || 'the document'
  return Word.run(async (context) => {
    const doc = context.document
    const body = doc.body
    doc.load('changeTrackingMode')
    await context.sync()
    const wasMode = doc.changeTrackingMode
    // Taking a change back is not itself a tracked change.
    if (wasMode !== 'Off') doc.changeTrackingMode = 'Off'
    let undone = 0
    let missed = 0
    const notes = []
    try {
      for (const change of [...changes].reverse()) {
        const record = {
          offset: change.start ?? 0, old: change.old || '', new: change.text || '',
          left: change.left || '', right: change.right || '',
        }
        const model = await readModel(context, { reviewed: true })
        const found = tm.locate(record, model.text)
        if (!found) {
          missed += 1
          continue
        }
        const locator = new Locator(context, model, { reviewed: true, name })
        const [range] = await locator.ranges([found])
        let deletion = null
        let insertion = null
        if (tracked) {
          if (record.new) {
            const within = range.getTrackedChanges()
            within.load('items/type,items/text')
            const before = body.getRange('Start').expandTo(range.getRange('Start')).getTrackedChanges()
            before.load('items/type,items/text')
            await context.sync()
            insertion = within.items.find((t) => t.type === 'Added'
              && tm.FoldedText.fold(plain(t.text)) === tm.FoldedText.fold(record.new)) || null
            if (record.old) {
              deletion = [...before.items].reverse().find((t) => t.type === 'Deleted'
                && tm.FoldedText.fold(plain(t.text)) === tm.FoldedText.fold(record.old)) || null
            }
          } else if (record.old) {
            const before = body.getRange('Start').expandTo(range).getTrackedChanges()
            before.load('items/type,items/text')
            await context.sync()
            deletion = [...before.items].reverse().find((t) => t.type === 'Deleted'
              && tm.FoldedText.fold(plain(t.text)) === tm.FoldedText.fold(record.old)) || null
          }
        }
        if (insertion && (deletion || !record.old)) {
          insertion.reject()
          if (deletion) deletion.reject()
        } else if (!record.new && deletion) {
          deletion.reject()
        } else if (deletion) {
          // The person accepted PAL's text: the old text comes back by
          // rejecting its deletion, and PAL's goes by hand.
          deletion.reject()
          range.delete()
        } else if (record.new) {
          if (insertion) {
            // The person accepted the deletion: the old text goes back in
            // front of PAL's, then PAL's insertion is rejected.
            if (record.old) range.insertText(record.old, 'Before')
            insertion.reject()
          } else if (record.old) {
            range.insertText(record.old, 'Replace')
          } else {
            range.delete()
          }
        } else {
          range.insertText(record.old, 'Start')
        }
        await context.sync()
        undone += 1
      }
      if (commentIds.length) {
        const list = body.getComments()
        list.load('items/id')
        await context.sync()
        let gone = 0
        for (const id of commentIds) {
          const comment = list.items.find((c) => c.id === id)
          if (comment) {
            comment.delete()
            undone += 1
          } else {
            gone += 1
          }
        }
        await context.sync()
        if (gone) {
          notes.push(gone === 1 ? 'The comment PAL added had already been removed.'
            : `${gone} comments PAL added had already been removed.`)
        }
      }
    } finally {
      if (wasMode !== 'Off') {
        doc.changeTrackingMode = wasMode
        await context.sync()
      }
    }
    if (missed) {
      notes.unshift(missed === changes.length
        ? "PAL's changes had all been changed since, so they were left as they are."
        : `${missed} of PAL's ${changes.length} changes had been changed since, so they were left as they are.`)
    }
    return { undone, notes }
  })
}
