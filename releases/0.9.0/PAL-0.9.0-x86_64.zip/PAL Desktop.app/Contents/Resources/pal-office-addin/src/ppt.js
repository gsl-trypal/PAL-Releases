// PowerPoint through Office.js: ppt.read, ppt.edit, ppt.undo, as far as
// PowerPointApi goes on the Mac: shapes' text (1.4), titles and bodies
// (placeholder types with 1.8, else the shapes' names), adding slides (1.3;
// anywhere but the end needs `moveTo`, 1.8). Speaker notes have no API, so
// set_notes, add_slide with notes, and reading notes answer `unsupported`
// (or say so) and the Mac uses AppleScript. PAL never deletes the person's
// slides and never saves.

import { OpError, unsupported } from './errors.js'
import * as tm from './text-match.js'

const TEXT_TYPES = new Set(['GeometricShape', 'TextBox', 'Placeholder'])
const TITLE_TYPES = new Set(['Title', 'CenterTitle', 'VerticalTitle'])
const BODY_TYPES = new Set(['Body', 'Subtitle', 'Content', 'VerticalBody', 'VerticalContent'])

/** PowerPoint's paragraph break as Office.js writes it (to verify live). */
export const PARAGRAPH_BREAK = '\n'

/** title | body | shape, from a placeholder type when there is one, else the shape's name. */
export function partOf(shape, placeholderType) {
  if (placeholderType) {
    if (TITLE_TYPES.has(placeholderType)) return 'title'
    if (BODY_TYPES.has(placeholderType)) return 'body'
    return 'shape'
  }
  const name = shape.name || ''
  if (/^(center |centre )?title\b/i.test(name)) return 'title'
  if (/^(subtitle|content placeholder|text placeholder|body)\b/i.test(name)) return 'body'
  return 'shape'
}

export function label(slide, part, index) {
  return part === 'title' || part === 'body' || part === 'notes' ? `slide ${slide} ${part}` : `slide ${slide} text box ${index}`
}

function needs(env, version = '1.4') {
  if (!env.supports('PowerPointApi', version)) throw unsupported(`This PowerPoint is older than PowerPointApi ${version}.`)
}

/** Every slide's text parts: [{part, index (1-based shape number), shapeId, text, shape}] per slide. */
export async function readDeck(context, env) {
  const placeholders = env.supports('PowerPointApi', '1.8')
  const slides = context.presentation.slides
  slides.load('items/id')
  await context.sync()
  const lists = slides.items.map((s) => {
    const shapes = s.shapes
    shapes.load('items/id,items/name,items/type')
    return shapes
  })
  await context.sync()
  const reads = []
  lists.forEach((list, si) => list.items.forEach((shape, j) => {
    if (!TEXT_TYPES.has(shape.type)) return
    const range = shape.textFrame.textRange
    range.load('text')
    const ph = placeholders && shape.type === 'Placeholder' ? shape.placeholderFormat : null
    if (ph) ph.load('type')
    reads.push({ si, j, shape, range, ph })
  }))
  if (reads.length) await context.sync()
  const parts = slides.items.map(() => [])
  for (const r of reads) {
    parts[r.si].push({
      part: partOf(r.shape, r.ph ? r.ph.type : null), index: r.j + 1, shapeId: r.shape.id,
      text: r.range.text || '', shape: r.shape,
    })
  }
  return { slides: slides.items, ids: slides.items.map((s) => s.id), parts }
}

// MARK: - The plan (SlidesModel.swift)

/** The deck's text as the edits leave it, worked out before anything changes. */
export class SlidesModel {
  constructor(parts, name) {
    this.slides = parts.map((list) => list.map((p) => ({ ...p })))
    this.name = name
  }

  get count() { return this.slides.length }

  bullets(text) {
    return tm.FoldedText.fold(text).split('\n').join(PARAGRAPH_BREAK)
  }

  checkSlide(slide) {
    if (!(slide >= 1 && slide <= this.count)) {
      throw new OpError('not_found', `${this.name} has no slide ${slide}; it has ${this.count}.`)
    }
  }

  plan(edit) {
    switch (edit.op) {
      case 'replace_text': {
        const { find, text, slide, all } = edit
        if (slide) this.checkSlide(slide)
        const hits = []
        this.slides.forEach((parts, i) => {
          if (slide && slide !== i + 1) return
          parts.forEach((part, j) => {
            const folded = new tm.FoldedText(part.text)
            const found = folded.matches(find)
            if (found.length) hits.push({ slide: i + 1, part: j, found, folded })
          })
        })
        const total = hits.reduce((n, h) => n + h.found.length, 0)
        const quoted = tm.quote(find)
        const where = slide ? `slide ${slide} of ${this.name}` : this.name
        if (!total) {
          throw new OpError('not_found', `${quoted} isn't on ${where}.`,
            { nextStep: 'Read the slides again and quote the text exactly as it is.' })
        }
        if (total > 1 && !all) {
          const candidates = hits.flatMap((h) => h.found.map((m) => `slide ${h.slide}: ${tm.snippet(m, h.folded)}`))
          throw new OpError('ambiguous', `${quoted} is on ${where} ${tm.times(total)}.`,
            { candidates: candidates.slice(0, 5), nextStep: 'Quote more of it, name the slide, or give `all`.' })
        }
        return hits.map((h) => {
          const part = this.slides[h.slide - 1][h.part]
          const list = h.found.map((m) => {
            const r = h.folded.originalRange(m.location, m.length)
            return { range: r, old: part.text.slice(r.location, r.location + r.length), new: text }
          })
          const next = tm.apply(list, part.text)
          const step = { kind: 'text', slide: h.slide, part: part.part, index: part.index, shapeId: part.shapeId, old: part.text, new: next }
          part.text = next
          return step
        })
      }
      case 'set_title': return this.set(edit.slide, 'title', edit.text)
      case 'set_body': return this.set(edit.slide, 'body', this.bullets(edit.text))
      case 'set_notes':
        throw unsupported("PowerPoint's Office.js has no speaker notes.")
      case 'add_slide': {
        if (edit.notes) throw unsupported("PowerPoint's Office.js has no speaker notes.")
        const at = edit.after ?? this.count
        if (!(at >= 0 && at <= this.count)) {
          throw new OpError('not_found', `${this.name} has no slide ${at} to add after; it has ${this.count}.`)
        }
        const body = edit.body ? this.bullets(edit.body) : null
        this.slides.splice(at, 0, [
          { part: 'title', index: 0, text: edit.title },
          { part: 'body', index: 0, text: body || '' },
        ])
        return [{ kind: 'add', after: at, title: edit.title, body }]
      }
      default:
        throw new OpError('invalid', `${edit.op} isn't an op PAL knows.`)
    }
  }

  set(slide, part, text) {
    this.checkSlide(slide)
    const found = this.slides[slide - 1].find((p) => p.part === part)
    if (!found || !found.shapeId) {
      // No box Office.js can tell is the title or body: AppleScript knows placeholders.
      throw unsupported(`PAL for Office can't tell which box is slide ${slide}'s ${part}.`)
    }
    const step = { kind: 'text', slide, part, index: found.index, shapeId: found.shapeId, old: found.text, new: text }
    found.text = text
    return [step]
  }
}

/** One mac.slides.edit edit, checked as SlideEdit.init does. */
export function parseEdit(item, index) {
  const at = `edits[${index}]`
  const slide = Number.isInteger(item.slide) ? item.slide : null
  const text = typeof item.text === 'string' ? item.text : ''
  switch (item.op) {
    case 'replace_text':
      if (!item.find) throw new OpError('invalid', `${at} has nothing to find.`)
      return { op: 'replace_text', find: item.find, text, slide, all: item.all === true }
    case 'set_title': return { op: 'set_title', slide: slide ?? 1, text }
    case 'set_body': return { op: 'set_body', slide: slide ?? 1, text }
    case 'set_notes': return { op: 'set_notes', slide: slide ?? 1, text }
    case 'add_slide':
      return {
        op: 'add_slide', after: Number.isInteger(item.after) ? item.after : null,
        title: typeof item.title === 'string' ? item.title : '',
        body: typeof item.body === 'string' ? item.body : null,
        notes: typeof item.notes === 'string' ? item.notes : null,
      }
    default:
      throw new OpError('invalid', `${at} has no op PAL knows.`)
  }
}

// MARK: - ppt.read

export async function pptRead(env) {
  needs(env)
  return env.PowerPoint.run(async (context) => {
    const deck = await readDeck(context, env)
    const slides = deck.parts.map((parts, i) => ({
      n: i + 1,
      title: (parts.find((p) => p.part === 'title') || {}).text || '',
      body: parts.filter((p) => p.part !== 'title').map((p) => p.text).join('\n'),
      notes: '',
    }))
    const text = deck.parts.map((parts, i) =>
      [`--- Slide ${i + 1} ---`, ...parts.map((p) => p.text).filter(Boolean)].join('\n')).join('\n')
    return { slides, text, notesRead: false }
  })
}

// MARK: - ppt.edit

/** The layout a new slide takes: "Title and Content" when the master has it by that name. */
async function pickLayout(context) {
  const masters = context.presentation.slideMasters
  masters.load('items/id')
  await context.sync()
  const master = masters.items[0]
  if (!master) return {}
  const layouts = master.layouts
  layouts.load('items/id,items/name')
  await context.sync()
  const byName = (re) => layouts.items.find((l) => re.test(l.name || ''))
  const layout = byName(/^title and content$/i) || byName(/title.*content|title.*text|title.*body/i)
  return layout ? { slideMasterId: master.id, layoutId: layout.id } : { slideMasterId: master.id }
}

export async function pptEdit(env, args = {}) {
  needs(env)
  const items = Array.isArray(args.edits) ? args.edits : []
  if (!items.length) throw new OpError('invalid', 'edits is empty.')
  const edits = items.map(parseEdit)
  const name = env.docName() || 'the presentation'
  return env.PowerPoint.run(async (context) => {
    const deck = await readDeck(context, env)
    const model = new SlidesModel(deck.parts, name)
    const count = model.count
    const steps = edits.flatMap((e) => model.plan(e))
    // Adding a slide anywhere but the end needs moveTo (PowerPointApi 1.8).
    let running = count
    for (const step of steps) {
      if (step.kind !== 'add') continue
      if (step.after < running && !env.supports('PowerPointApi', '1.8')) {
        throw unsupported("This PowerPoint can't put a new slide in the middle from PAL for Office (PowerPointApi 1.8).")
      }
      running += 1
    }
    const ids = [...deck.ids]
    const changes = []
    const added = []
    const notes = []
    const undo = { texts: [], added: [] }
    let seq = 0
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i]
      try {
        seq += 1
        if (step.kind === 'text') {
          const slide = context.presentation.slides.getItem(ids[step.slide - 1])
          const shape = slide.shapes.getItem(step.shapeId)
          const range = shape.textFrame.textRange
          range.load('text')
          await context.sync()
          if (tm.FoldedText.fold(range.text || '') !== tm.FoldedText.fold(step.old)) {
            throw new OpError('changed', `${label(step.slide, step.part, step.index).replace(/^./, (c) => c.toUpperCase())} changed while PAL was editing.`,
              { nextStep: 'Read the slides again, then try again.' })
          }
          range.text = step.new
          await context.sync()
          undo.texts.push({
            seq, slideId: ids[step.slide - 1], shapeId: step.shapeId, part: step.part, index: step.index,
            slide: step.slide, old: step.old, new: step.new,
          })
          changes.push({ where: label(step.slide, step.part, step.index), before: step.old, after: step.new })
        } else {
          const layout = await pickLayout(context)
          const slides = context.presentation.slides
          slides.add(layout)
          await context.sync()
          slides.load('items/id')
          await context.sync()
          const fresh = slides.items.find((s) => !ids.includes(s.id)) || slides.items[slides.items.length - 1]
          if (step.after < ids.length) {
            fresh.moveTo(step.after)
            await context.sync()
          }
          ids.splice(step.after, 0, fresh.id)
          const number = step.after + 1
          undo.added.push({ seq, slideId: fresh.id, title: step.title, number })
          added.push(number)
          changes.push({ where: `slide ${number} (new)`, before: '', after: step.title })
          const shapes = fresh.shapes
          shapes.load('items/id,items/name,items/type')
          await context.sync()
          const reads = shapes.items.filter((s) => TEXT_TYPES.has(s.type)).map((s) => {
            const ph = env.supports('PowerPointApi', '1.8') && s.type === 'Placeholder' ? s.placeholderFormat : null
            if (ph) ph.load('type')
            return { s, ph }
          })
          await context.sync()
          const title = reads.find((r) => partOf(r.s, r.ph ? r.ph.type : null) === 'title')
          const body = reads.find((r) => partOf(r.s, r.ph ? r.ph.type : null) === 'body')
          if (!title) throw new OpError('app_error', `The new slide ${number} has no title box.`)
          title.s.textFrame.textRange.text = step.title
          if (step.body) {
            if (!body) throw new OpError('app_error', `The new slide ${number} has no body box.`)
            body.s.textFrame.textRange.text = step.body
          }
          await context.sync()
        }
      } catch (error) {
        if (undo.texts.length + undo.added.length === 0) throw error
        notes.push(`Stopped at step ${i + 1} of ${steps.length}: ${error.message}`)
        break
      }
    }
    const data = {
      changes: tm.changesData(changes),
      changeCount: changes.length,
      added,
      undo,
    }
    if (notes.length) data.notes = notes
    return data
  })
}

// MARK: - ppt.undo

export async function pptUndo(env, args = {}) {
  needs(env)
  const undo = args.undo || {}
  const steps = [
    ...(undo.texts || []).map((t) => ({ kind: 'text', ...t })),
    ...(undo.added || []).map((a) => ({ kind: 'added', ...a })),
  ].sort((a, b) => (b.seq ?? 0) - (a.seq ?? 0))
  return env.PowerPoint.run(async (context) => {
    const slides = context.presentation.slides
    slides.load('items/id')
    await context.sync()
    const notes = []
    let undone = 0
    let kept = 0
    for (const step of steps) {
      const slide = slides.items.find((s) => s.id === step.slideId)
      if (step.kind === 'text') {
        if (!slide) { kept += 1; continue }
        const shapes = slide.shapes
        shapes.load('items/id')
        await context.sync()
        const shape = shapes.items.find((s) => s.id === step.shapeId)
        if (!shape) { kept += 1; continue }
        const range = shape.textFrame.textRange
        range.load('text')
        await context.sync()
        if (tm.FoldedText.fold(range.text || '') !== tm.FoldedText.fold(step.new || '')) { kept += 1; continue }
        range.text = step.old || ''
        await context.sync()
        undone += 1
      } else {
        let gone = false
        if (slide) {
          const shapes = slide.shapes
          shapes.load('items/id,items/name,items/type')
          await context.sync()
          const reads = shapes.items.filter((s) => TEXT_TYPES.has(s.type)).map((s) => {
            const r = s.textFrame.textRange
            r.load('text')
            return r
          })
          await context.sync()
          if (reads.some((r) => tm.FoldedText.fold(r.text || '') === tm.FoldedText.fold(step.title || ''))) {
            slide.delete()
            await context.sync()
            undone += 1
            gone = true
          }
        }
        if (!gone) notes.push(`PAL left the slide it added as slide ${step.number}: it has changed since.`)
      }
    }
    if (kept) notes.unshift(`${kept} text${kept === 1 ? ' had' : 's had'} been changed since, so PAL left ${kept === 1 ? 'it' : 'them'}.`)
    return { undone, notes }
  })
}
