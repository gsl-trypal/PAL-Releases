# Browser jobs

How each KIND of web job is done, on any site. pal-harness reads this file
(lib/jobs.js) when the assistant hands a task to the `browser` sub-agent,
picks the first job below whose `match` phrases appear in {{name}}'s own words
for the task (the task itself when it carries none of {{his}} words), and adds
that job's text to the task under a `[JOB: …]` heading. When the browser comes
back, the job's `### After` text goes to the assistant with the result.

Why this file exists: until 2026-09-30 everything the browser knew about a job
was either in browser.md (written around one car insurance form) or in a
per-site recipe (a list of selectors, learned one site at a time). A job here
is neither: it is what a quote, an application or a booking IS, whatever site
it happens on. Site recipes and notes still speed a job up where they exist.

Format, one section per job, in the order they are tried (first match wins):

    ## <name> — <title>
    match: comma-separated phrases, matched as whole words, any case
    also: phrases that pick the job only when no job's match does (optional)
    intent: phrases that ask for the job itself ("book a")       (optional)
    look: phrases that ask what is on offer ("see if", "any")    (optional)
    ends in: submit | book | cancel | none   (the one click that sends it)
    strict: yes | no                         (answers are statements in {{name}}'s name)

    What the browser is told.

    ### After
    What the assistant is told when the browser comes back.

    ### Look
    What the browser is told instead when it is only a look (optional).

    ### After look
    What the assistant is told when a look comes back.

A job with `look:` phrases and a `### Look` is only a look when {{name}}'s
words have a look phrase and no intent phrase ("I haven't booked" is not
one), or when {{he}} or the task says not to do it ("don't book"). On
2026-10-28 "see if there are any tables available tonight" was made a
booking: the browser held a table and typed {{his}} details in before {{he}}
declined the Submit. Asking whether it CAN be done is a look too ("see if we
can book a table", "check whether they could reserve one"): on 2026-11-05 its
"book a" made one a booking, twice over.

Keep each job short: it is added to the browser's task, and every word is paid
for on every step of the job.

Written for whoever's assistant this is: `{{name}}`, `{{he}}`, `{{him}}` and
`{{his}}` are lib/person.js tokens, filled in each time the file is read
(George, he, him, his on George's box — exactly the words that were here).

## cancel — Cancel or stop something
match: cancel, cancellation, unsubscribe from, end my subscription, end my membership, close my account, stop my subscription, turn off auto-renew, turn off auto renew, stop auto-renewal, stop the direct debit, leave my contract
ends in: cancel
strict: yes

1. Find the way to cancel on the site itself: the account area, "Manage
   subscription", "Membership", or the help page that names it. If you need to
   be signed in and are not, hand the sign-in to {{name}} with `browser_handoff`
   ("Sign in to <site>, then tap Done") — never type a password.
2. A site may offer a discount or a pause to keep {{him}}. Never accept one. If it
   asks why {{he}} is leaving and the task does not say, ask {{name}} with the
   `question` tool, offering the page's own reasons.
3. The last click that cancels goes through `browser_commit`, with `what`
   naming what ends and when, if the page says.
4. Capture the confirmation with `browser_capture` (`section`, name
   "confirmation"): the end date, any reference number, any final charge.

### After
Tell {{name}} what was cancelled and when it ends, from the captured
confirmation. If it names an end date or a final bill, offer one reminder for
it — only set it if {{he}} says yes.

## get-document — Find or download a document
match: download, statements, bank statement, my statement, latest statement, invoice, receipt, my bill, latest bill, the bill, bills, policy documents, policy document, certificate, payslip, tax return, my documents, proof of
ends in: none
strict: no

1. The document is usually behind a sign-in. If you need to be signed in and
   are not, hand the sign-in to {{name}} with `browser_handoff` ("Sign in to
   <site>, then tap Done") — never type a password.
2. Find the list the site keeps ("Bills", "Statements", "Documents"), and
   capture it with `browser_capture` (`like`, name "documents"): each
   document's name and date.
3. Keep the one the task asks for with `browser_save`, `link` set to the ref
   of its download link, and report the path it gives back. If it cannot be
   fetched, open it and report its page's url. Nothing in this job is sent:
   never use `browser_commit`.

### After
Tell {{name}} which document it is and where it is now — the path in {{his}} Files
the browser reported, or the url — from the captured list. Offer to fetch it again when the next one is due, if the list shows a
pattern (monthly, yearly) — only set a reminder if {{he}} says yes.

## apply — Apply, register, claim or request something
match: apply for, apply to, apply online, application, register for, sign up for, permit, parking voucher, visitor voucher, passport, blue badge, tv licence, licence application, renew my licence, claim for, make a claim, submit a claim, council tax, report a problem, report a fault, report a missed, report a pothole, request a refund, request a copy, update my address, change my address, change my details, enrol, enroll, onboarding, onboard, wizard, fill in the form, fill out the form, fill in this form, fill out this form, fill in a form, fill out a form, complete the form, complete this form, complete the onboarding, complete the information, fill in the information, registration form, sign-up form, signup form, questionnaire
also: portal, the form, a form, this form
ends in: submit
strict: yes

1. Go through the form the way the site leads you. Every answer comes from the
   task, the Vault (`browser_vault_list`, then `browser_fill_from`) or {{name}}
   (the `question` tool) — never from you. A form of many sections on one
   page (an onboarding portal) often has a Save or "Submit Information" under
   each: press it once that section is answered — it keeps the answers and
   sends nothing. Do not read a section again once it is done.
2. Most forms end on a "Check your answers" or summary page. Capture all of
   it with `browser_capture` (`page: true`, name "answers") before you send
   anything.
3. If the form wants a document uploaded (proof of address, a photo) and your
   task names the file, give it with `browser_upload_from` (the upload
   button's ref and the path as the task gave it). If the task names none,
   stop on that page and report which document it wants and in what format.
4. The final Submit / Send / Declare goes through `browser_commit`, with `what`
   saying what is applied for and to whom. It waits for {{name}}'s OK.
5. After it, capture the confirmation (`section`, name "confirmation"): the
   reference number and anything it says happens next. Keep the page too, with
   `browser_save` (name "<what was applied for> confirmation").

### After
Give {{name}} the reference number and what happens next, from the captured
confirmation, word for word. If it gives a date {{he}} must act by, or a date to
expect an answer, offer a reminder — only set it if {{he}} says yes.

## book — Book an appointment, a slot, a table or tickets
match: book a, book an, book me, book the, book it, book in, booking, reserve a, reservation, appointment, a table for, tickets for, a slot, availability for
intent: book a, book an, book me, book us, book the, book it, book in, book one, book that, book this, reserve a, reserve the, reserve me, reserve us, make a booking, make a reservation, get me a table, get us a table
look: see if, see whether, see what, check if, check whether, check for, check what, have a look, take a look, look at, look for, any tables, any table, any slots, any appointments, any availability, is there, are there, what times, which times, what's available, available, availability, free
ends in: book
strict: no

1. Find the times or dates on offer first, and capture them with
   `browser_capture` (`like`, name "slots") before you choose one.
2. If the task names a slot the page has, use it. If it names none, or the one
   it names is gone, ask {{name}} with the `question` tool: the page's own slots,
   copied exactly, as the options. Never pick one for {{him}}.
3. Fill in who the booking is for from the Vault (`browser_fill_from`).
4. The click that books goes through `browser_commit`, with `what` naming the
   place, the date and the time. A booking that needs paying stops at the pay
   button by itself.
5. Capture the confirmation (`section`, name "booking"): reference, date, time,
   place. Keep the page with `browser_save` (name "<place> booking").

### After
Give {{name}} the booking from the captured confirmation — place, date, time,
reference. Offer to put it in {{his}} calendar or set a reminder the day before;
only do it if {{he}} says yes.

### Look
{{name}} asked what is on offer, not for a booking. Do step 1 only: find
the times or dates, capture them (`browser_capture`, name "slots") and report
them. Do not pick a slot, ask {{him}} to pick one, fill anything in or use
`browser_commit`. Leave the page where it is: if {{he}} then picks one, the
assistant sends you back here to book it, and the steps below apply from step 2.

### After look
Give {{name}} the captured slots exactly as they are, and ask whether to book
one. If {{he}} names one, send the browser back to this page with the same
task_id and that slot, rather than starting again.

## quote — Get a quote or a renewal price
match: a quote, quote for, quotes for, get quotes, get me quotes, quotation, renewal price, renewal quote, how much would it cost, how much to insure, insurance, insure, premium, broadband deal, energy deal, switch supplier, mortgage rates
ends in: submit
strict: yes

1. Answers on a quote form are statements made in {{name}}'s name: every one
   comes from the task, the Vault or {{name}}, never from you. Check the Vault
   (`browser_vault_list`) before the first page, and ask {{name}} with the
   `question` tool for anything neither the task nor the Vault answers.
2. Most quote forms end on a summary or an assumptions page. Capture all of
   it (`browser_capture`, `page: true`, name "answers") before you ask for
   prices.
3. The click that gets the prices ("Get my quotes", "See prices", "Calculate")
   goes through `browser_commit`, with `what` naming the site and what is being
   quoted for. If it comes back "ask {{name}} first", ask {{him}} those answers in
   one `question` call, put in what {{he}} says, and send it again. Then it waits
   for {{his}} OK.
4. On the results, capture every quote with `browser_capture` (`like` with one
   quote's card or row, name "quotes"), and the quote reference if the page
   shows one.
5. Never choose, buy or "Continue" with a quote. Stop on the results page.

### After
Give {{name}} the captured quotes as they are, cheapest first only if the page
listed them that way. Say which answers came from where, from the recorded
list, and name any answer the browser chose. If the site or {{his}} documents
show a renewal or expiry date, offer a reminder three weeks before it — only
set it if {{he}} says yes.

## compare — Compare prices or options
match: compare, comparison, cheapest, best price, best deal, lowest price, price of, prices for, how much is, how much are
ends in: none
strict: no

1. Work through the sites the task names, or find them with `browser_search`.
   On each, find the item the task describes and check it is the same thing
   (size, model, quantity) before you compare it. On a list of results,
   `browser_listing` reads every card and the site's filters in one call.
2. Capture the prices on each site with `browser_capture`, one capture per
   site, named for it ("prices — tesco.com").
3. Nothing in this job is sent or bought: never use `browser_commit`, and stop
   before any basket or checkout.

### After
Compare only what was captured: one line per site, in the page's own words and
prices. Say plainly where the items were not the same thing.

## find — Find products or options that match what {{name}} wants
match: find me, looking for, look for, shop for, shopping for, to buy, buy me, in a size, in size, a size, in a small, in a medium, in a large, size small, size medium, size large, colours, colors, colour, color, brands, brand, in stock, for sale, available in, options for
ends in: none
strict: no

1. Every site the task names, one at a time — never drop one. Find each by
   searching for what is wanted in its words ("Reiss men's slim fit shirts"),
   and open the result whose title already names it (a "Men's Slim Fit
   Shirts" page) over the home page.
2. On the list, put on the site's own filters for everything asked that it
   filters by — size, fit, colour, sleeve, price — one click each. Call
   `browser_listing`: it shows the filter groups with their refs (a closed
   group opens with one click), then read the filtered list once with it.
3. Judge each card from what it shows. Open a product page only for a fact no
   card shows (a sleeve length, whether a size is in stock): at most about
   three per site.
4. Keep every match with `browser_found` the moment you know it (`card` = its
   number in the listing). Every option asked for — each colour, each size —
   that a site has no match for goes in `none`, so the report says so.
5. About 5 good matches is the first answer {{name}} wants. Spread them over
   the sites named — two or three from each filtered list, not five from the
   first — and once 5 are kept, stop and report them with what you have not
   covered yet (a site not searched, an option not found so far). If {{he}}
   wants more, the task carries on: the next ones, never one already kept.
6. A site that answers "Access Denied" or blocks the browser is done: keep
   what you found there, say so, and go on to the next site.
7. Nothing here is bought or sent: never `browser_commit`, and stop before
   any basket.

### After
Give {{name}} what was found on each site from the kept list, with each link
exactly as kept. Say plainly which asked-for options (a colour, a size) had no
match on which site, and which sites blocked the browser or were not reached.
When PAL's note says the browser stopped at its first few, ask {{him}} whether
to look for more, as the note says.
