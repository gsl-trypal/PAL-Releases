/*
 * pal-harness — the assistant's behaviour, as an opencode plugin.
 *
 * This replaces the whole SemaClaw hook stack. Each piece maps 1:1:
 *
 *   semaclaw/hooks/router.js        (UserPromptSubmit) -> "chat.message"
 *   semaclaw/hooks/tool-gate.js     (PreToolUse)       -> "tool.execute.before"
 *   semaclaw/hooks/bash-classify.js (helper)           -> unchanged, verbatim
 *   semaclaw-plugins/pal-notation   (4 async hooks)    -> "event"
 *
 * FIVE THINGS HERE ARE LOAD-BEARING, each one paid for by a wrong answer first
 * (see spikes/opencode-plugin/README.md and ../H0-FINDINGS.md):
 *
 *  1. The turn preamble injects into the USER TURN, not the system prompt. The
 *     same directive appended to the ~19KB system prompt was measured to be
 *     IGNORED by qwen3-coder-30b even phrased as a hard override; adjacent to the
 *     user's own words it is obeyed. That also matches what sema-core's
 *     `additionalContext` actually did. The preamble is [NOW] (lib/now.js — the
 *     model has NO other source for the date) then the router directive, in that
 *     order, so the directive keeps the adjacency it was measured with.
 *  2. It edits an EXISTING text part rather than pushing a new one. A Part is a
 *     rich record (id/sessionID/messageID/…); a bare {type,text} corrupts the
 *     message and the turn dies with an opaque UnknownError.
 *  3. `output.system` is MUTATED IN PLACE, never reassigned. Reassignment
 *     rebinds the property on the hook's own object while the engine keeps the
 *     array it already held — the edit is silently discarded.
 *  4. Trace writes are buffered and async (../plugin/traces.js). The event hook
 *     fires hundreds of times a turn; synchronous I/O there sits in the middle
 *     of the token stream.
 *  5. The gate is `tool.execute.before`, NOT `permission.ask`. That hook is
 *     documented and never fires on 1.18.4 — a gate built on it would silently
 *     never gate.
 */
import { createRequire } from "node:module"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"

const require_ = createRequire(import.meta.url)
const HERE = path.dirname(fileURLToPath(import.meta.url))

// THE HELPERS LIVE IN lib/, AND THAT IS NOT TIDINESS — IT IS REQUIRED.
// opencode discovers plugins by globbing `<config>/opencode/plugin/*.js` and
// loading EVERY match as a plugin, expecting each to default-export a function.
// These four are CommonJS modules, so while they sat beside this file opencode
// logged, on every single boot:
//
//   ERROR "failed to load plugin" path=.../gate.js error="Plugin export is not a function"
//
// four times over, into its own log rather than stdout — which is why it went
// unseen through the H1 spike and the H2 deploy. The glob is not recursive, so
// a subdirectory is the whole fix. Do not move them back up, and do not add a
// second plugin here: one entry point, everything else under lib/.
const { decide, createCounter, mergeGeneratedPolicy, withoutPro, emailCallNudge } = require_("./lib/gate.js")
/* The pro switch (docs/shipping-interfaces.md §2): app creation (lib/made-apps.js
 * and its policy rows) is pro. On unless PAL_PRO is 0; a free bundle is built
 * with esbuild `define: {PAL_PRO: 'false'}`, and its pro branches drop out. */
const PRO = typeof PAL_PRO !== 'undefined' ? PAL_PRO : process.env.PAL_PRO !== '0';
const { createTracer, isNoisy } = require_("./lib/traces.js")
const { classify } = require_("./lib/bash-classify.js")
const { nowBlock } = require_("./lib/now.js")
const { carryMedia } = require_("./lib/media-meta.js")
const { memoryBlock, projectFromBlock, askedToRemember, userWords: memoryWords } = require_("./lib/memory.js")
const { askedToHold, holdKey, notAskedRefusal, repeatRefusal } = require_("./lib/hold-asked.js")
const { asksForYou, asksAboutSelf } = require_("./lib/for-you.js")
const { projectContext, withoutProjectBlock } = require_("./lib/project-context.js")
const { tripNote, tripForTurn } = require_("./lib/trip-context.js")
const { addTitleNote, DEFAULT_TITLE_RE, titleFromBlocks, titleFromWords } = require_("./lib/title-context.js")
const { createQuestionBridge } = require_("./lib/question-bridge.js")
const { createLedger, cutDefaults, defaultsCutNote, questionProblems, resultText, appendToResult, enteredPairs, ENTRY_HOLD_TOOLS, ENTRY_STOP_TOOLS } = require_("./lib/answers-ledger.js")
const { createCaptures, parseFound, kindWords, offKindNote, withoutBlockHeads } = require_("./lib/captures.js")
const { withoutCopiedBlocks } = require_("./lib/copied-blocks.js")
const { stateBlock, isAutoContinue, browserCompactionPrompt, chatFacts, chatStateBlock, chatCompactionPrompt, carryOnText,
  finishedBeforeCompaction } = require_("./lib/task-state.js")
/* A Talk conversation kept small, and answered after a compaction (lib/talk-context.js). */
const { isTalkMessage, isTalkText, trimEarlierToolOutput, talkContinueText } = require_("./lib/talk-context.js")
/* When that cut happens: near a budget, at a kept boundary (lib/tool-trim.js). */
const { acquireToolTrim } = require_("./lib/tool-trim.js")
const { createChatAnswers, pointsElsewhere, lookElsewhereNote, lookElsewhereOnTask } = require_("./lib/chat-answers.js")
const { wordsBlock, limitsOf, limitsInPrompt, limitsStamp, wordsInPrompt, ownText, header: wordsHeader,
        asksForPALsPart, palsPartRefusal, insteadIn, insteadNote, insteadOnTask } = require_("./lib/own-words.js")
const { parseScreen, parseMacContext, taskBlock: screenBlock, taskHeader: screenHeader } = require_("./lib/screen.js")
const { createStepText, closingQuestion, acts, refusal: askFirstRefusal } = require_("./lib/ask-then-act.js")
const { createRefusedCalls, HEAD: REFUSED_HEAD } = require_("./lib/refused-calls.js")
/* "Added", "saved", "a card is waiting", held to what the turn's calls did
 * (lib/done-claims.js). Off with PAL_HARNESS_DONE_CLAIMS=off. */
const { createDoneClaims, checkCard, cardClaims } = require_("./lib/done-claims.js")
const DONE_CLAIMS_ON = process.env.PAL_HARNESS_DONE_CLAIMS !== "off"
const { createAddressBook, editChanges, ranNote, namesAccount } = require_("./lib/addresses.js")
/* Whose assistant this is (lib/person.js): the name and pronouns in the
 * strings this file writes for the model. With no PAL_USER_* set it is George,
 * and every string reads exactly as it did before multi-user. */
const { current: currentPerson, words: personWords } = require_("./lib/person.js")
const who = () => personWords(currentPerson())
/* pal-api's credential (lib/api-headers.js), on every pal-api request below
 * and on none of opencode's own: {} — no header — until a cell token is set. */
const { apiHeaders } = require_("./lib/api-headers.js")
/* A browser job that works through a spreadsheet George gave it: the list is
 * made by code and handed over a row at a time (lib/work-list.js). */
const { attachmentsIn, sourcesIn, rowRange, listBlock, listIdIn, rewriteForBrowser, workListApi, resultLine, pathsNaming, unfiledRefusal } = require_("./lib/work-list.js")
/** The list tools (nas-browser-v2 worklist.mjs): the task's list id is stamped on them (pal_list). */
const LIST_TOOLS = new Set(["playwright_browser_list_next", "playwright_browser_list_done"])
const { actionsMode, searchAlongside, shadowRow, capabilityOf, cardsBlock, cardsFor, cardsOnRoute, harnessContext, recipeCardsFor, recipeCalled } = require_("./lib/actions.js")
/* PAL's hands on the Mac (lib/actions.js, pal-api actions/defs/mac.py): the
 * read cards on a turn about what is open there. */
const { withMacCards, macCardsFor, macChangeOf, createMacChanges, createMacSteps, macWatchOf, createMacWatching } = require_("./lib/actions.js")
/* The chats where PAL changed something on the Mac: "undo that" there is
 * mac.undo (router-core.js macHandsRoute). */
const macChanges = createMacChanges()
/* The chats where PAL is watching the person on the Mac (mac.watch.start):
 * "that's it" there is mac.watch.stop, then hands.learn (Phase 7). */
const macWatching = createMacWatching()
/* The steps a turn has taken in an app on the Mac (mac.ui.*), held to a budget. */
const macSteps = createMacSteps()
const { createStallWatch, reportStalls } = require_("./lib/stall-watch.js")
/* The first step of a new chat read before it is sent (lib/keep-warm.js): the
 * agents' tools + system text replayed into llama.cpp's prompt cache at start,
 * after a llama.cpp restart, after use and every 10 minutes. On only with
 * PAL_HARNESS_WARM=on (cells/cell.yml). */
const { acquireKeepWarm, AGENT_HEADER: WARM_AGENT_HEADER, PROVIDER_HEADER: WARM_PROVIDER_HEADER,
  SIGN_IN_COMMAND: WARM_SIGN_IN_COMMAND } = require_("./lib/keep-warm.js")
/* The warm-up chat (primeWarm, below): its title, in case a chat list catches
 * it in the second it exists, and how long it may take. */
const WARM_PRIMER_TITLE = "Getting PAL ready"
const WARM_PRIMER_TIMEOUT_MS = 60_000
const { browserOutputCap, browserThinkingOff, shortenBrokenCalls, harnessArgsOff, continueReport, withReportAdded, isContinueAsk,
  redoEmptyTurn, withReportReplaced } = require_("./lib/runaway.js")
/* A form's report cut at the browser's output limit, written from PAL's record (lib/capped-report.js). */
const { cappedReportFor } = require_("./lib/capped-report.js")
const { isQuickView, quickWords } = require_("./lib/quick-view.js")
/* A tool call the model wrote into its answer as text (lib/written-calls.js):
 * taken out of the answer and the history, and the step done again once. The
 * redo is off with PAL_HARNESS_WRITTEN_CALL_REDO=off; the cleaning stays. */
const { writtenCalls, withoutWrittenCalls, redoNote, isRedoNote, writtenCallsOff } = require_("./lib/written-calls.js")
const WRITTEN_CALL_REDO_ON = process.env.PAL_HARNESS_WRITTEN_CALL_REDO !== "off"
/* A browser task's step and time budget, by the kind of job, and the sites
 * that blocked it (lib/browser-budget.js; policy.json `browser_budget`). Off
 * with PAL_HARNESS_BROWSER_BUDGET=off. */
const { createBrowserBudget } = require_("./lib/browser-budget.js")
/* Several page actions in one call (lib/browser-steps.js): the hooks below that
 * care about a page action see each action of a list as its own call. */
const { STEPS_TOOL, innerCalls, innerResults, browserBudgetAfter, stepsSection } = require_("./lib/browser-steps.js")
const BROWSER_BUDGET_ON = process.env.PAL_HARNESS_BROWSER_BUDGET !== "off"
/* A browser task compacts with its own short notes prompt instead of opencode's
 * coding-agent template (lib/task-state.js browserCompactionPrompt). Off with
 * PAL_HARNESS_BROWSER_COMPACT=off. */
const BROWSER_COMPACT_ON = process.env.PAL_HARNESS_BROWSER_COMPACT !== "off"
/* What a browser task is told after a compaction instead of opencode's
 * "Continue if you have next steps, or stop and ask for clarification…".
 * Unset (the Evo X2), opencode's own words go out. */
const BROWSER_CONTINUE_TEXT = String(process.env.PAL_HARNESS_BROWSER_CONTINUE || "").trim()
/* A browser task's prompt rebuilt from what code kept once it passes a limit,
 * so the task never reaches opencode's compaction (lib/browser-fresh.js).
 * PAL_HARNESS_BROWSER_FRESH: unset or `on` appends and rebuilds past
 * PAL_HARNESS_BROWSER_FRESH_TOKENS, `every` rebuilds every step, `off` sends
 * the transcript as it is, as before. */
const { createBrowserFresh, browserProgress, freshMode } = require_("./lib/browser-fresh.js")
const BROWSER_FRESH = freshMode()
/* A chat compacts into working notes that keep the request, any draft, the
 * pages read, what was saved and the next step, and is told "Carry on with:
 * <next step>" after it (lib/task-state.js chatCompactionPrompt). For the
 * agents in PAL_HARNESS_CHAT_COMPACT_AGENTS; off with PAL_HARNESS_CHAT_COMPACT=off. */
const CHAT_COMPACT_ON = process.env.PAL_HARNESS_CHAT_COMPACT !== "off"
const CHAT_COMPACT_AGENTS = new Set(String(process.env.PAL_HARNESS_CHAT_COMPACT_AGENTS || "assistant,meeting-notes")
  .split(",").map((s) => s.trim()).filter(Boolean))
/* Earlier turns' tool output is cut in every chat, not only Talk
 * (lib/talk-context.js trimEarlierToolOutput). Off with PAL_HARNESS_TOOL_TRIM=off. */
const TOOL_TRIM_ON = process.env.PAL_HARNESS_TOOL_TRIM !== "off"
/* No "Continue…" after a compaction that followed a finished answer
 * (lib/task-state.js finishedBeforeCompaction). Every agent; off with
 * PAL_HARNESS_NO_CONTINUE_AFTER_STOP=off, which keeps opencode's own. */
const NO_CONTINUE_AFTER_STOP_ON = process.env.PAL_HARNESS_NO_CONTINUE_AFTER_STOP !== "off"
/* The llama.cpp session (`id_slot`) opencode's compaction, title and summary
 * requests go to. Unset (the Evo X2), llama.cpp chooses. */
const UTILITY_SLOT = /^\d+$/.test(String(process.env.PAL_HARNESS_UTILITY_SLOT || "").trim())
  ? Number(process.env.PAL_HARNESS_UTILITY_SLOT) : null
const UTILITY_AGENTS = new Set(["compaction", "title", "summary"])
const { addressesIn, isKnown, knownHosts, dropGuessedAddresses, droppedNote, withoutDroppedNotes, droppedResultNote,
  refusedLookup } = require_("./lib/site-guess.js")
/* A web address the assistant worked out from a name is kept out of browser
 * tasks and recipe lookups (lib/site-guess.js). Off with PAL_HARNESS_SITE_GUESS=off. */
const SITE_GUESS_ON = process.env.PAL_HARNESS_SITE_GUESS !== "off"
/* A name George typed, cut short by the model in a search or a task, is put
 * back as he typed it (lib/cut-names.js). Off with PAL_HARNESS_CUT_NAMES=off. */
const { putBack, createNameBook } = require_("./lib/cut-names.js")
const CUT_NAMES_ON = process.env.PAL_HARNESS_CUT_NAMES !== "off"
/* A browser task for a day nothing in its chat points to is held, once
 * (lib/task-date.js). Off with PAL_HARNESS_TASK_DATE=off. */
const { dayOf, taskDays, offDays, heldNote: dateHeldNote } = require_("./lib/task-date.js")
const TASK_DATE_ON = process.env.PAL_HARNESS_TASK_DATE !== "off"
/* A booking the browser did not make is not told to anyone as made, and an
 * email about a booking says the day booked (lib/booking-claims.js). Off with
 * PAL_HARNESS_BOOKING_CLAIMS=off. */
const { createBookings, claimsBooked, emailClash, clashNote, unmadeNote, reviewClaims } = require_("./lib/booking-claims.js")
const BOOKING_CLAIMS_ON = process.env.PAL_HARNESS_BOOKING_CLAIMS !== "off"
/* An answer that says a draft, an email, an event, a file or a form was
 * saved, sent or changed, held against the calls that ran this turn, and
 * "from your Vault" against the Vault's tools (lib/booking-claims.js
 * reviewClaims). Off with PAL_HARNESS_CLAIM_CHECK=off. */
const CLAIM_CHECK_ON = process.env.PAL_HARNESS_CLAIM_CHECK !== "off"
/* Where each value came from: the person's words or a tool's result, never
 * the assistant's retelling alone (lib/provenance.js). A browser task
 * carrying an identifier nothing in the chat gave is refused, and the
 * answers ledger counts the task's text as a source only with one behind
 * it. Off with PAL_HARNESS_PROVENANCE=off. */
const { createProvenance, unsourcedAgainst, taskRefusal } = require_("./lib/provenance.js")
const PROVENANCE_ON = process.env.PAL_HARNESS_PROVENANCE !== "off"
/* Look-ups go through the API before the browser: on a turn the router called
 * `web_research`, a NEW browser task (or a recipe run) is refused until
 * web_search, web_read or a `research` task has been tried this turn
 * (router-core.js webFirstRefusal). Off with PAL_HARNESS_WEB_FIRST=off. */
const WEB_FIRST_ON = process.env.PAL_HARNESS_WEB_FIRST !== "off"
/* One browser job per chat at a time: a second NEW `browser` task while the
 * chat's first is still running is refused (lib/one-browser-job.js). Off with
 * PAL_HARNESS_ONE_BROWSER_JOB=off. */
const { createOneBrowserJob, busyRefusal } = require_("./lib/one-browser-job.js")
const ONE_BROWSER_JOB_ON = process.env.PAL_HARNESS_ONE_BROWSER_JOB !== "off"
/* A call the gate parked, approved since, goes back to the agent that made it
 * on the chat's next go-ahead (lib/parked-calls.js). Off with
 * PAL_HARNESS_PARKED=off. */
const { isCarryOn, saysGoAhead, createParkedCalls, handBackBlock, subagentAsk } = require_("./lib/parked-calls.js")
const PARKED_ON = process.env.PAL_HARNESS_PARKED !== "off"
/* A browser task's `read` of anything but opencode's overflow files is
 * refused with what to use instead, before opencode's rule dump
 * (lib/read-refusal.js). Off with PAL_HARNESS_READ_REFUSAL=off. */
const { refusesRead, readRefusal } = require_("./lib/read-refusal.js")
const READ_REFUSAL_ON = process.env.PAL_HARNESS_READ_REFUSAL !== "off"
/* The gate waits on a card until it is answered (lib/approval-hold.js). */
const { createApprovalHolds } = require_("./lib/approval-hold.js")
/* One task record per browser task, built by code from George's own words
 * when the task starts and kept under the task's id (lib/task-record.js): what
 * its steps, compactions, resumes and approval cards work from, in place of
 * the assistant's retelling. The libs above fill it and read from it. Off with
 * PAL_HARNESS_TASK_RECORD=off, which puts back each lib's own side channel. */
const { buildRecord, addWords, noteAnswer: noteRecordAnswer, noteClash, forgetKeptSites, clashesIn, nameBookOf, renderRecord, cardOf,
  idIn: recordIdIn, withoutRecords, createTaskRecords, saysKind } = require_("./lib/task-record.js")
const TASK_RECORD_ON = process.env.PAL_HARNESS_TASK_RECORD !== "off"
/* A browser task that ended well becomes a recipe, and a correction in the
 * next turn undoes it (lib/recipe-learn.js; docs/recipes-overhaul-plan.md R4).
 * Off with PAL_HARNESS_RECIPE_LEARN=off. */
const { createRecipeLearn } = require_("./lib/recipe-learn.js")
const RECIPE_LEARN_ON = process.env.PAL_HARNESS_RECIPE_LEARN !== "off"
/* Recipes in the hands of an agent with no page tools (the recipe guard in
 * lib/actions.js, 2026-11-06 demo): a run that stopped is turned into "hand it to `browser`
 * now", the same recipe run again that turn is refused, the assistant's
 * lookups are answered with the way on, and a `browser` lookup by a name it
 * was never shown is a lookup of the site. Off with PAL_HARNESS_FLOW_GUARD=off. */
const { stoppedRun, delegateDirective, rerunRefusal, lookupRefusal, asksAboutRecipes, createFlowNames, siteKey,
  replaceResult } = require_("./lib/actions.js")
const FLOW_GUARD_ON = process.env.PAL_HARNESS_FLOW_GUARD !== "off"
/* A chat title opencode's title model drew from the harness's blocks, not
 * from George's words, is put right from his words (lib/title-context.js,
 * 2026-11-06 demo). Off with PAL_HARNESS_TITLE_CHECK=off. */
const TITLE_CHECK_ON = process.env.PAL_HARNESS_TITLE_CHECK !== "off"
/* A message of fewer words than this is an answer to the assistant: the
 * record carries the message before it too. */
const EARLIER_UNDER_WORDS = 12
/* What counts as trying the API, and what the guard holds back. */
const WEB_LOOKUP_TOOLS = new Set(["palapi_web_search", "palapi_web_read"])
const BROWSER_START_TOOLS = new Set(["playwright_flow_run", "playwright_browser_task"])
/* Shorter descriptions for opencode's bash, task and todowrite, which open
 * every chat (lib/lean-tools.js). Off with PAL_HARNESS_LEAN_TOOLS=off. */
const { leanDescription } = require_("./lib/lean-tools.js")
const LEAN_TOOLS_ON = process.env.PAL_HARNESS_LEAN_TOOLS !== "off"
/* One trace row per tool per process, not one per turn. */
const leanTraced = new Set()

/** The tools that drive the shared browser's pages (not the recipe tools,
 * whose arguments can end up on an approval card). */
const PAGE_TOOL_RE = /^playwright_(?:browser_|flow_run$)/
/* An item number no page showed never becomes a page the browser opens
 * (lib/page-ids.js); off with PAL_HARNESS_PAGE_IDS=off. */
const { createPageIds, madeUpRefusal } = require_("./lib/page-ids.js")
const PAGE_IDS_ON = process.env.PAL_HARNESS_PAGE_IDS !== "off"

/* A browser call that moves its chat into an app, on the desktop, the
 * person's Android or the person's Mac: browser_app open (any app), a
 * navigate to app://…, android://… or mac://…, or a recipe or task for an app
 * (domain app-…, android-… or mac-… — Mac hands Phase 5). */
function opensApp(toolName, args) {
  if (toolName === "playwright_browser_app") return String(args?.action ?? "open") === "open"
  if (toolName === "playwright_browser_navigate") return /^(?:app|android|mac):\/\//i.test(String(args?.url ?? "").trim())
  if (toolName === "playwright_flow_run" || toolName === "playwright_browser_task") {
    return /^(?:app|android|mac)-/.test(String(args?.domain ?? ""))
  }
  return false
}

/** Does `prompt` already carry George's `words` word for word (case, spacing
 * and punctuation aside)? */
function saysWordForWord(prompt, words) {
  const norm = (t) => String(t || "").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim()
  const w = norm(words)
  return Boolean(w) && norm(prompt).includes(w)
}
/* The watch on a browser task whose model has gone quiet (lib/stall-watch.js).
 * Off with PAL_HARNESS_STALL=off. */
const STALL_ON = process.env.PAL_HARNESS_STALL !== "off"
const STALL_CHECK_MS = Number(process.env.PAL_HARNESS_STALL_CHECK_MS || 15_000)
/* "PAL finished" / "PAL couldn't finish" for a chat George walked away from
 * (lib/turn-report.js): every top-level turn that ends is reported to pal-api,
 * which decides by the user's own threshold. Off with PAL_HARNESS_TURN_REPORT=off;
 * `record` (a device's own server, pal-desktop's) reports for Activity only and
 * asks for no push. */
const TURN_REPORT = process.env.PAL_HARNESS_TURN_REPORT || "on"
const TURN_REPORT_ON = TURN_REPORT !== "off"
const TURN_REPORT_EXTRA = TURN_REPORT === "record"
  ? { record_only: true, device: process.env.PAL_DEVICE_ID || "" }
  : {}
const { createTurnReport } = require_("./lib/turn-report.js")
/* The box's telemetry (lib/telemetry.js, docs/shipping-plan.md §7): how fast
 * each chat turn is — time to the first word, tokens a second, the whole turn —
 * to Sentry, per hardware profile, names and numbers only. Loaded only when the
 * box has PAL_SENTRY_DSN; a dev box and the Mac's own opencode child have none,
 * so the Mac's file lists leave it out. Box-only, so a missing or broken file is
 * no telemetry, never a harness without hooks. Null with telemetry off at start;
 * the admin's switch is read again before each report. */
let telemetry = null
if (process.env.PAL_SENTRY_DSN) {
  try {
    telemetry = require_("./lib/telemetry.js").fromEnv(process.env)
  } catch (err) {
    console.error("[pal-harness] telemetry unavailable:", String(err))
  }
}
/* PAL Apps (lib/made-apps.js, docs/pal-apps-plan.md). In an instance whose
 * directory is an app's own folder, <home>/PAL/apps/<id>: a file edit that
 * stays in the folder (and off what opencode runs: dot-names, node_modules,
 * opencode.json) does not ask, a read of anything OUTSIDE the folder does,
 * the model is told which app it is, and each turn's end is reported to
 * pal-api, which keeps it as a version. Off with PAL_HARNESS_MADE_APPS=off:
 * edits there ask again and reads are free again, like anywhere else; with
 * every edit asking, nothing read can reach the app unseen either way.
 *
 * Loaded like the router, so that this helper missing can only mean "off": a
 * Mac child gets just the files OpenCodeHarness.files names, and a helper
 * index.js cannot load there costs the child every hook, the gate included
 * (test/install-lists.test.mjs). Without it no folder is an app's, and every
 * edit asks as before. */
let appRepoOf = () => null
let insideApp = () => ({ inside: false, why: "not an app folder" })
let appContextLine = () => ""
let stampApp = () => null
let readAsk = () => null
let createAppTurns = null
// Pro only: a free build has no made-apps.js, and no folder is an app's.
if (PRO) {
  try {
    ;({ appRepoOf, insideApp, readAsk, stampApp, contextLine: appContextLine, createAppTurns } = require_("./lib/made-apps.js"))
  } catch (err) {
    console.error("[pal-harness] made-apps unavailable (edits in an app's folder ask, as anywhere else):", String(err))
  }
}
const MADE_APPS_ON = PRO && Boolean(createAppTurns) && process.env.PAL_HARNESS_MADE_APPS !== "off"
/* Agents that build one thing in one folder (opencode/agent/app-builder.md),
 * and the two that run unattended on a prompt pal-api wrote (meeting-notes,
 * routine): top-level chats, but none of the everyday assistant's preamble
 * goes to them — no router directive or skill, no [CONNECTORS], [PROJECT],
 * [TRIP] or [MEMORY]. [NOW] still does. ([ACTIONS] cards already go only to
 * the agents that hold the library: lib/actions.js cardsFor.)
 * 16–22 Nov 2026: every meeting merge got a [ROUTER] for Mac edits and the
 * turn-review [SKILL] ("THIS PROCEDURE WINS", call Bash); a single-session
 * meeting got the write-meeting-notes skill and spent two steps on task_create,
 * which it does not hold; each part's prompt carried ~2.4k characters of
 * connectors, trip and memory; and the Weekly NAS changelog routine was told by
 * [ROUTER] to call device_agent_run, which `routine` does not have, and ended
 * CANNOT. */
const LEAN_AGENTS = new Set(String(process.env.PAL_HARNESS_LEAN_AGENTS || "app-builder,meeting-notes,routine").split(",").map((s) => s.trim()).filter(Boolean))
const { loadJobs, pickJob, jobBlock, afterBlock, jobInPrompt, lookInPrompt, onlyALook, asksForIt } = require_("./lib/jobs.js")
const { eventsNear, calendarBlock, afterCalendarBlock, agendaEvents, HEADER: CALENDAR_HEADER } = require_("./lib/calendar-near.js")
const { slotTimes, fitOptions } = require_("./lib/slot-question.js")
/* What a browser task that is only a look (lib/jobs.js onlyALook) may not do
 * until George asks for the job itself: nothing is filled in or sent. */
const LOOK_REFUSED = new Set([
  "playwright_browser_commit", "playwright_browser_fill_page", "playwright_browser_fill_from",
  "playwright_browser_fill_form", "playwright_browser_answer_page", "playwright_browser_upload_from",
  "playwright_browser_new_password",
])
/* browser_set is refused on a look only with a Vault value, which is a fill:
 * a look still sets what it searches by (the dates, the time, how many), as
 * browser_type and browser_select_option do — the very fields that cost the
 * 2026-10-18 parking look two hand-offs. A tick that agrees is held in
 * nas-browser-v2 by George's own limits, as a click's is. */
const lookRefuses = (toolName, args) => LOOK_REFUSED.has(toolName)
  || (toolName === "playwright_browser_set" && /^\s*vault:/i.test(String(args?.value ?? "")))
/* A report's and an answer's links, names and the person's conditions, held
 * against what was actually read (lib/grounding.js, lib/conditions.js). Off
 * with PAL_HARNESS_GROUNDING=off; the answer's footnote alone with
 * PAL_HARNESS_ANSWER_CHECK=off, its names with PAL_HARNESS_ANSWER_NAMES=off. */
const {
  seenFromMessages, mergeSeen, splitTaskResult, unseenLinks, unseenNames, linksIn, markLinks, putBackNear,
  reportNote, answerNote, REPORT_MARK, ANSWER_MARK, ANSWER_HEAD, TASK_ID_RE,
} = require_("./lib/grounding.js")
const { conditionsIn, conditionsBlock, uniqueConditions, reportLines, answerLines, itemsIn, CONDITIONS_HEAD } = require_("./lib/conditions.js")
const GROUNDING_ON = process.env.PAL_HARNESS_GROUNDING !== "off"
const ANSWER_CHECK_ON = GROUNDING_ON && process.env.PAL_HARNESS_ANSWER_CHECK !== "off"
const ANSWER_NAMES_ON = process.env.PAL_HARNESS_ANSWER_NAMES !== "off"
/* The answer waits on this at its last token: past it, it goes out unchecked. */
const ANSWER_CHECK_MS = Number(process.env.PAL_HARNESS_ANSWER_CHECK_MS || 5000)
/* Sub-agents whose reports are what they read: their names are checked too.
 * A creative sub-agent's are its own to make up. */
const READING_AGENTS = new Set(String(process.env.PAL_HARNESS_READING_AGENTS || "browser,research,reader").split(",").map((s) => s.trim()).filter(Boolean))
/* Auto thinking (lib/thinking-auto.js): a message sent on the Thinking chip's
 * Auto gets a thinking pass only when it needs one — a document, a deck,
 * numbers, analysis — and answers straight away otherwise. Off with
 * PAL_HARNESS_THINKING_AUTO=off, which leaves Auto on the variant's own
 * options (the medium budget every turn had before). */
const THINKING_AUTO_ON = process.env.PAL_HARNESS_THINKING_AUTO !== "off"
const { createAutoThinking, wantsAuto } = require_("./lib/thinking-auto.js")

const POLICY_PATH =
  process.env.PAL_HARNESS_POLICY || path.join(HERE, "lib", "policy.json")
const TRACE_FILE = process.env.PAL_HARNESS_TRACE || ""
const API_BASE = (process.env.PAL_API_BASE_URL || "http://pal-api:8000").replace(/\/+$/, "")
const ROUTER_ON = process.env.PAL_HARNESS_ROUTER !== "off"
const GATE_ON = process.env.PAL_HARNESS_GATE !== "off"
/* A step that ends by asking George something may not also change anything
 * (lib/ask-then-act.js). Independent of the gate: it refuses before any card. */
const ASK_THEN_ACT_ON = process.env.PAL_HARNESS_ASK_THEN_ACT !== "off"
/* A call the harness refused never ran: an answer that says it did is marked,
 * with a note of what did not run (lib/refused-calls.js). */
const REFUSED_CHECK_ON = process.env.PAL_HARNESS_REFUSED_CHECK !== "off"
// Per-session call budgets (policy.json `budget`). Independent of the gate
// switch: a budget is a stop on iteration, not an approval, and an eval that
// turns the gate off usually still wants the creative loop to terminate.
const BUDGETS_ON = process.env.PAL_HARNESS_BUDGETS !== "off"
/* The [NOW] block (lib/now.js). ON unless explicitly disabled, and deliberately
 * NOT tied to PAL_HARNESS_ROUTER: turning the router off must not silently take
 * the calendar with it. Its own switch exists only so a date-sensitive eval can
 * reproduce the pre-2026-08-13 behaviour on purpose. */
const NOW_ON = process.env.PAL_HARNESS_NOW !== "off"
/* Deterministic project filing (sessionProject + the fill-if-absent block in
 * tool.execute.before). ON unless explicitly disabled, and NOT tied to
 * PAL_HARNESS_GATE: filing a task under the project the user is looking at is
 * not an approval concern, and turning the gate off for an eval must not
 * silently change where that eval's tasks land. */
const PROJECT_FILING_ON = process.env.PAL_HARNESS_PROJECT_FILING !== "off"
/* The [MEMORY] block (lib/memory.js): what PAL remembers about the user that
 * bears on this message, with where each fact came from. Main-agent turns only
 * — a sub-agent gets the facts it needs in its task text. */
const MEMORY_ON = process.env.PAL_HARNESS_MEMORY !== "off"
/* The [PROJECT] block from pal-api (lib/project-context.js), built from the
 * project the thread is filed under, in place of the client's copy. Main-agent
 * turns only, like [MEMORY]. Off with PAL_HARNESS_PROJECT_CONTEXT=off, which
 * leaves whatever block the client sent exactly as it was. */
const PROJECT_CONTEXT_ON = process.env.PAL_HARNESS_PROJECT_CONTEXT !== "off"
/* The [TRIP] block from pal-api (lib/trip-context.js) while a trip is on. */
const TRIP_CONTEXT_ON = process.env.PAL_HARNESS_TRIP_CONTEXT !== "off"
const APPROVAL_TIMEOUT_S = Number(process.env.PAL_GATE_TIMEOUT_S || 100)
/* A gated call waits on its card until the person answers, however long that
 * takes (lib/approval-hold.js): pal-api holds the card rather than parking it,
 * and the gate comes back for it every PAL_GATE_TIMEOUT_S. Off restores the
 * park after one PAL_GATE_TIMEOUT_S. */
const GATE_HOLD_ON = process.env.PAL_GATE_HOLD !== "off"
/* How far past pal-api's own window the gate's fetch may run. pal-api starts
 * its window only once the card is made and its push sent; with 5 s here,
 * #662 (2026-11-03) was aborted 6 s before pal-api parked it. */
const GATE_FETCH_SLACK_S = 60
/* Short, because this sits in front of a tool call the user is waiting on and
 * its answer is bookkeeping. A slow pal-api costs a filing, never the turn. */
const PROJECT_LOOKUP_TIMEOUT_MS = Number(process.env.PAL_PROJECT_LOOKUP_MS || 2000)
const PERSONA_PATH =
  process.env.PAL_HARNESS_PERSONA || path.join(HERE, "lib", "persona.md")
/* The question bridge (lib/question-bridge.js): every opencode `question` is
 * mirrored into pal-api's approval inbox so it can be answered from the phone
 * or the Mac panel. ON unless disabled; independent of the gate, because a
 * question is not an approval of anything and an eval that turns the gate off
 * still wants the user reachable. The grace window keeps a question the user
 * answers in the chat straight away from ever buzzing their phone. */
const QUESTIONS_ON = process.env.PAL_HARNESS_QUESTIONS !== "off"
/* The record of what the browser entered and where each answer came from
 * (lib/answers-ledger.js). Off with PAL_HARNESS_LEDGER=off. */
const LEDGER_ON = process.env.PAL_HARNESS_LEDGER !== "off"
/* George's answers to the browser's questions, offered for his Vault when a
 * browser task comes back (pal-api vault_answers.py): next time the form is
 * filled from them instead of asking again. Off with PAL_HARNESS_KEEP_ANSWERS=off. */
const KEEP_ANSWERS_ON = process.env.PAL_HARNESS_KEEP_ANSWERS !== "off"
/* What the browser copied off the pages (lib/captures.js), put on the task's
 * result as captured. Off with PAL_HARNESS_CAPTURES=off. */
const CAPTURES_ON = process.env.PAL_HARNESS_CAPTURES !== "off"
/* Browser jobs (lib/jobs.md): how a kind of web job goes on any site, added to
 * the browser's task. Read per task, so an edit is live on the next one. Off
 * with PAL_HARNESS_JOBS=off. */
const JOBS_ON = process.env.PAL_HARNESS_JOBS !== "off"
const JOBS_FILE = process.env.PAL_HARNESS_JOBS_FILE || path.join(HERE, "lib", "jobs.md")
const QUESTION_GRACE_MS = Number(process.env.PAL_HARNESS_QUESTION_GRACE_S ?? 15) * 1000
/* pal-api calls from the bridge are bookkeeping behind a parked turn — short. */
const API_TIMEOUT_MS = Number(process.env.PAL_HARNESS_API_TIMEOUT_MS || 5000)
/* Which opencode process holds a question: the host, stable across restarts of
 * the same container, and a boot id, new every process. A restarted process
 * withdraws the cards its predecessor left (their questions died with it)
 * without touching another host's — the NAS and a Mac's local opencode share
 * one pal-api. */
const QUESTION_ORIGIN = `${process.env.PAL_HARNESS_ORIGIN || os.hostname()}#${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
/* Once per process, not per directory instance: every instance's plugin boots
 * with its own bridge, and only the first boot is the one whose predecessor's
 * questions are stale. */
let questionSweepStarted = false

/* Only an AGENT prompt this large gets replaced by the persona. The
 * system.transform hook also fires for opencode's AUXILIARY model calls —
 * title generation runs a ~2KB prompt through it vs the ~19KB agent prompt
 * (measured in the H1 spike) — and replacing those with the persona breaks
 * them while teaching the titler to answer as PAL. Size is the one signal
 * that separates the two without depending on prompt wording. */
const PERSONA_MIN_PROMPT_CHARS = 8000

/* ...and only when that prompt is opencode's STOCK one. Size alone was the
 * whole test until 2026-09-28, which is fine while the stock prompt is the only
 * big one, and it stopped being that on 2026-08-06 when opencode/agent/*.md
 * started giving agents prompts of their own. opencode builds the system as ONE
 * string, [agent.prompt ?? stock provider prompt, environment, MCP, skills]
 * (LLMRequestPrep.prepare in 1.18.4), so an agent prompt over 8000 chars
 * looked exactly like the stock one and got replaced too. The trace shows every
 * `replaced:true` since 2026-08-11 was assistant.md, and browser.md from
 * 2026-09-28: ~950 model calls that never saw their own instructions, only
 * the 2KB persona.
 *
 * Every stock provider prompt in 1.18.4 (the nine `wd()` picks from by model
 * id) opens "You are opencode" / "You are OpenCode", and no built-in auxiliary
 * prompt (title, compaction, explore, review) does. Our agent prompts open
 * "You are PAL" / "You browse". This DOES depend on wording, which the size
 * test avoided on purpose, but it fails the safe way: if an opencode upgrade
 * rewords the stock opener, the persona stops replacing it (the trace shows
 * `stock:false` with a big promptChars) and no agent prompt is thrown away. */
const STOCK_PROMPT = /^\s*you are opencode\b/i

let policy = null
try {
  policy = require_(POLICY_PATH)
} catch (err) {
  // A missing policy must not mean "allow everything" — decide() treats a null
  // policy as gate-everything, which is the safe direction.
  console.error("[pal-harness] policy unreadable, FAILING CLOSED:", String(err))
}
/* The rows pal-api's action registry generates (policy.actions.json, beside
 * policy.json; pal-api tests/test_gate_ownership.py keeps it current). Merged
 * UNDER the hand-written table: a tool named in both keeps its hand-written
 * row. Unreadable, it is skipped — its tools then fall to the default row,
 * require:true risk:high, so a lost file only ever asks more. */
/* A free box reads the policy without its pro rows (policy.json `pro`): a free
 * bundle's copy has none (scripts/release/strip_pro.py), and an unstripped one
 * behaves the same. */
if (policy && !PRO) policy = withoutPro(policy)
if (policy) {
  try {
    const generated = require_(path.join(path.dirname(POLICY_PATH), "policy.actions.json"))
    policy = mergeGeneratedPolicy(policy, generated)
  } catch (err) {
    if (err?.code !== "MODULE_NOT_FOUND") {
      console.error("[pal-harness] policy.actions.json unreadable, its tools ask:", String(err))
    }
  }
}

let route = null
let rememberBrowserTask = null
let rememberBrowserStart = null
let browserJobFor = null
let asksToContinue = null
let lastRequestOf = null
let rememberRequest = null
let isAbandonedTask = null
let rememberResearchStart = null
let rememberResearchTask = null
let researchJobFor = null
let categoryOf = null
let forgetCategory = null
let webFirstRefusal = null
let userWordsOnly = (t) => String(t || "").trim()
if (ROUTER_ON) {
  try {
    ;({
      route, rememberBrowserTask, rememberBrowserStart, browserJobFor, asksToContinue, lastRequestOf, isAbandonedTask,
      rememberRequest, userWordsOnly, rememberResearchStart, rememberResearchTask, researchJobFor,
      categoryOf, forgetCategory, webFirstRefusal,
    } = require_("./lib/router-core.js"))
  } catch (err) {
    console.error("[pal-harness] router unavailable (routing disabled):", String(err))
  }
}

/* The assistant's identity. Without this, the NAS opencode runs the stock
 * ~19KB CODING-AGENT system prompt and the model refuses anything that reads
 * as personal ("I'm here to help with software engineering tasks…") — found
 * live 2026-08-06 when it declined to use the question tool because the
 * request "doesn't relate to any coding task". FAIL-OPEN like the router: a
 * missing/unreadable persona must mean "stock prompt", never a failed turn.
 * Set PAL_HARNESS_PERSONA=off to disable explicitly. */
let persona = null
if (PERSONA_PATH !== "off") {
  try {
    persona = require_("node:fs").readFileSync(PERSONA_PATH, "utf8").trim() || null
  } catch (err) {
    console.error("[pal-harness] persona unreadable (stock prompt kept):", String(err))
  }
}

/* The S4 approval spine, unchanged: pal-api blocks on the human and answers.
 *
 * WHAT COMES BACK IS THREE THINGS, NOT ONE. pal-api distinguishes a refusal from
 * an envelope nobody opened — `{"decision":"deny","reason":"timeout"}` vs
 * `reason:"user"` — and this function used to reduce the whole body to the string
 * "deny". Downstream, `it was DENIED` was then the only thing the model, the
 * trace and the log ever saw, so "you said no" and "you were not at your desk"
 * became the same event. Carry `reason` and `id`; gate.js turns them into
 * different instructions.
 *
 * HELD (GATE_HOLD_ON, with `holds`): an unanswered card is not parked when the
 * window passes. pal-api answers "wait" and the gate waits on, window after
 * window (lib/approval-hold.js), until the person answers or the turn is
 * stopped. `onHeld(id)` notes the call once it is held (parked-calls.js). */
async function awaitApproval({ action, summary, params, risk, defer, timeoutS, sessionId, agentId, chatId, holds, onHeld }) {
  const paramsJson = JSON.stringify(params ?? {})
  const hold = GATE_HOLD_ON && Boolean(holds)
  let body = await approvalCall("/approvals/await", {
    action, summary, risk,
    params_json: paramsJson,
    timeout_s: timeoutS,
    // Straight from the policy row. Kept for wire compatibility; pal-api
    // parks every unanswered envelope now (approvals do not expire) so
    // this value no longer changes the outcome.
    defer_ok: defer === true,
    // The opencode session and agent behind this call. Two uses on the
    // server side: the A20 approval-edit trace (existing), and the
    // "Allow for this session" bypass — a decision with scope=session on
    // the resulting envelope arms a bypass keyed on this session_id, and
    // every subsequent await from the same session short-circuits to
    // approve. An empty string means the hook had no session to
    // attribute; the bypass never matches "".
    session_id: sessionId || "",
    agent_id: agentId || "",
    // The chat a sub-agent works for: pal-api holds no card for a job it
    // runs itself (a routine's step), which parks as before.
    hold,
    chat_id: chatId || "",
  }, timeoutS)
  if (hold && body?.decision === "wait" && Number.isFinite(body?.id)) {
    const id = body.id
    try { await onHeld?.(id) } catch { /* the note is for a restart; the wait goes on without it */ }
    body = await holds.wait({
      id,
      sessionId,
      // A Stop withdraws the card unless the policy row says its approval
      // means the same thing later (lib/approval-hold.js, 2026-11-16).
      defer: defer === true,
      poll: ({ park, withdraw, signal }) => approvalCall(`/approvals/${id}/wait`, {
        action, params_json: paramsJson, timeout_s: timeoutS,
        session_id: sessionId || "", agent_id: agentId || "", park,
        withdraw: Boolean(withdraw),
      }, park || withdraw ? 0 : timeoutS, signal),
    })
  }
  // Fail-closed on the DECISION (anything not "approve" is a deny), open on
  // the REASON — an unrecognised reason degrades to a plain denial, which is
  // the safe direction and the pre-existing behaviour.
  //
  // `edited` is the third thing pal-api answers with, and this function
  // dropping it was half of the approve-with-edit bug (measured 2026-08-09,
  // envelope #229: the correction was stored and traced, and the tool ran
  // the original params). Carried as-is; gate.js normalise() owns the
  // object-only validation so both entry points get the same rule.
  return {
    decision: body?.decision === "approve" ? "approve" : "deny",
    reason: typeof body?.reason === "string" ? body.reason : "",
    id: Number.isFinite(body?.id) ? body.id : null,
    edited: body?.edited ?? null,
    // The fields the card filled in itself and the person left as offered
    // (pal-api approval_gate: the account last used with that person).
    filled: Array.isArray(body?.filled) ? body.filled.map(String) : [],
    // A held call's rule, as How PAL acts lists it (“Emails: don’t” (always)).
    rule: typeof body?.rule === "string" ? body.rule : "",
    // Why pal-api refused a call before raising its card ("invalid").
    detail: typeof body?.detail === "string" ? body.detail : "",
  }
}

/* One POST to pal-api's approval routes, given up GATE_FETCH_SLACK_S after
 * pal-api's own window of `windowS`, or when `signal` aborts. */
async function approvalCall(route, body, windowS, signal) {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), (windowS + GATE_FETCH_SLACK_S) * 1000)
  const stop = () => ctl.abort()
  signal?.addEventListener("abort", stop, { once: true })
  try {
    const res = await fetch(`${API_BASE}${route}`, {
      method: "POST",
      headers: { "content-type": "application/json", ...apiHeaders() },
      body: JSON.stringify(body),
      signal: ctl.signal,
    })
    if (!res.ok) throw new Error(`${route.slice(1)} returned ${res.status}`)
    return await res.json()
  } finally {
    clearTimeout(timer)
    signal?.removeEventListener("abort", stop)
  }
}

/* ---- deterministic project filing ------------------------------------------
 *
 * WHY THIS IS IN THE HARNESS AND NOT LEFT TO THE MODEL. A project reaches the
 * model as prose — the `[PROJECT]` block on the user turn (pal_app's
 * `project_preamble.dart`) — and prose is advice. Measured on the live NAS
 * 2026-08-19: inside the "KxEngage" project the assistant created tasks 93 and
 * 95, both `project_id NULL`, while the task the user added by hand thirty
 * seconds apart carried `kxengage`. The tool had no `project` argument at all
 * then, which is fixed in `mcp_server.py`; this is the half that does not depend
 * on a 30B model remembering to pass it.
 *
 * The AUTHORITY is the thread's own membership row, which pal-api already holds:
 * the client files a new thread under the active project on its first turn
 * (`projects_controller.fileNewThread`), so "which project is this conversation
 * in?" is a fact on disk rather than something to infer from the prompt.
 *
 * The tools this fills for, and the argument that files them. A Set rather than
 * a regex because a tool NAME is a wire contract with six registration points,
 * and matching `/task_create/` would also claim a tool called
 * `task_create_batch` that nobody has thought about. Both dialects are here for
 * the reason `_BARE_TOOLS` in mcp_server.py accepts both: which prefix the model
 * sees depends on the harness it is running under.
 */
const PROJECT_FILED_TOOLS = new Set([
  "palapi_task_create",
  "mcp__pal-api__task_create",
])

/* The memory tools are filed the same way, so a fact said inside a project is
 * kept for that project's threads and a recall there sees them (pal-api
 * memory_core, "Scope"). One exception, for remember only: a preference or a
 * writing-style fact is about the user wherever it was said, so it stays
 * general. Filling happens here rather than in pal-api because this is where
 * the approval card is built — the user sees "Remember for work: …" before
 * saying yes. Kept in step with memory_core.GENERAL_CATEGORIES. */
const MEMORY_REMEMBER_TOOLS = new Set(["palapi_memory_remember", "mcp__pal-api__memory_remember"])
const MEMORY_RECALL_TOOLS = new Set([
  "palapi_memory_recall", "mcp__pal-api__memory_recall",
  // Earlier chats (pal-api thread_digest.py): a recall inside a project looks
  // at that project's chats.
  "palapi_chat_recall", "mcp__pal-api__chat_recall",
])
const GENERAL_MEMORY_CATEGORIES = new Set(["preference", "writing"])

/* Search inside a project (pal-api project_hub, J5): the project's own files,
 * mail and meetings come first. Filled the same way, never overwritten. */
const PROJECT_SCOPED_SEARCH = new Set(["palapi_doc_search", "mcp__pal-api__doc_search"])

function projectFillable(toolName, args) {
  if (PROJECT_FILED_TOOLS.has(toolName) || MEMORY_RECALL_TOOLS.has(toolName)) return true
  if (PROJECT_SCOPED_SEARCH.has(toolName)) return true
  if (MEMORY_REMEMBER_TOOLS.has(toolName)) {
    return !GENERAL_MEMORY_CATEGORIES.has(String(args.category ?? "").trim().toLowerCase())
  }
  return false
}

/* The project a thread is filed under, or "" for none.
 *
 * FAIL-OPEN, which inverts the posture of the gate it sits inside, and the
 * inversion is deliberate: this is bookkeeping in front of an action the user
 * asked for, so an unreachable or slow pal-api must mean "no project injected"
 * — the pre-existing behaviour — and never a turn that dies because a filing
 * lookup timed out. The cost of a miss is a task the user re-files with one tap.
 */
async function sessionProject(sessionID) {
  if (!sessionID) return ""
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), PROJECT_LOOKUP_TIMEOUT_MS)
  try {
    const res = await fetch(`${API_BASE}/api/projects/threads`, { headers: apiHeaders(), signal: ctl.signal })
    if (!res.ok) return ""
    const body = await res.json()
    const id = body && body.threads ? body.threads[sessionID] : ""
    return typeof id === "string" ? id : ""
  } catch {
    return ""
  } finally {
    clearTimeout(timer)
  }
}

/* Agents that only ever run as someone's sub-agent, by their own `mode:` —
 * read once from the agent files beside this plugin (/config/opencode/agent on
 * the NAS). A missing or unreadable directory is an empty set, which only means
 * the session lookup below has to answer instead. */
const AGENT_DIR = process.env.PAL_HARNESS_AGENT_DIR || path.join(HERE, "..", "agent")
function subagentNames(dir) {
  const out = new Set()
  try {
    const fs = require_("node:fs")
    for (const f of fs.readdirSync(dir)) {
      if (!f.endsWith(".md")) continue
      const head = fs.readFileSync(path.join(dir, f), "utf8").split(/^---\s*$/m)[1] || ""
      if (/^mode:\s*subagent\s*$/m.test(head)) out.add(f.slice(0, -3))
    }
  } catch {}
  return out
}
const SUBAGENTS = subagentNames(AGENT_DIR)
const SESSION_LOOKUP_TIMEOUT_MS = Number(process.env.PAL_HARNESS_SESSION_LOOKUP_MS || 1500)
/* One carry-on of a cut browser report (lib/runaway.js continueReport): a
 * capped step is ~25 s; past this the ask is stopped and the report is said to
 * be cut. */
const REPORT_CONTINUE_TIMEOUT_MS = Number(process.env.PAL_HARNESS_REPORT_CONTINUE_MS || 120_000)
/* The two message reads and the note's store behind a redo of a written call
 * (redoWrittenCall); the step's end waits on them, so they are kept short. */
const WRITTEN_CALL_TIMEOUT_MS = Number(process.env.PAL_HARNESS_WRITTEN_CALL_MS || 3000)
/* A browser asked to do the job its first turn only talked about: the whole
 * job, so it gets a browser task's time (lib/runaway.js redoEmptyTurn). */
const EMPTY_TURN_TIMEOUT_MS = Number(process.env.PAL_HARNESS_EMPTY_TURN_MS || 20 * 60_000)
/* Tools whose call raises a browser handoff George answers in the chat: the
 * harness stamps the chat's session on them (tool.execute.before). */
const HANDOFF_TOOLS = new Set(["playwright_browser_handoff"])

/* Device commands (pal-api device_tools.py). The chat's session tells pal-api
 * which device this conversation is on (the session → device map); on the
 * Mac's own opencode, PAL_DEVICE_ID — set by pal-desktop when it starts this
 * child — names the Mac outright; and `said`, George's own words this turn,
 * carries a device he named. All three ALWAYS overwritten: a device the model
 * made up would ring a timer in some other room. device_agent_run (a job on
 * his own computer) is picked the same way, and its session is also the chat
 * the job's approvals are asked in. */
const DEVICE_TOOLS = new Set(["palapi_device_run", "palapi_device_agent_run"])
/* The action library's dispatcher (lib/actions.js, pal-api app/actions/library.py):
 * its ctx_json is the harness's, stamped on every call and stripped from history. */
const ACTION_DO_TOOLS = new Set(["palapi_action_do", "mcp__pal-api__action_do"])
const THIS_DEVICE = (process.env.PAL_DEVICE_ID || "").trim()

/* Clicks nas-browser-v2 may hold for George's approval (commit-guard.mjs): a
 * plain click whose words submit, send, book, agree, cancel, delete or pay, and
 * browser_commit, which always asks. Both get the chat's session, so the card
 * shows in that thread, and the answers ledger's entries for this browser task,
 * so the card can list what is about to be sent. v2 takes both off the call
 * before the sidecar sees it. */
const COMMIT_TOOLS = new Set(["playwright_browser_click", "playwright_browser_commit", "playwright_browser_upload_from", "playwright_browser_answer_page", "playwright_browser_fill_form",
  // A set can tick a box (George's limits) and fill from the Vault (the chat's grant card).
  "playwright_browser_set",
  // A list of page actions: nas-browser-v2 passes the stamp on to each click and fill in it.
  STEPS_TOOL])

/* The Vault's tools (nas-browser-v2 vault-client.mjs → pal-api, and the
 * assistant's own vault_catalogue): the chat's session, so a site's grant card
 * shows in that thread and every value the Vault hands out is recorded against
 * the chat it was for. */
const VAULT_TOOLS = new Set(["playwright_browser_fill_from", "playwright_browser_fill_page", "playwright_browser_vault_list",
  "playwright_browser_sign_in", "playwright_browser_new_password", "palapi_vault_catalogue", "palapi_vault_ask"])

/* A meeting's notes written by a call: the calling session itself (not the
 * chat at the top), so pal-api can tell the notes job's own write from
 * another chat's while that job holds the meeting (meeting_notes.held_by). */
const NOTE_WRITE_TOOLS = new Set(["palapi_meeting_note_write", "mcp__pal-api__meeting_note_write"])

/* The arguments tool.execute.before below writes into a call and always
 * overwrites, by tool. They are never the model's own words, so the calls in
 * its history go back to it without them (lib/runaway.js harnessArgsOff): a
 * history of clicks that each end in three more arguments sent qwen3.6 looking
 * for a fourth, and the grammar gave it `element` again. `project` is not here:
 * it is filled only when absent, so a project in a call may be the user's. */
function harnessArgsOf(toolName) {
  const own = []
  if (MEMORY_REMEMBER_TOOLS.has(toolName)) own.push("user_asked")
  if (PAGE_TOOL_RE.test(toolName)) own.push("pal_task", "pal_turn", "pal_fresh_view")
  if (LIST_TOOLS.has(toolName)) own.push("pal_list")
  if (HANDOFF_TOOLS.has(toolName)) own.push("session_id")
  if (DEVICE_TOOLS.has(toolName)) own.push("session_id", "from_device", "said")
  if (COMMIT_TOOLS.has(toolName)) own.push("session_id", "ledger", "limits")
  if (VAULT_TOOLS.has(toolName)) own.push("session_id")
  if (NOTE_WRITE_TOOLS.has(toolName)) own.push("session_id")
  if (ACTION_DO_TOOLS.has(toolName)) own.push("ctx_json")
  return own
}

/* ---- the question bridge's two transports ---------------------------------- */

/* pal-api's approval routes, as the bridge's `api` dependency. Throws on any
 * non-2xx so the bridge's own fail-soft handling decides what a failure means. */
function questionApi() {
  async function call(method, route, body) {
    const ctl = new AbortController()
    const timer = setTimeout(() => ctl.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(`${API_BASE}${route}`, {
        method,
        headers: body === undefined ? apiHeaders() : { "content-type": "application/json", ...apiHeaders() },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctl.signal,
      })
      if (!res.ok) throw new Error(`pal-api ${method} ${route} returned ${res.status}`)
      return await res.json()
    } finally {
      clearTimeout(timer)
    }
  }
  return {
    start: (body) => call("POST", "/approvals/question/start", body),
    get: (id) => call("GET", `/approvals/${id}`),
    settle: (id, body) => call("POST", `/approvals/${id}/settle`, body),
    pending: async () => (await call("GET", "/approvals?status=pending,deferred")).approvals || [],
  }
}

/* nas-browser-v2's picture of the page a browser session is on, for the card
 * that asks the person about it (question-bridge.js). The cell's credential,
 * as for pal-api: the route shows whatever is signed in. Fail-soft: null. */
function browserPagePicture() {
  const base = (process.env.PAL_BROWSER_FLOWS_URL || "http://chromium:8932").replace(/\/+$/, "")
  return async (sessionID) => {
    const ctl = new AbortController()
    const timer = setTimeout(() => ctl.abort(), API_TIMEOUT_MS)
    try {
      const url = new URL(`${base}/page-picture`)
      if (sessionID) url.searchParams.set("task", sessionID)
      const res = await fetch(url, { headers: apiHeaders(), signal: ctl.signal })
      if (!res.ok) return null
      return await res.json()
    } catch {
      return null
    } finally {
      clearTimeout(timer)
    }
  }
}

/* opencode's own question routes, on THIS plugin's instance.
 *
 * Raw fetch against the server this plugin runs in, rather than `client`: the
 * SDK the plugin is handed (the v1 client) has no `question` namespace on
 * 1.18.4. The routes are the root-level ones pal_app already answers with, and
 * `?directory=` pins them to the instance whose event hook saw the question —
 * questions live per directory instance, and this plugin only hears its own
 * (`event` is filtered on `location.directory`). The NAS serves on 0.0.0.0,
 * which is a listen address, not somewhere to connect to; loopback is. */
function opencodeQuestions(input, directory) {
  function base() {
    const url = new URL(String(process.env.PAL_HARNESS_OPENCODE_URL || input?.serverUrl || "http://127.0.0.1:4096"))
    if (url.hostname === "0.0.0.0" || url.hostname === "[::]") url.hostname = "127.0.0.1"
    return url
  }
  function headers(body) {
    const out = {}
    if (body !== undefined) out["content-type"] = "application/json"
    const password = process.env.OPENCODE_SERVER_PASSWORD
    if (password) {
      const user = process.env.OPENCODE_SERVER_USERNAME || "opencode"
      out.authorization = `Basic ${Buffer.from(`${user}:${password}`).toString("base64")}`
    }
    return out
  }
  async function call(method, route, body) {
    const url = new URL(route, base())
    if (directory) url.searchParams.set("directory", directory)
    const ctl = new AbortController()
    const timer = setTimeout(() => ctl.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(url, {
        method,
        headers: headers(body),
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctl.signal,
      })
      if (!res.ok) {
        const err = new Error(`opencode ${method} ${route} returned ${res.status}`)
        err.status = res.status
        throw err
      }
      const text = await res.text()
      return text ? JSON.parse(text) : null
    } finally {
      clearTimeout(timer)
    }
  }
  return {
    reply: (id, answers) => call("POST", `/question/${encodeURIComponent(id)}/reply`, { answers }),
    reject: (id) => call("POST", `/question/${encodeURIComponent(id)}/reject`, {}),
    pending: async () => {
      const data = await call("GET", "/question")
      return Array.isArray(data) ? data : Array.isArray(data?.data) ? data.data : null
    },
    // {sessionID: {type: "busy" | "retry"}}; an idle session is absent.
    status: async () => {
      const data = await call("GET", "/session/status")
      return data && typeof data === "object" && !Array.isArray(data) ? data : null
    },
  }
}

export const PALHarness = async (input = {}) => {
  const { directory, client } = input
  const tracer = createTracer({ file: TRACE_FILE, enabled: Boolean(TRACE_FILE) })
  const pending = new Map()   // sessionID -> turn preamble ([NOW] + directive) awaiting injection
  /* Per-session call budgets for the tools policy.json marks `budget` (the
   * deck_* quartet). Off with PAL_HARNESS_BUDGETS=off, for evals that want
   * the loop unbounded. */
  const budgets = BUDGETS_ON ? createCounter() : null
  const provenance = PROVENANCE_ON ? createProvenance() : null
  const ledger = LEDGER_ON ? createLedger({ sources: provenance }) : null
  const captures = CAPTURES_ON ? createCaptures() : null
  const pageIds = PAGE_IDS_ON ? createPageIds() : null
  const work = BROWSER_BUDGET_ON ? createBrowserBudget({ policy }) : null
  const fresh = BROWSER_FRESH === "off" ? null : createBrowserFresh({
    mode: BROWSER_FRESH,
    // Called at a rebuild only, long after `records` (below) is made.
    progress: (sid) => browserProgress({ ledger, captures, work, records }, sid),
    trace: (row) => tracer.write(row),
  })
  /* George's answers to the browser, by chat and site, for the next browser
   * task in the chat or on the site (lib/chat-answers.js). */
  const chatAnswers = ledger ? createChatAnswers() : null
  /* Chats that have just started a NEW browser task, and the browser
   * children already matched to one: how a stopped task is known. */
  const startingBrowserTasks = new Map()
  const seenBrowserChild = new Set()
  /* The same for `research` tasks, so "continue" after one means that one
   * (router-core.js researchJobs). */
  const startingResearchTasks = new Map()
  const seenResearchChild = new Set()
  /* chat -> when it last tried a web look-up without the browser (web_search,
   * web_read, or a `research` task): what opens the browser fallback on a
   * look-up turn (WEB_FIRST_ON). */
  const webTried = new Map()
  /* The person's last message in each chat, and the limits each browser child's
   * task carries (lib/own-words.js). */
  const personSaid = new Map()
  /* chat -> the acting_hold rules set since George last spoke: one call per
   * rule per turn (lib/hold-asked.js). */
  const heldThisTurn = new Map()
  /* The names George has typed in each chat, with the names beside them
   * (lib/cut-names.js). */
  const saidNames = createNameBook()
  /* chat -> the days a browser task was held for since George last spoke:
   * sent again, it goes (lib/task-date.js). */
  const datesHeld = new Map()
  /* chat -> its last booking commit, declined or made (lib/booking-claims.js). */
  const bookings = BOOKING_CLAIMS_ON ? createBookings() : null
  /* The [ACTIONS] cards each chat has been shown: one is never repeated —
   * it is still in the history above (lib/actions.js cardsBlock). */
  const shownCards = new Map()
  /* The calls the gate parked, by chat, kept beside the router's own state
   * so a restart between park and approval loses nothing; and chat -> the
   * grants this turn's note handed back (lib/parked-calls.js). */
  const parked = PARKED_ON
    ? createParkedCalls({
      file: path.join(process.env.PAL_ROUTER_STATE_DIR || path.join(os.homedir(), ".pal"), "parked-calls.json"),
      fetchApproval: (id) => questionApi().get(id),
      boot: QUESTION_ORIGIN,
      log: (r) => tracer.write(r),
    })
    : null
  const handBacks = new Map()
  /* The gated calls waiting on their cards, by session: a stopped turn lets
   * its own go (the `event` hook below, and opencode's status as the check
   * when an event is missed). */
  const holdStatus = opencodeQuestions(input, directory)
  const holds = GATE_ON && GATE_HOLD_ON
    ? createApprovalHolds({
      liveness: async (sid) => {
        const busy = await holdStatus.status()
        return busy ? Boolean(busy[sid]) : null
      },
      log: (r) => tracer.write(r),
    })
    : null
  /* Calls an earlier opencode was holding when it stopped: their cards are
   * parked, and the go-ahead hands them back (lib/parked-calls.js). Not
   * awaited: pal-api being slow must not hold up the plugin's boot. */
  for (const orphan of parked?.orphans() ?? []) {
    approvalCall(`/approvals/${orphan.id}/wait`, { action: orphan.tool, park: true }, 0)
      .then((r) => tracer.write({ kind: "gate.orphan_parked", id: orphan.id, parked: r?.parked ?? null }))
      .catch((err) => tracer.write({ kind: "gate.orphan_park_failed", id: orphan.id, error: String(err) }))
  }
  /* Each browser task's record (lib/task-record.js), kept beside the router's
   * state so a restart between a task and its "Continue", or its parked
   * approval, loses nothing; and, by a compaction's summary id, the block
   * that rides on that summary (the same text on every request after it). */
  const records = TASK_RECORD_ON
    ? createTaskRecords({
      file: path.join(process.env.PAL_ROUTER_STATE_DIR || path.join(os.homedir(), ".pal"), "task-records.json"),
      log: (r) => tracer.write(r),
    })
    : null
  const recordBlocks = new Map()
  const recipeLearn = RECIPE_LEARN_ON ? createRecipeLearn({ log: (r) => tracer.write(r) }) : null
  /* session -> the agent its turns run as, from chat.message (which is told;
   * tool.execute.before is not). pal-api scopes a sub-agent's action_do by it
   * (pal-api/app/actions/scopes.py). */
  const sessionAgent = new Map()
  function noteAgent(sid, agent) {
    if (sessionAgent.size >= 256 && !sessionAgent.has(sid)) sessionAgent.delete(sessionAgent.keys().next().value)
    sessionAgent.set(sid, agent)
  }
  async function agentOfSession(sid) {
    if (!sid) return ""
    if (sessionAgent.has(sid)) return sessionAgent.get(sid)
    const agent = (await describeSession(sid)).agent || ""
    if (agent) noteAgent(sid, agent)
    return agent
  }
  /* Whether a call's session runs as `browser`, the one agent with page tools
   * (the recipe guard in lib/actions.js). With no agent known, a sub-agent's
   * session is taken for one — every page job is delegated — and a chat's own
   * is not. */
  async function runsAsBrowser(input) {
    const agent = input?.agent || await agentOfSession(input?.sessionID)
    if (agent) return agent === "browser"
    return Boolean(input?.sessionID) && (await rootSessionOf(input.sessionID)) !== input.sessionID
  }
  /* The recipe names each browser session has been shown, and, by session,
   * the recipe that stopped this turn with what to do instead (the recipe
   * guard in lib/actions.js). The latter goes with the person's next message. */
  const flowNames = FLOW_GUARD_ON ? createFlowNames() : null
  const stoppedRecipes = new Map()
  /* The email addresses George typed in each chat, and those its sources gave;
   * and, per tool call, how what ran differs from the call the model wrote
   * (lib/addresses.js). */
  const addressBook = createAddressBook()
  const ranChanges = new Map()
  /* George's answers to the last question asked in each chat, for whether he
   * named a mail account (namesAccount). */
  const lastAnswers = new Map()
  /* "Change task" on a sub-agent's question: his words, by the sub-agent's
   * session, for the task result that goes back to its parent. */
  const insteadByChild = new Map()
  /* A browser's question George answered by pointing to his own mail or
   * files, by the browser session: the assistant is told on the task's
   * result to fetch it (lib/chat-answers.js pointsElsewhere). */
  const pointedByChild = new Map()
  /** The question tool's answers as words, one per question answered. */
  const answersOf = (questions, answers) => {
    const qs = Array.isArray(questions) ? questions : []
    const as = Array.isArray(answers) ? answers : []
    return qs.map((_, i) => [as[i]].flat().filter(Boolean).join(", ")).filter(Boolean)
  }
  /* The addresses taken out of a browser task (lib/site-guess.js), by call,
   * for the line on its result that tells the assistant so. */
  const droppedByCall = new Map()
  /* A browser task's work list (lib/work-list.js): by the browser's session,
   * for the id stamped on its list calls, and by the task call, for the
   * code-kept line on its result. */
  const childLists = new Map()
  const listByCall = new Map()
  const workLists = workListApi({ base: API_BASE, headers: apiHeaders })
  const keepLimited = (map, key, value, max = 256) => {
    if (map.size >= max && !map.has(key)) map.delete(map.keys().next().value)
    map.set(key, value)
  }
  const noteRan = (callID, { edited = [], held = [], filled = [], kept = [] }) => {
    if (!callID) return
    const ran = ranChanges.get(callID) ?? { edited: [], held: [], filled: [], kept: [] }
    ran.edited.push(...edited)
    ran.held.push(...held)
    ran.filled.push(...filled)
    ran.kept.push(...kept)
    if (!ranChanges.has(callID) && ranChanges.size >= 256) ranChanges.delete(ranChanges.keys().next().value)
    ranChanges.set(callID, ran)
  }
  /* What George's last message in each chat was asked looking at, when it was
   * asked from the orb beside a stream (lib/screen.js): the app a browser task
   * starts in. Per message — a message from anywhere else clears it. */
  const screens = new Map()
  // What each step has said so far, from the event stream (lib/ask-then-act.js).
  const stepText = ASK_THEN_ACT_ON ? createStepText() : null
  // Each turn's calls, refused or let through (lib/refused-calls.js).
  const refusedCalls = REFUSED_CHECK_ON ? createRefusedCalls() : null
  // Each turn's calls and how they came back (lib/done-claims.js).
  const doneClaims = DONE_CLAIMS_ON ? createDoneClaims() : null
  const oneJob = ONE_BROWSER_JOB_ON ? createOneBrowserJob() : null
  const childLimits = new Map()
  /* Each chat's Auto thinking level, decided on George's message and put on
   * every model request of that turn. */
  const autoThinking = THINKING_AUTO_ON ? createAutoThinking() : null
  /* Sessions whose first browser call has carried their task (pal_task). */
  const stampedTasks = new Set()
  /* Sessions with a new turn whose first page call has not gone yet: it
   * carries pal_turn (nas-browser-v2 fresh-task.mjs TURN_ARG), so a resume by
   * task_id keeps the page it is on rather than loading it again. pal_task is
   * once per task, so it never marked a resume (2026-11-24 review). */
  const turnToStamp = new Set()
  /* One value per turn, unique across restarts (the sidecar outlives us). */
  let turnSeq = 0
  const bootTag = Date.now().toString(36)
  /* Sessions that have opened an app, desktop or Android (opensApp): every
   * browser call of theirs carries the stamp from then on. */
  const appChats = new Set()
  /* Sessions whose history has gone out without the harness's arguments, traced once. */
  const ownArgsTraced = new Set()
  const continueTraced = new Set()
  /* Sessions heard from the Talk view (lib/talk-context.js), and the ones whose cut is traced. */
  const talkSessions = new Set()
  const talkTraced = new Set()
  /* The cut's kept boundary per chat, one per process (lib/tool-trim.js). */
  const toolTrim = acquireToolTrim({ log: (row) => tracer.write(row) })
  /* A Talk continue's text as first sent, by message id: the person's words
   * move on with every turn, and the history must not move with them. */
  const talkContinued = new Map()
  /* Browser tasks gone quiet: the watch, and the line for each chat. */
  const stalls = STALL_ON ? createStallWatch() : null
  /* The report goes after the session is idle, so nothing here is in front of
   * a turn: a slow pal-api costs the push, never the chat. */
  async function postFinished(body) {
    if (!API_BASE) return false
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(`${API_BASE}/api/notifications/finished`, {
        method: "POST", headers: { "content-type": "application/json", ...apiHeaders() }, body: JSON.stringify(body), signal: controller.signal,
      })
      return res.ok
    } catch {
      return false
    } finally {
      clearTimeout(timer)
    }
  }
  /* A turn ended in this chat: pal-api summarises a chat filed in a project
   * once it has gone quiet, and every report starts that wait over
   * (pal-api/app/thread_digest.py). opencode says `session.idle` and
   * `session.status` idle for the same end, so one report per chat per few
   * seconds. Sub-agents and unfiled chats are pal-api's to ignore. */
  const movedAt = new Map()
  async function postMoved(sid) {
    if (!API_BASE || !sid) return false
    const now = Date.now()
    if (now - (movedAt.get(sid) ?? -Infinity) < 5000) return false
    if (movedAt.size >= 256) movedAt.delete(movedAt.keys().next().value)
    movedAt.set(sid, now)
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(`${API_BASE}/api/projects/threads/${encodeURIComponent(sid)}/moved`, {
        method: "POST", headers: apiHeaders(), signal: controller.signal,
      })
      return res.ok
    } catch {
      return false
    } finally {
      clearTimeout(timer)
    }
  }
  /* A turn ended in an app's own folder (lib/made-apps.js): pal-api commits
   * what the turn changed, so every turn is a version the person can go back
   * to (docs/pal-apps-plan.md, turn-done). `said` is their own words for the
   * turn. Once per turn, never a sub-agent's, and after the session is idle,
   * so nothing here is in front of the chat: a slow or failing pal-api costs
   * the version, and a trace line says so. */
  const appTurns = MADE_APPS_ON ? createAppTurns() : null
  async function postTurnDone(sid) {
    const said = appTurns?.ended(sid)
    if (said == null) return false
    const app = appRepoOf(directory)
    if (!app || !API_BASE || await isSubagentTurn({}, sid)) return false
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(`${API_BASE}/api/made-apps/by-folder/turn-done`, {
        method: "POST", headers: { "content-type": "application/json", ...apiHeaders() },
        body: JSON.stringify({ folder: app.directory, session_id: sid, said }), signal: controller.signal,
      })
      tracer.write({ kind: "made_app.turn_done", sessionID: sid, app: app.id, posted: res.ok, ...(res.ok ? {} : { status: res.status }) })
      return res.ok
    } catch (err) {
      tracer.write({ kind: "made_app.turn_done", sessionID: sid, app: app.id, posted: false, error: String(err) })
      return false
    } finally {
      clearTimeout(timer)
    }
  }
  async function readSession(sid) {
    const lookup = async (call, ms) => {
      let timer
      try {
        return await Promise.race([
          call(),
          new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), ms) }),
        ])
      } catch {
        return null
      } finally {
        clearTimeout(timer)
      }
    }
    const [info, history] = await Promise.all([
      typeof client?.session?.get === "function"
        ? lookup(() => client.session.get({ path: { id: sid }, query: { directory } }), SESSION_LOOKUP_TIMEOUT_MS)
        : null,
      typeof client?.session?.messages === "function"
        ? lookup(() => client.session.messages({ path: { id: sid }, query: { directory } }), SESSION_LOOKUP_TIMEOUT_MS * 3)
        : null,
    ])
    return {
      title: info?.data?.title || "",
      parentID: info?.data?.parentID || "",
      messages: Array.isArray(history?.data) ? history.data : [],
    }
  }
  /* A chat's first title, as opencode's title model made it, held to George's
   * own words (lib/title-context.js titleFromBlocks): a title drawn from the
   * harness's blocks instead is replaced by his words, once. Only a chat's
   * own session, only its first real title, and only while it has one
   * message of his — the one the title was made from — so a title he gave a
   * chat himself is never looked at. Fails quiet: an unreadable session or no
   * session.update leaves the title as it is. */
  const titleChecked = new Set()
  async function checkTitle(info) {
    const sid = info.id
    const title = String(info.title || "")
    if (!title || DEFAULT_TITLE_RE.test(title) || titleChecked.has(sid)) return
    if (titleChecked.size >= 512) titleChecked.delete(titleChecked.values().next().value)
    titleChecked.add(sid)
    if (typeof client?.session?.update !== "function") return
    const { messages } = await readSession(sid)
    const real = (m) => m?.info?.role === "user" && (m.parts || []).some((p) => p?.type === "text" && !p.synthetic)
    const users = messages.filter(real)
    if (users.length !== 1) return
    const stored = users[0].parts.filter((p) => p?.type === "text" && !p.synthetic).map((p) => p.text).join("\n\n")
    const words = memoryWords(stored)
    if (!titleFromBlocks({ title, words, stored })) return
    const fixed = titleFromWords(words)
    if (!fixed || fixed === title) return
    await client.session.update({ path: { id: sid }, query: { directory }, body: { title: fixed } })
    tracer.write({ kind: "title.fixed", sessionID: sid, was: title, now: fixed })
  }
  /* A message to a browser child, resolved once its reply is done: the
   * carry-on of a cut report. A reply that runs past the timeout is stopped,
   * so the task's result is never held for longer than that. */
  async function askBrowser(sid, body, timeoutMs = REPORT_CONTINUE_TIMEOUT_MS) {
    if (typeof client?.session?.prompt !== "function") throw new Error("no session.prompt")
    let timer
    try {
      return await Promise.race([
        client.session.prompt({ path: { id: sid }, query: { directory }, body }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), timeoutMs) }),
      ])
    } catch (err) {
      if (String(err?.message) === "timeout" && typeof client?.session?.abort === "function") {
        await client.session.abort({ path: { id: sid }, query: { directory } }).catch(() => {})
      }
      throw err
    } finally {
      clearTimeout(timer)
    }
  }
  /* A step that wrote [calls] out as text (lib/written-calls.js) gets one more
   * go. The note is stored as a synthetic user message in the same session,
   * now, while the step is still open: opencode 1.18.34's loop stops only when
   * the last assistant message answers the LAST user message, so it takes
   * another step to answer the note, in the same turn. The note goes with the
   * turn's own agent, model, Thinking level, system text and tools, so the
   * step after it is the same kind of request. Once a turn: a step answering
   * a note is not redone. Returns why it did nothing, or "" when the note is
   * stored. */
  async function redoWrittenCall(sid, messageID, calls) {
    if (!sid || !messageID) return "no_ids"
    if (typeof client?.session?.message !== "function" || typeof client?.session?.prompt !== "function") return "no_client"
    const within = (promise) => {
      let timer
      return Promise.race([
        promise,
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), WRITTEN_CALL_TIMEOUT_MS) }),
      ]).finally(() => clearTimeout(timer))
    }
    const read = (id) => within(client.session.message({ path: { id: sid, messageID: id }, query: { directory } }))
    const step = (await read(messageID))?.data?.info
    // opencode's own summary of the chat: notes, not a step that calls tools.
    if (step?.summary || step?.agent === "compaction") return "compaction"
    const parentID = step?.parentID
    if (!parentID) return "no_parent"
    const asked = (await read(parentID))?.data
    const info = asked?.info
    if (!info || info.role !== "user") return "no_parent"
    if (isRedoNote(asked.parts)) return "redone_already"
    if (info.format?.type === "json_schema") return "structured"
    const body = {
      noReply: true,
      ...(info.agent ? { agent: info.agent } : {}),
      ...(info.model?.providerID && info.model?.modelID
        ? { model: { providerID: info.model.providerID, modelID: info.model.modelID } } : {}),
      ...(info.model?.variant ? { variant: info.model.variant } : {}),
      ...(info.system ? { system: info.system } : {}),
      ...(info.tools && Object.keys(info.tools).length ? { tools: info.tools } : {}),
      parts: [{ type: "text", text: redoNote(calls.map((c) => c.name)), synthetic: true }],
    }
    await within(client.session.prompt({ path: { id: sid }, query: { directory }, body }))
    return ""
  }

  /* A model still calling a tool after its budget's last refusal (lib/gate.js
   * BUDGET_STOP_AFTER) has its turn ended, as a browser report past its time
   * is (askBrowser). Not awaited: the abort settles this very call, and its
   * refusal is thrown either way. A sub-agent's own session is the one ended,
   * so its caller gets the task back as failed and goes on. */
  function endTurn(sid, tool) {
    tracer.write({ kind: "budget.stop", tool, sessionID: sid })
    if (typeof client?.session?.abort !== "function") return
    client.session.abort({ path: { id: sid }, query: { directory } }).catch((err) => {
      tracer.write({ kind: "budget.stop_error", tool, sessionID: sid, error: String(err) })
    })
  }
  const turns = TURN_REPORT_ON
    ? createTurnReport({
        isSubagent: (sid) => isSubagentTurn({}, sid),
        read: readSession,
        post: postFinished,
        log: (row) => tracer.write(row),
        extra: TURN_REPORT_EXTRA,
      })
    : null
  // This instance's turns, timed for the box's telemetry (lib/telemetry.js).
  const speed = telemetry ? telemetry.speed() : null
  const stallNotes = new Map()
  const seenRunningCall = new Set()
  const modelBases = new Map()
  async function baseURLFor(model) {
    const fallback = process.env.PAL_HARNESS_MODEL_URL || ""
    if (!model?.providerID) return fallback
    if (modelBases.has(model.providerID)) return modelBases.get(model.providerID)
    let base = fallback
    try {
      const res = await client?.config?.get?.({ query: { directory } })
      base = res?.data?.provider?.[model.providerID]?.options?.baseURL || fallback
    } catch { base = fallback }
    modelBases.set(model.providerID, base)
    return base
  }
  async function postStall(body) {
    if (!API_BASE) return false
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), Math.min(API_TIMEOUT_MS, 3000))
    try {
      const res = await fetch(`${API_BASE}/browser/stall`, {
        method: "POST", headers: { "content-type": "application/json", ...apiHeaders() }, body: JSON.stringify(body), signal: controller.signal,
      })
      return res.ok
    } catch {
      return false
    } finally {
      clearTimeout(timer)
    }
  }
  if (stalls && STALL_CHECK_MS > 0) {
    const timer = setInterval(() => {
      reportStalls({ watch: stalls, baseURLFor, chatOf: rootSessionOf, post: postStall, notes: stallNotes, log: (r) => tracer.write(r) })
        .catch(() => {})
    }, STALL_CHECK_MS)
    timer.unref?.()
  }
  /* Which job each browser child was given, for its result's [AFTER THE JOB]
   * when a later task_id resume carries no [JOB] block of its own. */
  const jobByChild = new Map()
  /* The browser children whose job is only a look, until a resume asks for
   * the job itself (LOOK_REFUSED). */
  const lookChildren = new Set()
  /* The calendar events a booking task was told about (lib/calendar-near.js),
   * by the chat that started it until its child is known, then by child. */
  const calendarByChat = new Map()
  const calendarByChild = new Map()
  /* Which of a browser child's answers have been offered for the Vault, so a
   * task resumed five times makes one card, not five. */
  const offeredByChild = new Map()

  /* The ledger's record for a browser task, left on pal-api for the card a
   * click may raise (nas-browser-v2 reads it back by the task's id). Only
   * when it changed since the last click; true when pal-api has it. */
  const leftRecord = new Map()
  async function leaveRecord(sid, entries) {
    // The task record's own lines go with it, for the card's "You asked"
    // (lib/task-record.js cardOf; pal-api browser_answers.py).
    const task = records ? cardOf(records.of(sid)) : null
    const body = JSON.stringify({ answers: entries, ...(task ? { task } : {}) })
    if (leftRecord.get(sid) === body) return true
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), Math.min(API_TIMEOUT_MS, 3000))
    try {
      const res = await fetch(`${API_BASE}/browser/answers/${encodeURIComponent(sid)}`, {
        method: "PUT",
        headers: { "content-type": "application/json", ...apiHeaders() },
        body,
        signal: controller.signal,
      })
      if (!res.ok) return false
      if (leftRecord.size >= 256 && !leftRecord.has(sid)) leftRecord.delete(leftRecord.keys().next().value)
      leftRecord.set(sid, body)
      return true
    } catch (err) {
      tracer.write({ kind: "ledger.leave.error", sessionID: sid, error: String(err) })
      return false
    } finally {
      clearTimeout(timer)
    }
  }

  /* Offer George's answers (the ledger's "george" entries) for his Vault.
   * Bookkeeping behind a finished task: short timeout, fails soft, and the
   * caller hears only how many were offered. */
  async function offerAnswers(parentSid, child) {
    if (!ledger || !child) return 0
    const sent = offeredByChild.get(child) ?? new Set()
    // "george" is the ledger's source tag for the person's own answers — an
    // opaque value on the wire to pal-api's cards, the same in every cell.
    const fresh = ledger.entries(child).filter((e) => e.source === "george" && e.question && !sent.has(`${e.question}\u0000${e.value}`))
    if (!fresh.length) return 0
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS)
    try {
      const res = await fetch(`${API_BASE}/vault/answers/offer`, {
        method: "POST",
        headers: { "content-type": "application/json", ...apiHeaders() },
        // Where each answer was given (the page, and the box's own label),
        // so the Vault records where it came from and learns how the site asks.
        body: JSON.stringify({
          chat_session_id: await rootSessionOf(parentSid),
          browser_session_id: child,
          answers: fresh.map((e) => ({
            question: e.question, value: e.value, page: e.page || "", box_label: e.label || "",
          })),
        }),
        signal: controller.signal,
      })
      if (!res.ok) return 0
      for (const e of fresh) sent.add(`${e.question}\u0000${e.value}`)
      if (offeredByChild.size >= 256 && !offeredByChild.has(child)) offeredByChild.delete(offeredByChild.keys().next().value)
      offeredByChild.set(child, sent)
      return Number((await res.json())?.offered) || 0
    } catch {
      return 0
    } finally {
      clearTimeout(timer)
    }
  }

  /* What each sub-agent session read (lib/grounding.js), and the conditions
   * its task carried: read once, when its result comes back, and again only
   * when a resume's result does. Null when the session cannot be read. */
  const childReads = new Map()
  async function readChild(child, { fresh = false, depth = 0 } = {}) {
    if (!child) return null
    if (!fresh && childReads.has(child)) return childReads.get(child)
    const { messages, title } = await readSession(child)
    if (!messages.length) return null
    const { seen, children } = seenFromMessages(messages)
    // A sub-agent's own sub-agents: what they read, it read.
    if (depth < 1) {
      for (const grandchild of children) {
        const r = await readChild(grandchild, { depth: depth + 1 })
        if (r) for (const page of r.seen.pages()) seen.addPage(page)
      }
    }
    const asked = messages.filter((m) => m?.info?.role === "user")
      .flatMap((m) => (m.parts || []).filter((p) => p?.type === "text").map((p) => p.text)).join("\n")
    const agent = messages.find((m) => m?.info?.agent)?.info?.agent || (/\(@([\w.-]+) subagent\)\s*$/.exec(title) || [])[1] || ""
    // George's conditions from the task's record too, which no retelling lost.
    const kept = records?.of(child)?.conditions ?? []
    const read = { seen, conds: uniqueConditions([...kept, ...conditionsIn(asked)]), agent }
    if (childReads.size >= 32 && !childReads.has(child)) childReads.delete(childReads.keys().next().value)
    childReads.delete(child)
    childReads.set(child, read)
    return read
  }

  /* The assistant's answer, checked against everything the chat read: its
   * own tools' results and its sub-agents' pages. Returns the answer with
   * unchecked links marked and a footnote, or null when nothing needs one. */
  async function checkAnswer(sid, text) {
    const { messages } = await readSession(sid)
    if (!messages.length) return null
    let lastUser = -1
    for (let i = messages.length - 1; i >= 0; i--) if (messages[i]?.info?.role === "user") { lastUser = i; break }
    const { seen, children, reports } = seenFromMessages(messages)
    const reads = await Promise.all(children.map((c) => readChild(c).catch(() => null)))
    // A sub-agent that cannot be read: its report is taken at its word.
    children.forEach((c, i) => { if (!reads[i]) seen.addGiven(reports.get(c)) })
    const all = mergeSeen([seen, ...reads.map((r) => r?.seen)])
    const turn = seenFromMessages(lastUser >= 0 ? messages.slice(lastUser + 1) : [])
    const turnReads = turn.children.map((c) => reads[children.indexOf(c)]).filter(Boolean)

    const links = unseenLinks(text, all)
    // Names only when this turn's answer rests on what sub-agents read.
    const names = ANSWER_NAMES_ON && turnReads.length && turnReads.every((r) => READING_AGENTS.has(r.agent))
      ? unseenNames(text, all) : []
    const said = lastUser >= 0
      ? userWordsOnly((messages[lastUser].parts || []).filter((p) => p?.type === "text").map((p) => p.text).join("\n")) : ""
    const conds = uniqueConditions([...conditionsIn(said), ...turnReads.flatMap((r) => r.conds)])
    const conditions = conds.length
      ? answerLines(text, conds, all.pages(), turn.children.map((c) => reports.get(c)).filter(Boolean)) : []
    // A link retyped a character off the page's is put back as the page had it.
    const { text: put, fixed } = putBackNear(text, links)
    const left = links.filter((l) => !fixed.includes(l))
    const note = answerNote({ links: left, names, conditions })
    if (!note && !fixed.length) return null
    return {
      text: note ? `${markLinks(put, left, ANSWER_MARK)}\n${note}` : put,
      counts: { links: left.length, names: names.length, conditions: conditions.length, put_back: fixed.length },
    }
  }

  /* Is this turn a sub-agent's? A sub-agent's "user message" is the prompt its
   * parent wrote with the task tool, and the router has nothing to add to it:
   * measured live 2026-09-28 (Rosetta Stone), routing it cost 4.3 s on the main
   * model and told the `browser` sub-agent to "delegate to the `browser`
   * sub-agent — do NOT drive the browser yourself". Two signals: the agent's own
   * `mode: subagent`, then the session's parentID (a `mode: all` agent run by
   * the task tool). Cached per session, since a parent never changes. FAILS
   * OPEN to "not a sub-agent" — routing a turn it did not need to is the old
   * behaviour; skipping one that needed it is not. */
  const childSessions = new Map()
  async function isSubagentTurn(input, sid) {
    if (input?.agent && SUBAGENTS.has(input.agent)) return true
    if (!sid || sid === "*" || typeof client?.session?.get !== "function") return false
    if (childSessions.has(sid)) return childSessions.get(sid)
    let timer
    try {
      const res = await Promise.race([
        client.session.get({ path: { id: sid }, query: { directory } }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), SESSION_LOOKUP_TIMEOUT_MS) }),
      ])
      const child = Boolean(res?.data?.parentID)
      if (childSessions.size >= 256) childSessions.delete(childSessions.keys().next().value)
      childSessions.set(sid, child)
      return child
    } catch {
      return false
    } finally {
      clearTimeout(timer)
    }
  }

  /* The chat a session belongs to: itself, or the parent it was delegated
   * from, followed up to the top. A `browser` sub-agent runs in a CHILD
   * session and the app shows the parent's thread, so an envelope stamped with
   * the child's id would never find its chat. Cached, since a session's parent
   * never changes. FAILS OPEN to the session itself. */
  const rootSessions = new Map()
  async function rootSessionOf(sid) {
    if (!sid || sid === "*" || typeof client?.session?.get !== "function") return sid || ""
    if (rootSessions.has(sid)) return rootSessions.get(sid)
    let current = sid
    for (let hops = 0; hops < 4; hops++) {
      let timer
      try {
        const res = await Promise.race([
          client.session.get({ path: { id: current }, query: { directory } }),
          new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), SESSION_LOOKUP_TIMEOUT_MS) }),
        ])
        const parent = res?.data?.parentID
        if (!parent) break
        current = parent
      } catch {
        break
      } finally {
        clearTimeout(timer)
      }
    }
    if (rootSessions.size >= 256) rootSessions.delete(rootSessions.keys().next().value)
    rootSessions.set(sid, current)
    return current
  }

  /* The hosts a chat has given — George's own words, and what pages and
   * documents in it showed (lib/site-guess.js knownHosts) — read from the
   * chat's own history. Null when it cannot be read: nothing is then taken
   * out, which is only ever the old behaviour. */
  async function knownHostsOf(sid) {
    const messages = await chatMessagesOf(sid, "site_guess")
    return messages ? knownHosts(messages) : null
  }

  /* A chat's own history, read from its root session, or null when it
   * cannot be read (a trace line under `kind`). */
  async function chatMessagesOf(sid, kind) {
    if (!sid || sid === "*" || typeof client?.session?.messages !== "function") return null
    const root = await rootSessionOf(sid)
    let timer
    try {
      const res = await Promise.race([
        client.session.messages({ path: { id: root }, query: { directory } }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), SESSION_LOOKUP_TIMEOUT_MS * 3) }),
      ])
      return Array.isArray(res?.data) ? res.data : null
    } catch (err) {
      tracer.write({ kind: `${kind}.history_error`, sessionID: sid, error: String(err) })
      return null
    } finally {
      clearTimeout(timer)
    }
  }

  /* Who asked, for the question card: the agent and, for a sub-agent, the
   * conversation it works for. The task tool titles a child session
   * "<description> (@<agent> subagent)" on 1.18.4, which is the one place the
   * agent's name is recorded on the session itself. FAILS OPEN to "unknown" —
   * the card then says "PAL" instead of "PAL's browser", nothing worse. */
  async function describeSession(sid) {
    if (!sid || typeof client?.session?.get !== "function") return {}
    let timer
    try {
      const res = await Promise.race([
        client.session.get({ path: { id: sid }, query: { directory } }),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), SESSION_LOOKUP_TIMEOUT_MS) }),
      ])
      const info = res?.data || {}
      const agent = typeof info.agent === "string" && info.agent
        ? info.agent
        : (/\(@([\w.-]+) subagent\)\s*$/.exec(String(info.title || "")) || [])[1] || ""
      return { agent, parentID: info.parentID || "" }
    } catch {
      return {}
    } finally {
      clearTimeout(timer)
    }
  }

  /* Is this a browser sub-agent's session? Known from its own turns in this
   * process, else from the session itself (a restart mid-task). */
  async function isBrowserSession(sid) {
    if (seenBrowserChild.has(sid) || work?.tracked(sid)) return true
    return (await describeSession(sid)).agent === "browser"
  }

  /* The text of a session's latest finished compaction summary, or "". */
  async function latestSummary(sid) {
    return summaryIn((await readSession(sid)).messages)
  }
  function summaryIn(messages) {
    for (let i = messages.length - 1; i >= 0; i--) {
      const info = messages[i]?.info
      if (info?.role !== "assistant" || !info.summary || !info.finish || info.error) continue
      const text = (messages[i].parts ?? []).filter((p) => p?.type === "text").map((p) => p.text ?? "").join("").trim()
      if (text) return text
    }
    return ""
  }

  /* The agent a chat's turns run as: the newest user message that names one,
   * else the harness's own record from chat.message. */
  function agentIn(messages, sid) {
    for (let i = (messages?.length ?? 0) - 1; i >= 0; i--) {
      const info = messages[i]?.info
      if (info?.role === "user" && typeof info.agent === "string" && info.agent) return info.agent
    }
    return (sid && sessionAgent.get(sid)) || ""
  }

  /* A sub-agent's session (browser, research, …): its turns are one job, so
   * its earlier tool output is never cut (lib/talk-context.js). */
  function isSubagentChat(messages, sid) {
    if (seenBrowserChild.has(sid) || seenResearchChild.has(sid) || work?.tracked(sid)) return true
    return SUBAGENTS.has(agentIn(messages, sid))
  }

  /* A chat's code-kept block for a compaction (lib/task-state.js
   * chatStateBlock): made with the compaction's prompt, then kept by its
   * summary's id, so every request after it carries the same text and the
   * prompt cache still matches. After a restart it is made again from the
   * stored history, once per summary. */
  const chatBlocks = new Map()
  const pendingChatBlocks = new Map()
  const requestWords = (text) => userWordsOnly(text)
  async function chatBlockFor(sid, summary) {
    const id = summary?.info?.id
    if (!id) return ""
    if (chatBlocks.has(id)) return chatBlocks.get(id)
    let block = ""
    const pending = pendingChatBlocks.get(sid)
    if (pending && Number(summary.info.time?.created ?? Infinity) >= pending.at) {
      block = pending.block
      pendingChatBlocks.delete(sid)
    } else {
      const { messages } = await readSession(sid)
      if (!messages.length) return ""
      block = chatStateBlock(chatFacts(messages, { beforeID: summary.info.parentID, wordsOf: requestWords }))
    }
    if (chatBlocks.size >= 256) chatBlocks.delete(chatBlocks.keys().next().value)
    chatBlocks.set(id, block)
    return block
  }

  /* ---- the task record (lib/task-record.js) ------------------------------ */

  /* George's message only says go on with what is there: "Continue", the
   * app's "Approve and carry on", "go ahead". Not words for the task. */
  const goesOn = (words) => Boolean(asksToContinue?.(words)) || isCarryOn(words) || saysGoAhead(words)

  /* His message before `latest` in the chat's history, with the day it was
   * said: [{words, day}], or [] when there is none or it cannot be read. */
  function earlierWords(history, latest) {
    const said = []
    for (const m of Array.isArray(history) ? history : []) {
      if (m?.info?.role !== "user") continue
      const own = (m.parts ?? []).filter((p) => p?.type === "text" && !p.synthetic).map((p) => p.text ?? "").join(" ")
      const words = userWordsOnly(own)
      const created = Number(m.info.time?.created)
      if (words && !goesOn(words)) said.push({ words, day: Number.isFinite(created) && created > 0 ? dayOf(new Date(created)) : dayOf() })
    }
    const norm = (t) => String(t).replace(/\s+/g, " ").trim()
    const at = said.map((s) => norm(s.words)).lastIndexOf(norm(latest))
    const before = at >= 0 ? said.slice(0, at) : said.filter((s) => norm(s.words) !== norm(latest))
    return before.slice(-1)
  }

  /* The record for a browser `task` call, and the chat history it was read
   * with: a resume's own record with George's latest words added, or a new
   * record built from his words, the chat, his earlier answers and the job
   * they ask for. A resume whose record was lost (a restart with no state
   * file) gets a new one under its task_id. */
  async function recordFor(input, args) {
    const sid = input.sessionID
    const chat = await rootSessionOf(sid)
    const resumed = String(args.task_id ?? "").trim()
    const history = await chatMessagesOf(sid, "task_record")
    const ctx = { today: dayOf(), history, wordsOf: (t) => userWordsOnly(t) }
    const latest = personSaid.get(sid) ?? personSaid.get(chat) ?? ""
    let rec = resumed ? records.of(resumed) : null
    if (rec) {
      if (latest && !goesOn(latest) && addWords(rec, latest, ctx)) {
        tracer.write({ kind: "task_record.words", sessionID: sid, id: rec.id, task: resumed })
      }
      const job = rec.job && JOBS_ON ? loadJobs(JOBS_FILE).find((j) => j.name === rec.job) ?? null : null
      for (const c of clashesIn(rec, args.prompt, { job })) noteClash(rec, c)
      records.changed(rec)
      return { rec, history }
    }
    // His words from the chat itself when this process never heard them (a
    // restart since he spoke); and when his message is short, an answer to
    // the assistant ("7pm", "yes, that one"), the message before it, the
    // request it answers, goes on too.
    const words = latest || earlierWords(history, "")[0]?.words || ""
    const earlier = words.split(/\s+/).length < EARLIER_UNDER_WORDS ? earlierWords(history, words) : []
    // The job is picked as lib/jobs.js always picked it: from his own words
    // when they are long enough to go on the task, else from the task.
    const carried = wordsBlock(words) ? words : earlier.map((e) => e.words).find((w) => wordsBlock(w)) ?? ""
    const jobs = JOBS_ON ? loadJobs(JOBS_FILE) : []
    const job = jobs.length ? pickJob(jobs, carried || args.prompt) : null
    const look = job ? onlyALook(job, carried, args.prompt) : false
    rec = records.add(buildRecord({
      ...ctx, chat, words, earlier, title: args.description, prompt: args.prompt, job, look,
      nameBook: saidNames.of(sid) ?? saidNames.of(chat),
      answers: chatAnswers ? chatAnswers.rowsFor(chat, args.prompt) : [],
    }))
    if (resumed) records.bind(resumed, rec.id)
    tracer.write({
      kind: "task_record.start", sessionID: sid, id: rec.id, resumed: Boolean(resumed), words: rec.words.length,
      mode: rec.mode, job: rec.job, conditions: rec.conditions.length, answers: rec.answers.length,
    })
    return { rec, history }
  }

  /* What a browser task's run has noted so far, kept on its record so a
   * restart does not lose it (the ledger, captures and budget are in memory). */
  function noteRun(sid) {
    const rec = records?.of(sid)
    if (!rec) return
    const snap = ledger?.snapshot(sid)
    const sum = work?.summary(sid)
    const found = captures?.found(sid) ?? []
    rec.run = {
      url: snap?.url ?? rec.run?.url ?? "",
      qa: (snap?.qa ?? rec.run?.qa ?? []).slice(-60),
      entries: (snap?.entries ?? rec.run?.entries ?? []).slice(-60),
      found: found.length
        ? found.map((f) => ({ site: f.site, items: f.items.slice(-30).map((it) => ({ name: it.name, price: it.price ?? "", notes: it.notes ?? "" })), none: f.none }))
        : rec.run?.found ?? [],
      blocked: sum?.blocked ?? rec.run?.blocked ?? [],
      failed: (sum?.failed ?? rec.run?.failed ?? []).slice(-12),
    }
    records.changed(rec, { soon: true })
  }

  /* The state block for a browser task (lib/task-state.js), from the ledger,
   * captures and budget, or from its record's copy when they were lost. The
   * task as it was given goes without the record block, which goes on its own. */
  function stateFor(sid) {
    const run = records?.of(sid)?.run ?? null
    const snap = ledger?.snapshot(sid) ?? (run ? { task: "", url: run.url, qa: run.qa, entries: run.entries } : null)
    const found = captures?.found(sid) ?? []
    return stateBlock({
      snapshot: snap && records ? { ...snap, task: withoutRecords(snap.task) } : snap,
      captured: captures?.list(sid) ?? [],
      found: found.length ? found : run?.found ?? [],
      work: work?.summary(sid) ?? (run ? { blocked: run.blocked, failed: run.failed } : null),
    })
  }

  /* The record and the code-kept state, as one block for a compaction. */
  function compactionBlock(sid) {
    const rec = records?.of(sid)
    return [rec ? renderRecord(rec, { conditions: GROUNDING_ON }) : "", stateFor(sid)].filter(Boolean).join("\n\n")
  }

  const questions = QUESTIONS_ON
    ? createQuestionBridge({
        api: questionApi(),
        opencode: opencodeQuestions(input, directory),
        describeSession,
        pagePicture: browserPagePicture(),
        origin: QUESTION_ORIGIN,
        graceMs: QUESTION_GRACE_MS,
        trace: (row) => tracer.write(row),
      })
    : null
  if (questions && !questionSweepStarted) {
    questionSweepStarted = true
    // Not awaited: pal-api being slow must not hold up the plugin's boot.
    questions.sweepStale().catch(() => {})
  }

  /* `now` is reported for the same reason the other three are: "was the model
   * told the date on this turn?" has to be answerable from one boot line, not
   * reconstructed from a session database after the fact — which is how the
   * missing calendar was found in the first place. */
  /* One per process, shared by every directory instance of this plugin. Its
   * rows go to the first instance's trace, and each warm is one log line. */
  const warm = acquireKeepWarm({
    agentDir: AGENT_DIR,
    log: (row) => {
      tracer.write(row)
      if (row.kind !== "warm.captured") {
        const { kind, ...rest } = row
        console.error(`[pal-harness] ${kind} ${JSON.stringify(rest)}`)
      }
    },
  })

  /* With nothing captured yet (a new box, a new person), there is no prefix
   * to warm, and only opencode can build one. So one short chat is made in
   * this instance's folder (opencode's own, where a chat with no folder
   * chosen runs), with the keep-warm's random warm-up text as its message.
   * opencode sends its first step like any new chat's; the fetch tap keeps it
   * and answers it itself, so the model never reads it; the chat is deleted
   * straight after. chat.message lets the text through untouched (no route,
   * no blocks), so the prefix is the one a person's first message gets. */
  async function primeWarm() {
    const kw = warm?.keepWarm
    if (!kw) return "off"
    if (typeof client?.session?.create !== "function" || typeof client?.session?.prompt !== "function"
        || typeof client?.session?.delete !== "function") return "no_client"
    const query = { directory }
    let sid = ""
    let timer
    const within = (promise) => Promise.race([
      promise,
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error("timeout")), WARM_PRIMER_TIMEOUT_MS) }),
    ]).finally(() => clearTimeout(timer))
    try {
      const made = await within(client.session.create({ query, body: { title: WARM_PRIMER_TITLE } }))
      sid = made?.data?.id || ""
      if (!sid) return "no_session"
      await within(client.session.prompt({
        path: { id: sid }, query,
        body: { agent: kw.primaryAgent(), parts: [{ type: "text", text: kw.primerText() }] },
      }))
      return kw.hasPrefix() ? "captured" : "not_captured"
    } catch (err) {
      if (sid && typeof client?.session?.abort === "function") {
        await client.session.abort({ path: { id: sid }, query }).catch(() => {})
      }
      return `error: ${String(err?.message || err)}`
    } finally {
      if (sid) {
        await client.session.delete({ path: { id: sid }, query }).catch(() => {})
        // Its own "busy" may not have reached the event hook's idle yet: it
        // must not hold the warm back as a session in a turn.
        kw.noteSession(sid, false)
      }
    }
  }
  /* One sign-in warm at a time: a person signing in on two devices at once
   * gets one warm, not two. */
  let signInWarm = null
  function warmAtSignIn() {
    if (!warm) return Promise.resolve()
    if (signInWarm) return signInWarm
    signInWarm = (async () => {
      if (!warm.keepWarm.hasPrefix()) {
        const outcome = await primeWarm()
        tracer.write({ kind: "warm.primed", directory, outcome })
      }
      await warm.keepWarm.signIn()
    })().finally(() => { signInWarm = null })
    return signInWarm
  }

  tracer.write({
    kind: "harness.init", directory,
    router: Boolean(route), gate: GATE_ON, persona: Boolean(persona), now: NOW_ON,
    projectFiling: PROJECT_FILING_ON, budgets: BUDGETS_ON, questions: Boolean(questions),
    warm: Boolean(warm),
  })
  console.error(`[pal-harness] loaded (router=${Boolean(route)} gate=${GATE_ON} persona=${Boolean(persona)} now=${NOW_ON} projectFiling=${PROJECT_FILING_ON} questions=${Boolean(questions)} warm=${Boolean(warm)} trace=${TRACE_FILE || "off"})`)

  const hooks = {
    /* Flush on teardown. Without this the last <=500ms of rows die with the
     * process — which is exactly the window containing the final tool call and
     * the turn's outcome, i.e. the rows a trace is FOR. The question bridge
     * goes first: its withdrawals write trace rows of their own. */
    dispose: async () => {
      try { questions?.dispose() } catch {}
      try { warm?.keepWarm.persist() } catch {}
      try { records?.flush() } catch {}
      try { tracer.close() } catch {}
    },

    /* ---- trace capture, and the question bridge ------------------------
     * opencode hands this hook `{id, type, properties}` (1.18.4's plugin
     * loader). It used to read `event.data`, which is always undefined — so
     * `budgets.forget` never ran and every event row carried no session. */
    event: async ({ event }) => {
      const type = event?.type
      const props = event?.properties ?? event?.data ?? {}
      if (stepText && typeof type === "string" && type.startsWith("message.")) {
        try { stepText.onEvent(type, props) } catch (err) {
          tracer.write({ kind: "ask-then-act.error", error: String(err) })
        }
      }
      if (questions && typeof type === "string" && type.startsWith("question.")) {
        try { questions.onEvent(event) } catch (err) {
          tracer.write({ kind: "question.error", error: String(err) })
        }
      }
      if (budgets && (type === "session.deleted" || type === "session.idle")) {
        const sid = props.sessionID || props.info?.id
        if (sid) budgets.forget(sid)
      }
      /* Which sessions are in a turn, for the warm after background work
       * (lib/keep-warm.js), and a deleted chat's kept cut (lib/tool-trim.js). */
      if (type === "session.status" || type === "session.idle" || type === "session.deleted") {
        try {
          const sid = props.sessionID || props.info?.id
          const t = props.status?.type
          warm?.keepWarm.noteSession(sid, type === "session.status" && (t === "busy" || t === "retry"))
          if (type === "session.deleted" && sid) toolTrim.forget(sid)
        } catch (err) {
          tracer.write({ kind: "warm.session_error", error: String(err) })
        }
      }
      /* A task that ended in an error never reaches tool.execute.after (opencode
       * calls it only on success): its part settling is what lets the chat's
       * browser go, so a retry in the same turn is not refused. */
      if (oneJob && type === "message.part.updated" && props.part?.type === "tool" && props.part.tool === "task"
          && (props.part.state?.status === "completed" || props.part.state?.status === "error")) {
        oneJob.release(props.part.callID)
      }
      if (type === "session.idle" || (type === "session.status" && props.status?.type === "idle")) {
        postMoved(props.sessionID).catch(() => {})  // not awaited: the stream never waits on pal-api
        // A turn in an app's own folder is a version (lib/made-apps.js). Not awaited either.
        if (appTurns) postTurnDone(props.sessionID).catch(() => {})
        // Its turn is over, so no browser task it started is still running.
        if (oneJob && props.sessionID) oneJob.idle(props.sessionID)
        // A turn stopped while a call waited on its card: the card is
        // withdrawn, or parked when its call is deferrable (lib/approval-hold.js).
        if (holds && props.sessionID) holds.stopped(props.sessionID)
      }
      if (speed) {
        try { speed.onEvent(type, props) } catch (err) {
          tracer.write({ kind: "telemetry.error", error: String(err) })
        }
      }
      if (turns) {
        if (type === "session.error") {
          turns.error(props.sessionID, props.error)
        } else if (type === "session.idle" || (type === "session.status" && props.status?.type === "idle")) {
          // Not awaited: the report reads the session back, and the event
          // stream must not wait on that.
          turns.idle(props.sessionID).catch(() => {})
        }
      }
      // What a browser task's model is doing, for the stall watch.
      if (stalls && typeof type === "string") {
        try {
          const sid = props.sessionID || props.part?.sessionID || props.info?.sessionID || ""
          if (sid && seenBrowserChild.has(sid)) {
            if (type === "session.status") {
              const t = props.status?.type
              stalls.busy(sid, t === "busy" || t === "retry")
            } else if (type === "session.idle") {
              stalls.busy(sid, false)
            } else if (type.startsWith("message.")) {
              stalls.activity(sid)
              if (props.info?.providerID) stalls.model(sid, props.info.providerID, props.info.modelID)
              if (props.info?.tokens) stalls.context(sid, props.info.tokens)
              const st = props.part?.type === "tool" ? props.part.state?.status : ""
              if (st === "running" && !seenRunningCall.has(props.part.callID)) {
                if (seenRunningCall.size >= 512) seenRunningCall.delete(seenRunningCall.values().next().value)
                seenRunningCall.add(props.part.callID)
                stalls.toolStart(sid)
              } else if ((st === "completed" || st === "error") && seenRunningCall.delete(props.part.callID)) {
                stalls.toolEnd(sid)
              }
            }
          }
        } catch (err) {
          tracer.write({ kind: "stall.event.error", error: String(err) })
        }
      }
      /* A recipe run the site turned down (answers-ledger.js noteRefusal):
       * read here, because a failed flow_run never reaches
       * tool.execute.after, where the page tools' results are read. */
      if (ledger && type === "message.part.updated" && props.part?.type === "tool"
          && props.part.tool === "playwright_flow_run" && props.part.state?.status === "error") {
        try {
          const found = ledger.noteRefusal(props.part.sessionID, props.part.state.error)
          if (found.length) tracer.write({ kind: "refusal.noted", sessionID: props.part.sessionID, tool: props.part.tool, count: found.length })
        } catch (err) {
          tracer.write({ kind: "ledger.error", error: String(err) })
        }
      }
      /* A page call nas-browser-v2 refused because the page held that answer
       * before this task (held-answers.mjs): read here for the same reason,
       * so the call made again is held to George's own words (entryStop). */
      if (ledger && type === "message.part.updated" && props.part?.type === "tool"
          && ENTRY_STOP_TOOLS.has(props.part.tool) && props.part.state?.status === "error") {
        try {
          ledger.noteHeld(props.part.sessionID, props.part.tool, props.part.state.input, props.part.state.error)
        } catch (err) {
          tracer.write({ kind: "ledger.error", error: String(err) })
        }
      }
      /* An upload waiting on the person's card, or declined, is a failed tool
       * too: the record says what became of each file (answers-ledger.js noteUpload). */
      if (ledger && type === "message.part.updated" && props.part?.type === "tool"
          && props.part.tool === "playwright_browser_upload_from" && props.part.state?.status === "error") {
        try {
          ledger.noteUpload(props.part.sessionID, props.part.state.input, props.part.state.error, false)
        } catch (err) {
          tracer.write({ kind: "ledger.error", error: String(err) })
        }
      }
      /* A booking commit that ended, declined or made (lib/booking-claims.js).
       * A declined one is a failed tool, so it is read here, not in
       * tool.execute.after (H0-FINDINGS). */
      if (bookings && type === "message.part.updated" && props.part?.type === "tool"
          && props.part.tool === "playwright_browser_commit"
          && (props.part.state?.status === "completed" || props.part.state?.status === "error")) {
        try {
          const part = props.part
          const chat = part.state.input?.session_id || await rootSessionOf(part.sessionID)
          const text = part.state.status === "error" ? part.state.error : part.state.output
          const kept = bookings.record(chat, { callID: part.callID, what: part.state.input?.what, text, today: dayOf() })
          if (kept) tracer.write({ kind: "booking.commit", sessionID: part.sessionID, chat, outcome: kept.outcome })
        } catch (err) {
          tracer.write({ kind: "booking.error", error: String(err) })
        }
      }
      /* A browser page action that ended, failed or not, for the task's
       * Failed list (lib/browser-budget.js outcome). Read here because
       * tool.execute.after never runs for a failed tool (H0-FINDINGS). */
      if (work && type === "message.part.updated" && props.part?.type === "tool") {
        try {
          const part = props.part
          const st = part.state?.status
          if ((st === "completed" || st === "error") && work.tracked(part.sessionID)) {
            const text = st === "error" ? part.state.error : part.state.output
            // A list's actions each as its own (lib/browser-steps.js).
            const ended = part.tool === STEPS_TOOL
              ? innerResults(part.state.input, text).filter((r) => r.ran)
                .map((r) => ({ callID: `${part.callID}#${r.n}`, tool: r.tool, args: r.args, ok: r.ok, text: r.text }))
              : [{ callID: part.callID, tool: part.tool, args: part.state.input, ok: st === "completed", text }]
            for (const e of ended) work.outcome(part.sessionID, e)
          }
        } catch (err) {
          tracer.write({ kind: "browser_budget.error", error: String(err) })
        }
      }
      /* A chat's first title, held to George's words (lib/title-context.js,
       * 2026-11-06 demo: "What's on the shopping list?" for "what do I have
       * on this week?"). Not awaited: the event stream never waits on it. */
      if (TITLE_CHECK_ON && type === "session.updated" && props.info?.id && !props.info.parentID
          && props.info.title !== WARM_PRIMER_TITLE) {
        checkTitle(props.info).catch((err) => tracer.write({ kind: "title.check_error", sessionID: props.info.id, error: String(err) }))
      }
      /* Someone signed in on a device (gateway/auth/warm.py): read the
       * assistant's first step into the model's cache now, before they open a
       * chat. Not awaited: the event stream never waits on a warm. */
      if (type === "tui.command.execute" && props.command === WARM_SIGN_IN_COMMAND) {
        warmAtSignIn().catch((err) => tracer.write({ kind: "warm.sign_in_error", error: String(err) }))
        return
      }
      if (!type || isNoisy(type)) return
      tracer.write({ kind: "event", type, sessionID: props.sessionID })
    },

    /* ---- the turn preamble: [NOW] then the router directive --------------
     * FAIL-OPEN, exactly as router.js is: any trouble must be
     * indistinguishable from "nothing matched", never a failed turn.
     *
     * TWO blocks now, and the ORDER is deliberate. [NOW] goes on top, so the
     * router directive keeps the adjacency to the user's own words that lesson 1
     * measured — and so a directive that says "resolve the date against the
     * current date above" has something above it to mean.
     *
     * [NOW] does NOT depend on the router. It is prepended even when routing is
     * off, unavailable, or returns nothing: a turn with no directive still needs
     * to know what day it is, and the whole bug this fixes arrived on a turn the
     * router handled perfectly. */
    "chat.message": async (input, output) => {
      try {
        const parts = output?.parts || []
        // A quick view (lib/quick-view.js): answered on the device and stored
        // with noReply, so no turn follows. Nothing below may run for it — it
        // would route, prepend blocks into the stored words and start a turn
        // that never ends. Its words are the chat's earlier request, though.
        if (isQuickView(parts)) {
          const sid = output?.message?.sessionID || input?.sessionID || ""
          rememberRequest?.(sid, quickWords(parts))
          tracer.write({ kind: "quick.view", sessionID: sid })
          return
        }
        // The harness's own note after a call written out as text
        // (redoWrittenCall): the same turn going on, so nothing a new turn
        // does — no date, no route, no fresh budget.
        if (isRedoNote(parts)) return
        // The warm-up chat at a sign-in (primeWarm): its first step must be
        // exactly a new chat's, so nothing is added to it, and it is no turn
        // of anyone's — no route, no report, no title.
        if (warm && parts.some((p) => p?.type === "text" && warm.keepWarm.isPrimer(p.text))) return
        // A turn begins in an app's own folder (lib/made-apps.js): its end is
        // reported with the person's own words, before any block is added to
        // them. Here, ahead of the checks below, so a message that is only a
        // picture is a turn too.
        if (appTurns && !(input?.agent && SUBAGENTS.has(input.agent)) && appRepoOf(directory)) {
          const typed = parts.filter((p) => p?.type === "text" && typeof p.text === "string" && !p.synthetic).map((p) => p.text).join(" ")
          appTurns.started(output?.message?.sessionID || input?.sessionID || "", memoryWords(typed))
        }
        const textPart = parts.find((p) => p.type === "text" && typeof p.text === "string")
        const text = parts.filter((p) => p.type === "text").map((p) => p.text).join(" ")
        if (!text.trim()) return
        // What the person wrote, without a client's synthetic steer (Talk's
        // spoken style) — for everything that searches on their words.
        const own = ownText(parts)
        // The harness's own ask to a browser to go on with a cut report
        // (tool.execute.after): the same task going on, not a new one, so no
        // date, no task to note and no fresh budget.
        if (isContinueAsk(text)) return

        const sid = output?.message?.sessionID || input?.sessionID || "*"
        if (input?.agent && sid !== "*") noteAgent(sid, String(input.agent))
        if (sid !== "*" && isTalkText(text)) {
          if (talkSessions.size >= 512 && !talkSessions.has(sid)) talkSessions.delete(talkSessions.values().next().value)
          talkSessions.add(sid)
        }
        stepText?.userSpoke(sid)
        refusedCalls?.userSpoke(sid)
        doneClaims?.userSpoke(sid)
        if (sid !== "*") {
          if (turnToStamp.size >= 512 && !turnToStamp.has(sid)) turnToStamp.delete(turnToStamp.values().next().value)
          turnToStamp.add(sid)
        }
        heldThisTurn.delete(sid)
        datesHeld.delete(sid)
        stoppedRecipes.delete(sid)
        turns?.started(sid, { subagent: Boolean(input?.agent && SUBAGENTS.has(input.agent)) })
        // A chat's own turn, not a sub-agent's: timed for the box's telemetry.
        if (speed && !(input?.agent && SUBAGENTS.has(input.agent))) speed.started(sid)
        const blocks = []

        if (NOW_ON) {
          // Never allowed to cost a turn: a broken clock or a bad TZ name must
          // degrade to "no date block", which is only ever the old behaviour.
          try {
            blocks.push(nowBlock())
          } catch (err) {
            tracer.write({ kind: "now.error", error: String(err) })
          }
        }

        // [NOW] still goes to a sub-agent — it has no other source for the date.
        // The sub-agent check is made once and only when something needs it.
        const auto = Boolean(autoThinking) && wantsAuto(input, output)
        const subagent = (route || MEMORY_ON || PROJECT_CONTEXT_ON || ledger || auto || parked)
          ? await isSubagentTurn(input, sid) : false
        // A builder's turn (LEAN_AGENTS): the person's own chat, with none of
        // the everyday assistant's blocks below.
        const lean = LEAN_AGENTS.has(String(input?.agent ?? ""))
        // A sub-agent's user message is its task: where its answers may come from.
        if (ledger && subagent) ledger.noteTask(sid, text)
        // Where its values may come from: the chat it works for, read from
        // that chat's history when a restart lost what was noted (lib/provenance.js).
        if (provenance && subagent && sid !== "*") {
          try {
            const chat = await rootSessionOf(sid)
            provenance.link(sid, chat)
            if (chat && chat !== sid && !provenance.knows(chat)) {
              const history = await chatMessagesOf(chat, "provenance")
              if (history) provenance.seed(chat, history, { wordsOf: (t) => userWordsOnly(t), except: (c) => ledger?.unsourced(c) ?? [] })
            }
          } catch (err) {
            tracer.write({ kind: "provenance.error", error: String(err) })
          }
        }
        // A browser task's list, from the block on its task (lib/work-list.js).
        // Only the harness writes that block, so no sub-agent check is needed
        // (and `subagent` is not worked out at all with every feature off).
        if (listIdIn(text)) keepLimited(childLists, sid, listIdIn(text))
        // George's own words, for the next browser task in this chat; and a
        // browser task's limits, for its clicks (lib/own-words.js).
        if (!subagent && sid !== "*") {
          const words = userWordsOnly(own)
          if (words) {
            if (personSaid.size >= 256 && !personSaid.has(sid)) personSaid.delete(personSaid.keys().next().value)
            personSaid.set(sid, words)
            if (CUT_NAMES_ON) saidNames.heard(sid, words)
          }
          addressBook.heard(sid, words, own)
          // His words, and what the app sent with them: sources (lib/provenance.js).
          if (provenance) {
            provenance.heard(sid, words)
            provenance.output(sid, "chat", own, "")
          }
          const screen = parseScreen(text)
          if (screen) {
            if (screens.size >= 256 && !screens.has(sid)) screens.delete(screens.keys().next().value)
            screens.set(sid, screen)
          } else {
            screens.delete(sid)
          }
          // A browser task of this chat went quiet and never came back: say so.
          const stalled = stallNotes.get(sid)
          if (stalled) {
            stallNotes.delete(sid)
            const w = who()
            blocks.push(`[BROWSER] ${stalled} Tell ${w.name} this plainly if ${w.his} message is about the browser task.`)
          }
          // "Tell Rohit I've booked the table" after the Book card was declined.
          const booking = bookings?.last(sid)
          if (booking?.outcome === "declined" && claimsBooked(words)) {
            blocks.push(unmadeNote(booking, who()))
            tracer.write({ kind: "booking.unmade_note", sessionID: sid })
          }
        } else if (subagent) {
          // What the task hands the browser is something it was shown.
          pageIds?.saw(sid, text, { start: true })
          // A recipe named in the task is one it was shown (the recipe guard,
          // lib/actions.js).
          flowNames?.saw(sid, text)
          // A browser task's first message carries its record's id: from
          // here on the record is this task's (lib/task-record.js), and its
          // limits and look are read from it, not from the prompt's words.
          const rid = records && sid !== "*" ? recordIdIn(text) : ""
          const rec = rid ? records.bind(sid, rid) : null
          if (rid) tracer.write({ kind: "task_record.bind", sessionID: sid, id: rid, bound: Boolean(rec) })
          // His own words, apart from the assistant's brief (answers-ledger.js "brief").
          if (ledger && rec) ledger.noteOwnWords(sid, [...(rec.earlier ?? []), rec.words, ...(rec.said ?? [])])
          const stamp = rec ? limitsStamp(rec.limits) : text.includes(wordsHeader()) ? limitsStamp(limitsInPrompt(text)) : ""
          if (stamp) {
            if (childLimits.size >= 256 && !childLimits.has(sid)) childLimits.delete(childLimits.keys().next().value)
            childLimits.set(sid, stamp)
          }
          if (rec?.mode === "look" && JOBS_ON) {
            if (lookChildren.size >= 256 && !lookChildren.has(sid)) lookChildren.delete(lookChildren.values().next().value)
            lookChildren.add(sid)
          }
        }
        // A call the gate parked and George has approved since: back to the
        // agent that made it (lib/parked-calls.js). The app's own "Approve and
        // carry on" message asks for nothing else, so it skips the router and
        // the cards, whose word for it would be a guess.
        let handedBack = false
        if (parked && !subagent && sid !== "*") {
          handBacks.delete(sid)
          const words = userWordsOnly(own)
          const carryOn = isCarryOn(words)
          if (carryOn || saysGoAhead(words) || Boolean(asksToContinue?.(words))) {
            const grants = await parked.grantsFor(sid)
            if (grants.length) {
              blocks.push(handBackBlock(grants, who(), { carryOn }))
              if (handBacks.size >= 256) handBacks.delete(handBacks.keys().next().value)
              handBacks.set(sid, grants)
              handedBack = carryOn
              tracer.write({ kind: "parked.hand_back", sessionID: sid, ids: grants.map((g) => g.id), carryOn })
            }
          }
        }
        // The turn after a recipe was learned: "that's wrong" undoes it
        // (lib/recipe-learn.js).
        if (recipeLearn && !subagent && sid !== "*") {
          try {
            recipeLearn.heard(sid, userWordsOnly(own))
            const block = await recipeLearn.onUserTurn(sid, userWordsOnly(own))
            if (block) blocks.push(block)
          } catch (err) {
            tracer.write({ kind: "recipe_learn.error", error: String(err) })
          }
        }
        // Each turn of a browser task (its task, or a resume with George's
        // words) gets its budget (lib/browser-budget.js); opencode's own
        // "Continue…" after a compaction is the same turn going on.
        if (work && subagent && input?.agent === "browser" && sid !== "*" && !/^Continue if you have next steps/.test(text.trim())) {
          const job = jobInPrompt(text) || work.summary(sid)?.job || ""
          work.start(sid, { job, found: captures ? captures.foundCount(sid) : 0 })
          tracer.write({ kind: "browser_budget.start", sessionID: sid, job })
        }
        if (JOBS_ON && input?.agent === "browser" && sid !== "*" && lookInPrompt(text)) {
          if (lookChildren.size >= 256 && !lookChildren.has(sid)) lookChildren.delete(lookChildren.values().next().value)
          lookChildren.add(sid)
        }
        // A browser task is open from its first message until its result
        // comes back: one that never does was stopped (router-core.js). Its
        // chat is the one that just started a browser task — no session
        // lookup on a sub-agent's turn (subagent-routing.test.mjs).
        if (subagent && input?.agent === "browser" && !seenBrowserChild.has(sid)) {
          let parent = ""
          let newest = 0
          for (const [chat, at] of startingBrowserTasks) {
            if (Date.now() - at < 30_000 && at > newest) { parent = chat; newest = at }
          }
          if (parent) {
            startingBrowserTasks.delete(parent)
            if (rememberBrowserStart) rememberBrowserStart(parent, sid)
          }
          if (seenBrowserChild.size >= 256) seenBrowserChild.delete(seenBrowserChild.values().next().value)
          seenBrowserChild.add(sid)
        }
        if (subagent && input?.agent === "research" && !seenResearchChild.has(sid)) {
          let parent = ""
          let newest = 0
          for (const [chat, at] of startingResearchTasks) {
            if (Date.now() - at < 30_000 && at > newest) { parent = chat; newest = at }
          }
          if (parent) {
            startingResearchTasks.delete(parent)
            if (rememberResearchStart) rememberResearchStart(parent, sid)
          }
          if (seenResearchChild.size >= 256) seenResearchChild.delete(seenResearchChild.values().next().value)
          seenResearchChild.add(sid)
        }
        // [MEMORY] is fetched alongside the router's model call rather than
        // after it — it is one SELECT on pal-api and must not add its latency to
        // a turn the router is already making the user wait for.
        // The session goes with it: the project the thread is filed under
        // decides which project's facts it may be shown (memory_core "Scope").
        const session = sid === "*" ? "" : sid
        // "…and how does it affect me?" (lib/for-you.js): the same request
        // also brings the [YOU] block, the person's circumstances with their
        // sources. Decided on their own words, so it holds with the router off.
        // "What do you know about me / George?" too (asksAboutSelf): on
        // 2026-11-22 it came with no block at all, and the model offered the
        // box's home folder as a fact about him.
        const forYou = MEMORY_ON && !subagent
          && (asksForYou(memoryWords(own)) || asksAboutSelf(memoryWords(own), currentPerson()))
        // Not on the app's "Approve and carry on" (handedBack): on 2026-10-31
        // (ses_e6e157d4e) [TRIP]/[MEMORY] there seeded an invented
        // "[SKILL: trips.get — …]" reply instead of the approved call.
        const memoryP = (MEMORY_ON && !subagent && !handedBack && !lean)
          ? memoryBlock(own, { base: API_BASE, session, forYou })
          : Promise.resolve("")
        // [PROJECT] likewise, alongside: the thread's filing, or the id the
        // client's own block named while a new thread is not filed yet.
        const projectP = (PROJECT_CONTEXT_ON && !subagent && !lean)
          ? projectContext({ base: API_BASE, session, project: projectFromBlock(text) })
          : Promise.resolve({ projectId: "", block: "", continues: "" })
        // [TRIP] alongside (lib/trip-context.js): only while a trip is about
        // to start, under way or just over — pal-api answers "" otherwise.
        const tripP = (TRIP_CONTEXT_ON && !subagent && !handedBack && !lean && sid !== "*")
          ? tripNote({ base: API_BASE })
          : Promise.resolve({ block: "", phase: "" })
        // The action library (lib/actions.js): which PAL capabilities fit
        // George's own words this turn, asked alongside the router and
        // collected after it, so it adds no wait. In shadow mode it is only
        // traced.
        const ACTIONS_MODE = actionsMode()
        const actionWords = (ACTIONS_MODE !== "off" && !subagent && !handedBack && sid !== "*" && cardsFor(input?.agent))
          ? userWordsOnly(own) : ""
        const actionsAsk = actionWords ? searchAlongside(actionWords, { base: API_BASE }) : null
        let category = ""
        let skill = ""
        if (route && subagent) {
          tracer.write({ kind: "router.skip", sessionID: sid, agent: input?.agent || "", reason: "subagent" })
        } else if (route && handedBack) {
          forgetCategory?.(sid)
          tracer.write({ kind: "router.skip", sessionID: sid, agent: input?.agent || "", reason: "parked_hand_back" })
        } else if (route && lean) {
          tracer.write({ kind: "router.skip", sessionID: sid, agent: input?.agent || "", reason: "lean_agent" })
        } else if (route) {
          const t0 = Date.now()
          // Last turn's decision must not hold this one (WEB_FIRST_ON).
          forgetCategory?.(sid)
          const ctx = await route({
            prompt: text, session_id: sid, agent_id: input?.agent || "",
            // A change PAL made on the Mac in this chat: "undo that" is mac.undo.
            macChanged: macChanges.changed(sid),
            // PAL is watching the person on the Mac: "that's it" stops it.
            macWatching: macWatching.watching(sid),
            // What a person typed: opencode's synthetic parts (a background
            // task's result, a "Continue…") are nobody's request.
            typed: parts.filter((p) => p.type === "text" && !p.synthetic).map((p) => p.text).join(" "),
            onCategory: (c) => { category = String(c || "") },
            onSkill: (name) => { skill = String(name || "") },
          })
          tracer.write({ kind: "router", sessionID: sid, routed: Boolean(ctx), ms: Date.now() - t0 })
          if (ctx) blocks.push(ctx)
          // A job in an app on the Mac, which the browser sub-agent drives
          // (mac_drive, or mac_app handing a job of several steps on): the app
          // in front by the Mac's [CONTEXT] block is what "this" and "here"
          // mean in the new browser task (lib/screen.js taskBlock).
          if (!subagent && sid !== "*" && (category === "mac_drive" || category === "mac_app") && !screens.has(sid)) {
            const mac = parseMacContext(text)
            if (mac?.label) {
              if (screens.size >= 256) screens.delete(screens.keys().next().value)
              screens.set(sid, mac)
            }
          }
        }
        // Auto thinking: George's own words and the category the router just
        // gave them. A sub-agent's turn is left on the variant's own options.
        // A message made of opencode's synthetic parts only (a background
        // task's result) keeps the level the chat already has.
        if (auto && !subagent && sid !== "*" && !parts.filter((p) => p.type === "text").every((p) => p.synthetic)) {
          try {
            const d = autoThinking.decide(sid, { words: userWordsOnly(own), category })
            tracer.write({ kind: "thinking.auto", sessionID: sid, level: d.level, reason: d.reason, category })
          } catch (err) {
            tracer.write({ kind: "thinking.auto.error", error: String(err) })
          }
        }
        // The capabilities that fit, as cards, after the router's directive:
        // what the directive says to do, then what PAL has to do it with.
        if (actionWords) {
          let found = await actionsAsk.collect()
          tracer.write(shadowRow(sid, found, { mode: ACTIONS_MODE, query: actionWords, late: actionsAsk.late }))
          const onRoute = cardsOnRoute(category, parseScreen(text))
          if (!onRoute) tracer.write({ kind: "actions.cards.skip", sessionID: sid, reason: "screen" })
          // A turn about what is open on the Mac, or carrying the Mac's own
          // [CONTEXT] block, gets mac.context and mac.document.read as cards
          // whatever the index ranked: the first step reads the Mac. A change
          // in place (mac_edit) gets the two reads it starts from, the text
          // and the cells; mac.sheet.read joins a read when a sheet is in front.
          const macCards = macCardsFor(category, text, actionWords)
          if (macCards.length) found = withMacCards(found, macCards)
          if (ACTIONS_MODE === "cards" && found && onRoute) {
            const seen = shownCards.get(sid) || new Set()
            const { block, names } = cardsBlock(found, seen, { name: who().name, recipes: recipeCardsFor(input?.agent) })
            if (block) {
              blocks.push(block)
              for (const n of names) seen.add(n)
              if (shownCards.size >= 512 && !shownCards.has(sid)) shownCards.delete(shownCards.keys().next().value)
              shownCards.set(sid, seen)
              tracer.write({ kind: "actions.cards", sessionID: sid, names })
            }
          }
        }
        // The project before the facts: a fact marked "about this project"
        // reads after the block that says which project that is.
        const project = await projectP
        if (PROJECT_CONTEXT_ON && !subagent) {
          tracer.write({ kind: "project.context", sessionID: sid, project: project.projectId })
        }
        if (project.block) blocks.push(project.block)
        // The trip after the project: "the hotel" in the person's words now
        // has a name, and the time they say is the time where they are.
        // A trip just over stays off a turn planning the next (tripForTurn).
        const note = await tripP
        const trip = tripForTurn(note, skill)
        if (TRIP_CONTEXT_ON && !subagent) {
          tracer.write({ kind: "trip.context", sessionID: sid, injected: Boolean(trip),
            ...(note.block && !trip ? { left_off: note.phase, skill } : {}) })
        }
        if (trip) blocks.push(trip)
        // A chat started with "Continue in a new chat": the earlier one's
        // summary, on its first turn only (pal-api decides which turn that is).
        if (project.continues) blocks.push(project.continues)
        const memory = await memoryP
        if (MEMORY_ON && !subagent) {
          tracer.write({ kind: "memory", sessionID: sid, injected: Boolean(memory),
            ...(forYou ? { for_you: memory.startsWith("[YOU]") } : {}) })
        }
        if (memory) blocks.push(memory)

        if (!blocks.length) return
        const preamble = blocks.join("\n\n")
        // PAL's own blocks (what George told it before, the trip, the screen): a source too.
        if (provenance && !subagent && sid !== "*") provenance.output(sid, "context", preamble, "")

        // Into the USER TURN (lesson 1), by editing an existing part (lesson 2).
        // With the NAS's [PROJECT] in the preamble, the client's copy comes out
        // of the text, so the model is told one project, once.
        if (textPart) {
          const own = project.block ? withoutProjectBlock(textPart.text) : textPart.text
          textPart.text = `${preamble}\n\n${own}`
        } else pending.set(sid, preamble)   // no text part to carry it — fall back
      } catch (err) {
        tracer.write({ kind: "router.error", error: String(err) })
      }
    },

    /* ---- system prompt ---------------------------------------------------
     * Two jobs, both MUTATING IN PLACE (lesson 3 — reassignment is silently
     * discarded by the engine):
     *  1. Replace the stock coding-agent prompt with the PAL persona — but
     *     ONLY when it IS the stock prompt (STOCK_PROMPT; an agent with its
     *     own prompt file keeps it) and it is agent-sized. This hook also
     *     fires for auxiliary calls (title generation, ~2KB); replacing those
     *     breaks them (lesson 4 — which is also why this is guarded per call
     *     rather than a one-shot stash).
     *  2. Carry the turn preamble ([NOW] + any router directive) when the user
     *     turn had no text part to edit. A FALLBACK, not the main channel —
     *     lesson 1 is that this placement is the one that gets ignored. */
    /* What the compaction of a browser task must carry: the task, the page,
     * George's answers and the record, as code kept them (lib/task-state.js).
     * A browser task also gets its own prompt, short working notes instead of
     * opencode's coding-agent template, with the notes of the compaction
     * before put back: opencode leaves its own <prior-summary> out once a
     * plugin sets the prompt, and drops `context` too, so the block goes in
     * the prompt. Fails soft — a compaction without it is the old behaviour. */
    "experimental.session.compacting": async (input, output) => {
      try {
        /* The transform that follows is the compaction's own copy of the
         * history: left as it is, and any rebuild in force ends here. */
        fresh?.compacting(input?.sessionID)
        const sid = input?.sessionID
        // The task record first (lib/task-record.js): the summary is made
        // from George's own words, not from what the history retold.
        const block = sid ? compactionBlock(sid) : ""
        if (BROWSER_COMPACT_ON && sid && output && await isBrowserSession(sid)) {
          output.prompt = browserCompactionPrompt({ block, prior: await latestSummary(sid) })
          tracer.write({ kind: "compacting.browser_prompt", sessionID: sid, chars: output.prompt.length })
          return
        }
        /* A chat (the assistant, meeting notes): working notes, with the
         * request, pages, parts read and what was saved kept by code. A set
         * prompt drops opencode's `context`, so any other block goes in it. */
        if (CHAT_COMPACT_ON && sid && output) {
          const { messages } = await readSession(sid)
          if (CHAT_COMPACT_AGENTS.has(agentIn(messages, sid))) {
            const chat = chatStateBlock(chatFacts(messages, { wordsOf: requestWords }))
            output.prompt = chatCompactionPrompt({ block: [chat, block].filter(Boolean).join("\n\n"), prior: summaryIn(messages) })
            if (pendingChatBlocks.size >= 256 && !pendingChatBlocks.has(sid)) pendingChatBlocks.delete(pendingChatBlocks.keys().next().value)
            pendingChatBlocks.set(sid, { block: chat, at: Date.now() })
            tracer.write({ kind: "compacting.chat_prompt", sessionID: sid, chars: output.prompt.length, block: chat.length })
            return
          }
        }
        if (block && Array.isArray(output?.context)) {
          output.context.push(block)
          tracer.write({ kind: "compacting.state", sessionID: sid, chars: block.length })
        }
      } catch (err) {
        tracer.write({ kind: "compacting.error", error: String(err) })
      }
    },

    /* opencode 1.18.34 asks this before it adds "Continue if you have next
     * steps…" after an automatic compaction (`input.message` is the
     * compaction's own message). When the step before the compaction had
     * finished the answer (finish=stop), the turn was over: the continue only
     * starts a pass nobody asked for. Fails soft — unread, it goes ahead. */
    "experimental.compaction.autocontinue": async (input, output) => {
      try {
        const sid = input?.sessionID
        if (!NO_CONTINUE_AFTER_STOP_ON || !sid || !output || output.enabled === false) return
        const { messages } = await readSession(sid)
        if (!finishedBeforeCompaction(messages, input?.message?.id)) return
        output.enabled = false
        tracer.write({ kind: "compaction.no_continue", sessionID: sid, agent: String(input?.agent ?? "") })
      } catch (err) {
        tracer.write({ kind: "compaction.no_continue_error", error: String(err) })
      }
    },

    /* The turn right after a compaction works from the same state, attached
     * to opencode's "Continue if you have next steps…" for this request only:
     * a summary that got an answer's source wrong is corrected before the
     * browser acts on it. */
    "experimental.chat.messages.transform": async (_input, output) => {
      /* A Talk conversation: earlier turns' tool output cut short, and the
       * turn after a compaction asked to answer the person's last words out
       * loud (lib/talk-context.js). Before the browser's continue below, which
       * then finds no opencode continue to rewrite in a Talk session.
       * Any other chat's earlier turns are cut too, to a longer length
       * (PAL_HARNESS_TOOL_KEEP; off with PAL_HARNESS_TOOL_TRIM=off); not a
       * sub-agent's, whose turns are one job. Both only near a budget, and
       * then at a kept boundary, so the prompt cache holds (lib/tool-trim.js). */
      try {
        const messages = output?.messages
        const sid = Array.isArray(messages) ? messages[0]?.info?.sessionID : null
        if (sid && (talkSessions.has(sid) || messages.some(isTalkMessage))) {
          // Cut near the budget only, at a kept boundary (lib/tool-trim.js).
          const cut = toolTrim.apply(messages, { talk: true })?.cut ?? 0
          let continued = 0
          for (const m of messages) {
            if (!isAutoContinue(m)) continue
            // The text it first went out with, on every later request too.
            const id = m.info?.id
            let text = id ? talkContinued.get(id) : undefined
            if (text === undefined) {
              text = talkContinueText(personSaid.get(sid))
              if (id) {
                if (talkContinued.size >= 256) talkContinued.delete(talkContinued.keys().next().value)
                talkContinued.set(id, text)
              }
            }
            m.parts = [{ ...m.parts[0], text }, ...m.parts.slice(1)]
            continued++
          }
          if ((cut || continued) && !talkTraced.has(`${sid}|${cut}|${continued}`)) {
            if (talkTraced.size >= 512) talkTraced.delete(talkTraced.values().next().value)
            talkTraced.add(`${sid}|${cut}|${continued}`)
            tracer.write({ kind: "talk.context", sessionID: sid, cut, continued })
          }
        } else if (sid && TOOL_TRIM_ON && !isSubagentChat(messages, sid)) {
          const cut = toolTrim.apply(messages, { talk: false })?.cut ?? 0
          if (cut && !talkTraced.has(`${sid}|chat|${cut}`)) {
            if (talkTraced.size >= 512) talkTraced.delete(talkTraced.values().next().value)
            talkTraced.add(`${sid}|chat|${cut}`)
            tracer.write({ kind: "chat.trim", sessionID: sid, cut })
          }
        }
      } catch (err) {
        tracer.write({ kind: "talk.context_error", error: String(err) })
      }
      /* A call written into an earlier answer as text goes back without it
       * (lib/written-calls.js): the model is never shown one as its own words. */
      try {
        const n = writtenCallsOff(output?.messages)
        if (n) tracer.write({ kind: "written_call.history", sessionID: output?.messages?.[0]?.info?.sessionID, parts: n })
      } catch (err) {
        tracer.write({ kind: "written_call.error", error: String(err) })
      }
      /* A call that repeated itself to the output limit goes back to the model
       * as a one-line note, not as its garbled text (lib/runaway.js). */
      try {
        const n = shortenBrokenCalls(output?.messages)
        if (n) tracer.write({ kind: "broken_call.shortened", count: n })
      } catch (err) {
        tracer.write({ kind: "broken_call.error", error: String(err) })
      }
      /* Each call goes back as the model wrote it, without the arguments the
       * harness added (harnessArgsOf above). Traced once per session. */
      try {
        const n = harnessArgsOff(output?.messages, harnessArgsOf)
        const sid = output?.messages?.[0]?.info?.sessionID
        if (n && sid && !ownArgsTraced.has(sid)) {
          if (ownArgsTraced.size >= 512) ownArgsTraced.delete(ownArgsTraced.values().next().value)
          ownArgsTraced.add(sid)
          tracer.write({ kind: "own_args.off", sessionID: sid, calls: n })
        }
      } catch (err) {
        tracer.write({ kind: "own_args.error", error: String(err) })
      }
      /* A browser's "Continue if you have next steps, or stop and ask for
       * clarification…" goes out in the box's own words, when it has some
       * (PAL_HARNESS_BROWSER_CONTINUE; the Mac mini's cell.yml). On the mini's
       * 3-bit model on 2026-10-18 the first step after a compaction took
       * "ask" as the next step: a question to George mid-research that the
       * task never needed (3 minutes of his time). On every request that
       * holds the message, so the prompt stays the same from step to step. */
      try {
        const messages = output?.messages
        const sid = Array.isArray(messages) ? messages[0]?.info?.sessionID : null
        if (BROWSER_CONTINUE_TEXT && sid && messages.some(isAutoContinue) && await isBrowserSession(sid)) {
          let n = 0
          for (const m of messages) {
            if (!isAutoContinue(m)) continue
            m.parts = [{ ...m.parts[0], text: BROWSER_CONTINUE_TEXT }, ...m.parts.slice(1)]
            n++
          }
          if (!continueTraced.has(sid)) {
            if (continueTraced.size >= 512) continueTraced.delete(continueTraced.values().next().value)
            continueTraced.add(sid)
            tracer.write({ kind: "continue.browser_text", sessionID: sid, messages: n })
          }
        }
      } catch (err) {
        tracer.write({ kind: "continue.text_error", error: String(err) })
      }
      /* A chat after its compaction: the summary carries the block code kept
       * (chatBlockFor), on every request, and opencode's "Continue if you
       * have next steps, or stop and ask for clarification…" becomes "Carry
       * on with:" the summary's Next line — the tax email's "Could you
       * clarify what you'd like to continue working on?" came from it. */
      try {
        const messages = output?.messages
        const sid = Array.isArray(messages) ? messages[0]?.info?.sessionID : null
        if (CHAT_COMPACT_ON && sid) {
          let s = -1
          for (let i = messages.length - 1; i >= 0; i--) {
            const info = messages[i]?.info
            if (info?.role === "assistant" && info.summary && info.finish && !info.error) { s = i; break }
          }
          if (s >= 0 && CHAT_COMPACT_AGENTS.has(agentIn(messages, sid))) {
            const summary = messages[s]
            const notes = (summary.parts ?? []).filter((p) => p?.type === "text").map((p) => p.text ?? "").join("")
            const block = await chatBlockFor(sid, summary)
            const first = (summary.parts ?? []).find((p) => p?.type === "text")
            if (block && first) summary.parts = [...summary.parts, { ...first, id: `${first.id ?? "prt"}-pal-chat-state`, text: block }]
            let continued = 0
            for (let i = s + 1; i < messages.length; i++) {
              if (!isAutoContinue(messages[i])) continue
              // The kept block says when the last call before the notes was
              // parked: then the carry-on is "tell George it waits", not a
              // redo (lib/task-state.js carryOnText).
              messages[i].parts = [{ ...messages[i].parts[0], text: carryOnText(notes, block || "") }, ...messages[i].parts.slice(1)]
              continued++
            }
            const key = `${summary.info.id}|${continued}`
            if (!continueTraced.has(key)) {
              if (continueTraced.size >= 512) continueTraced.delete(continueTraced.values().next().value)
              continueTraced.add(key)
              tracer.write({ kind: "continue.chat", sessionID: sid, block: block.length, continued })
            }
          }
        }
      } catch (err) {
        tracer.write({ kind: "continue.chat_error", error: String(err) })
      }
      /* A browser task after its compaction: its task record and the state
       * code kept ride on the summary, on every request after it — not only
       * the first — so no later step works from notes that lost George's
       * words or where an answer came from (lib/task-record.js). Made once
       * per summary and kept by its id: the same text on every request, so
       * the prompt cache still matches. */
      let recordOnSummary = false
      try {
        const messages = output?.messages
        const sid = Array.isArray(messages) ? messages[0]?.info?.sessionID : null
        if (records && sid && records.of(sid)) {
          let s = -1
          for (let i = messages.length - 1; i >= 0; i--) {
            const info = messages[i]?.info
            if (info?.role === "assistant" && info.summary && info.finish && !info.error) { s = i; break }
          }
          const summary = s >= 0 ? messages[s] : null
          const first = summary ? (summary.parts ?? []).find((p) => p?.type === "text") : null
          if (summary?.info?.id && first) {
            let block = recordBlocks.get(summary.info.id)
            if (block === undefined) {
              block = compactionBlock(sid)
              if (recordBlocks.size >= 256) recordBlocks.delete(recordBlocks.keys().next().value)
              recordBlocks.set(summary.info.id, block)
              tracer.write({ kind: "task_record.compacted", sessionID: sid, id: records.of(sid).id, chars: block.length })
            }
            if (block) {
              summary.parts = [...summary.parts, { ...first, id: `${first.id ?? "prt"}-pal-record`, text: block }]
              recordOnSummary = true
            }
          }
        }
      } catch (err) {
        tracer.write({ kind: "task_record.error", error: String(err) })
      }
      /* A browser task's history, rebuilt from what code kept once it would
       * pass the limit (lib/browser-fresh.js). Last but one: it measures what
       * goes out, and the block below returns early. */
      try {
        fresh?.transform(output?.messages)
      } catch (err) {
        tracer.write({ kind: "browser.fresh.error", error: String(err) })
      }
      try {
        const messages = output?.messages
        const last = Array.isArray(messages) ? messages[messages.length - 1] : null
        if (recordOnSummary) return
        if (!isAutoContinue(last) && !(BROWSER_CONTINUE_TEXT && last?.parts?.[0]?.text === BROWSER_CONTINUE_TEXT)) return
        const sid = last.info.sessionID
        const block = sid ? stateFor(sid) : ""
        if (!block) return
        last.parts = [...last.parts, { ...last.parts[0], id: `${last.parts[0].id ?? "prt"}-pal-state`, text: block }]
        tracer.write({ kind: "continue.state", sessionID: sid, chars: block.length })
      } catch (err) {
        tracer.write({ kind: "continue.error", error: String(err) })
      }
    },

    /* Which agent a model request is for, on the request itself, so the
     * keep-warm's tap on fetch can keep that agent's prefix (lib/keep-warm.js).
     * Only on the providers it warms; llama.cpp ignores the headers. */
    "chat.headers": async (input, output) => {
      try {
        const providerID = input?.model?.providerID
        if (!warm || !warm.keepWarm.wants(providerID) || !output?.headers) return
        output.headers[WARM_AGENT_HEADER] = String(input?.agent ?? "")
        output.headers[WARM_PROVIDER_HEADER] = String(providerID)
      } catch (err) {
        tracer.write({ kind: "warm.headers_error", error: String(err) })
      }
    },

    /* opencode's own bash, task and todowrite go out with PAL-sized
     * descriptions (lib/lean-tools.js) — about 1,900 tokens off the front of
     * every chat that holds them. Fires per tool per turn, built-ins only.
     * Fails soft: anything unexpected and the stock description goes out. */
    "tool.definition": async (input, output) => {
      if (!LEAN_TOOLS_ON) return
      try {
        const lean = leanDescription(input?.toolID, output?.description)
        if (!lean) return
        if (!leanTraced.has(input.toolID)) {
          leanTraced.add(input.toolID)
          tracer.write({ kind: "lean-tools", toolID: input.toolID, stock: output.description.length, lean: lean.length })
        }
        output.description = lean
      } catch (err) {
        tracer.write({ kind: "lean-tools.error", error: String(err) })
      }
    },

    /* A browser step on llama.cpp never thinks, and gets room for one tool
     * call, not the model's whole 16k (lib/runaway.js). Fails soft: without it
     * the request keeps opencode's own level and budget. */
    "chat.params": async (input, output) => {
      /* Auto thinking first, so the browser cap below reads the budget this
       * request will actually run at. */
      try {
        if (autoThinking) {
          autoThinking.apply({
            sessionID: input?.sessionID,
            agent: input?.agent,
            variant: input?.message?.model?.variant,
            variants: input?.model?.variants,
            options: output?.options,
          })
        }
      } catch (err) {
        tracer.write({ kind: "thinking.auto.error", error: String(err) })
      }
      /* opencode's own one-shot requests (a compaction, a title, a summary)
       * share no prompt with any chat, so llama.cpp gives them the least
       * recently used session, which in a long browser run is the chat that
       * sent the browser: on the Mac mini (10-19) a compaction took the
       * assistant's 25.8k-token chat and it was read again when the browser
       * came back. Pinned (PAL_HARNESS_UTILITY_SLOT, the Mac mini's cell.yml)
       * they share the router's session. Only llama.cpp reads `id_slot`. */
      try {
        const providerID = input?.provider?.info?.id ?? input?.provider?.id ?? input?.model?.providerID
        if (UTILITY_SLOT !== null && UTILITY_AGENTS.has(String(input?.agent ?? "")) && /llamacpp/i.test(String(providerID ?? "")) && output?.options) {
          output.options.id_slot = UTILITY_SLOT
          tracer.write({ kind: "utility.slot", agent: input.agent, sessionID: input?.sessionID, slot: UTILITY_SLOT })
        }
      } catch (err) {
        tracer.write({ kind: "utility.slot.error", error: String(err) })
      }
      try {
        const providerID = input?.provider?.info?.id ?? input?.provider?.id ?? input?.model?.providerID
        if (browserThinkingOff({ agent: input?.agent, providerID, options: output?.options })) {
          tracer.write({ kind: "browser.thinking_off", sessionID: input?.sessionID })
        }
        const cap = browserOutputCap({
          agent: input?.agent,
          providerID,
          maxOutputTokens: output?.maxOutputTokens,
          options: output?.options,
        })
        if (cap) {
          output.maxOutputTokens = cap
          tracer.write({ kind: "browser.output_cap", sessionID: input?.sessionID, cap })
        }
      } catch (err) {
        tracer.write({ kind: "browser.output_cap.error", error: String(err) })
      }
      /* Where opencode would compact this browser session, and the step's
       * output cap: the rebuild's limit stays clear of both. */
      try {
        fresh?.noteModel(input?.sessionID, { agent: input?.agent, model: input?.model, maxOutputTokens: output?.maxOutputTokens })
      } catch (err) {
        tracer.write({ kind: "browser.fresh.error", error: String(err) })
      }
      /* Where opencode would compact this chat: the cut's budget stays clear of it (lib/tool-trim.js). */
      try {
        toolTrim.noteModel(input?.sessionID, { model: input?.model })
      } catch (err) {
        tracer.write({ kind: "tool_trim.error", error: String(err) })
      }
    },

    /* The assistant's answer, as it is stored (lib/grounding.js): opencode
     * 1.18.34 sets a text part to what this hook leaves in `output.text` at
     * the part's last token, then saves it and sends it to the app, whose
     * snapshot wins over the streamed words. So the person sees the links,
     * names and conditions no page backed, under the answer, and the next
     * turn reads the same note in the history. Top-level chats only: a
     * sub-agent's report is checked where its result comes back. Fails open:
     * any trouble, or past ANSWER_CHECK_MS, and the answer goes as written. */
    "experimental.text.complete": async (input, output) => {
      /* A tool call written into the words instead of made
       * (lib/written-calls.js): out of the stored answer, which is what the
       * app keeps, and the step done again once. Fails open. */
      try {
        const calls = typeof output?.text === "string" ? writtenCalls(output.text) : []
        if (calls.length) {
          output.text = withoutWrittenCalls(output.text, calls)
          const sid = input?.sessionID
          let redo = "off"
          if (WRITTEN_CALL_REDO_ON) {
            try {
              redo = await redoWrittenCall(sid, input?.messageID, calls)
            } catch (err) {
              redo = `error: ${err?.message || err}`
            }
          }
          tracer.write({ kind: "written_call", sessionID: sid, messageID: input?.messageID,
            calls: calls.map((c) => c.name || "?"), left: output.text.length, redo: redo || "asked" })
        }
      } catch (err) {
        tracer.write({ kind: "written_call.error", sessionID: input?.sessionID, error: String(err) })
      }
      /* The heads of PAL's blocks are for the assistant ("Give George these
       * as they are"); on 2026-10-30 it gave George them too, as headings. */
      if (typeof output?.text === "string") {
        const plain = withoutBlockHeads(output.text)
        if (plain !== output.text) {
          output.text = plain
          tracer.write({ kind: "capture.heads_cut", sessionID: input?.sessionID })
        }
      }
      /* And a copy of one of PAL's own blocks at the front of the reply — a
       * [SKILL] it wrote for a skill that does not exist, the [CONTEXT] block
       * as the whole answer (2026-11-04; lib/copied-blocks.js). Left empty when
       * that was all of it: the app asks once more for a reply with words in
       * it (pal_app guards.dart, PrematureStop.shouldRetryBlank). */
      if (typeof output?.text === "string") {
        const own = withoutCopiedBlocks(output.text)
        if (own !== output.text) {
          tracer.write({ kind: "reply.copied_blocks_cut", sessionID: input?.sessionID,
            cut: output.text.length - own.length, left: own.length })
          output.text = own
        }
      }
      /* What the answer says was saved, sent or changed, and "from your
       * Vault", held against what ran this turn (lib/booking-claims.js
       * reviewClaims): a note under it when nothing did. Top-level chats only;
       * fails open, and past ANSWER_CHECK_MS the answer goes as written. */
      if (CLAIM_CHECK_ON && typeof output?.text === "string" && output.text.trim() && input?.sessionID) {
        let timer
        try {
          if (!(await isSubagentTurn({}, input.sessionID))) {
            const note = await Promise.race([
              reviewClaims(output.text, { sid: input.sessionID, read: readSession }),
              new Promise((resolve) => { timer = setTimeout(() => resolve(""), ANSWER_CHECK_MS) }),
            ])
            if (note) {
              output.text = `${output.text}\n${note}`
              tracer.write({ kind: "claims.flagged", sessionID: input.sessionID, lines: note.split("\n").length - 3 })
            }
          }
        } catch (err) {
          tracer.write({ kind: "claims.error", sessionID: input?.sessionID, error: String(err) })
        } finally {
          clearTimeout(timer)
        }
      }
      if (!ANSWER_CHECK_ON) return
      const text = output?.text
      if (typeof text !== "string" || !text.trim() || text.includes(ANSWER_HEAD)) return
      // Nothing to check: no link, no list, and no capital past a sentence's start.
      if (!linksIn(text).length && !itemsIn(text).length && !/[^.!?\n#*\s]\s+\p{Lu}/u.test(text)) return
      const sid = input?.sessionID
      let timer
      try {
        if (!sid || await isSubagentTurn({}, sid)) return
        const checked = await Promise.race([
          checkAnswer(sid, text),
          new Promise((resolve) => { timer = setTimeout(() => resolve("timeout"), ANSWER_CHECK_MS) }),
        ])
        if (checked === "timeout") {
          tracer.write({ kind: "grounding.answer_timeout", sessionID: sid })
        } else if (checked?.text) {
          output.text = checked.text
          tracer.write({ kind: "grounding.answer", sessionID: sid, ...checked.counts })
        }
      } catch (err) {
        tracer.write({ kind: "grounding.answer_error", sessionID: sid, error: String(err) })
      } finally {
        clearTimeout(timer)
      }
    },

    "experimental.chat.system.transform": async (input, output) => {
      try {
        // browser.md's paragraph about lists, out while lists are off (lib/browser-steps.js).
        if (Array.isArray(output?.system)) {
          output.system.forEach((s, i) => { output.system[i] = stepsSection(s) })
        }
        if (persona && Array.isArray(output?.system)) {
          const promptChars = output.system.reduce(
            (n, s) => n + (typeof s === "string" ? s.length : 0), 0)
          const stock = STOCK_PROMPT.test(String(output.system[0] ?? ""))
          const replace = stock && promptChars >= PERSONA_MIN_PROMPT_CHARS
          // sessionID so a row can be tied to its agent; without it the 2026-09-28
          // audit had to match rows to agent files by prompt length.
          tracer.write({ kind: "persona", replaced: replace, stock, promptChars,
            sessionID: input?.sessionID })
          if (replace) output.system.splice(0, output.system.length, persona)
        }
        const sid = input?.sessionID || "*"
        // opencode's title call reads the stored first message, blocks and all
        // (lib/title-context.js): tell it which part is the person's words. It
        // gets no preamble of its own — that is what it must not title from.
        // memoryWords strips the client's blocks too when the router (and so
        // its userWordsOnly) is off.
        if (addTitleNote(output?.system, memoryWords(personSaid.get(sid) ?? ""))) {
          tracer.write({ kind: "title.note", sessionID: input?.sessionID, words: personSaid.has(sid) })
          return
        }
        const ctx = pending.get(sid) ?? pending.get("*")
        if (ctx && Array.isArray(output?.system)) output.system.push(ctx)
        // In an app's own folder (lib/made-apps.js): which app this is, for
        // the made_app_* tools. Here and not on the person's message, where
        // the app would show a block it does not know as part of their words.
        const app = MADE_APPS_ON && Array.isArray(output?.system) ? appRepoOf(directory) : null
        if (app) {
          output.system.push(appContextLine(app))
          tracer.write({ kind: "made_app.context", sessionID: input?.sessionID, app: app.id })
        }
      } catch (err) {
        tracer.write({ kind: "system.error", error: String(err) })
      }
    },

    /* ---- project filing, then the hard gate ------------------------------
     * TWO jobs with OPPOSITE fail-safe directions, in this order. Filing is
     * bookkeeping and FAILS OPEN (see sessionProject); the gate FAILS CLOSED —
     * decide() never throws, so a bug in it cannot become an allow, and throwing
     * here is what blocks the call in opencode. */
    "tool.execute.before": async (input, output) => {
      const toolName = input?.tool
      const args = output?.args ?? {}
      /* What the checks below put right in a browser task's text, for its
       * record's list of where the task differed from George's words. */
      const cutFixed = []
      let siteDropped = []

      /* A browser task's `read` outside tool-output/: refused with what to
       * use instead, not opencode's rule dump (lib/read-refusal.js). */
      if (READ_REFUSAL_ON && refusesRead(toolName, args) && input?.sessionID
          && await isBrowserSession(input.sessionID)) {
        tracer.write({ kind: "read.refused", sessionID: input.sessionID, path: String(args.filePath ?? "").slice(0, 200) })
        throw new Error(readRefusal(who()))
      }

      /* A visit to an item number no page, result or task showed: refused,
       * with the way to the item instead (lib/page-ids.js). */
      if (pageIds) {
        const unseen = pageIds.unseen(input?.sessionID, toolName, args)
        if (unseen.length) {
          tracer.write({ kind: "page_ids.refused", sessionID: input?.sessionID, tool: toolName, ids: unseen })
          throw new Error(madeUpRefusal(String(args.url).trim(), unseen))
        }
      }

      /* One browser, so one browser job per chat at a time (lib/one-browser-job.js):
       * before anything is recorded or George is asked to approve it. Let go
       * by the task's result, a refusal further down (the wrapper at the end)
       * or the chat going idle. */
      if (oneJob && toolName === "task" && args?.subagent_type === "browser" && input?.sessionID && input?.callID) {
        const chat = await rootSessionOf(input.sessionID)
        const busy = oneJob.claim(chat, input.callID, { description: args.description })
        if (busy) {
          tracer.write({ kind: "browser.one_job.refused", sessionID: input.sessionID, chat,
                         running: busy.description, description: String(args.description ?? "") })
          throw new Error(busyRefusal(busy, personSaid.get(chat) ?? personSaid.get(input.sessionID) ?? "", who()))
        }
      }

      /* Whether the user asked for this fact to be remembered, from their own
       * words this turn (lib/memory.js askedToRemember). ALWAYS overwritten,
       * like a handoff's session: a `user_asked` the model wrote would let a
       * page it read put a fact straight into every later prompt. Not asked
       * means the fact waits as a suggestion — no approval card either way. */
      if (MEMORY_REMEMBER_TOOLS.has(toolName) && args && typeof args === "object") {
        args.user_asked = askedToRemember(args.fact, personSaid.get(input?.sessionID) ?? "",
          { name: who().name })
        tracer.write({ kind: "memory.asked", sessionID: input?.sessionID, asked: args.user_asked })
      }

      /* A rule that holds PAL back, only when George's own words this turn
       * ask for one, and each rule once a turn (lib/hold-asked.js): on
       * 2026-10-21 an unasked call left his email blocked for good. */
      if (toolName === "palapi_acting_hold" && args && typeof args === "object") {
        const sid = input?.sessionID
        if (!askedToHold(args, personSaid.get(sid) ?? "")) {
          tracer.write({ kind: "acting_hold.unasked", sessionID: sid, family: args.family, when: args.when })
          throw new Error(notAskedRefusal(who().name))
        }
        const key = holdKey(args)
        if (key) {
          const held = heldThisTurn.get(sid) ?? new Set()
          if (held.has(key)) {
            tracer.write({ kind: "acting_hold.repeat", sessionID: sid, rule: key })
            throw new Error(repeatRefusal(who().name))
          }
          held.add(key)
          if (heldThisTurn.size >= 256 && !heldThisTurn.has(sid)) heldThisTurn.delete(heldThisTurn.keys().next().value)
          heldThisTurn.set(sid, held)
        }
      }

      /* Filing runs BEFORE the gate, and before the GATE_ON check, for two
       * reasons. The approval the user answers on their phone shows `params`
       * (gate.js `summarise`), so injecting first means the card names the
       * project the task will actually land in rather than one it will not. And
       * a turn with the gate switched off must still file correctly.
       *
       * FILL-IF-ABSENT, never overwrite. A `project` the model passed is the
       * user asking out loud for a different project ("add that one to
       * Personal"), and the thread's own membership must not win that argument.
       * Mutating `args` in place is what reaches the tool — reassigning
       * `output.args` is the same silently-discarded mistake as lesson 3. */
      if (PROJECT_FILING_ON && args && typeof args === "object"
          && projectFillable(toolName, args)
          && !String(args.project ?? "").trim()) {
        const filed = await sessionProject(input?.sessionID)
        if (filed) {
          args.project = filed
          tracer.write({
            kind: "project.inject", tool: toolName,
            sessionID: input?.sessionID, project: filed,
          })
        }
      }

      /* The account an email goes from is George's to name (addresses.js
       * namesAccount). One the model picked itself is left blank, so the card
       * asks him and offers the account he last used with that person. */
      if (toolName === "palapi_conn_write" && args && typeof args.params_json === "string") {
        try {
          const inner = JSON.parse(args.params_json)
          const picked = inner && typeof inner === "object" ? String(inner.from_account ?? "").trim() : ""
          const said = `${personSaid.get(input?.sessionID) ?? ""}\n${lastAnswers.get(input?.sessionID) ?? ""}`
          if (picked && !namesAccount(said, picked, { name: who().name })) {
            inner.from_account = ""
            args.params_json = JSON.stringify(inner)
            tracer.write({ kind: "account.unpicked", sessionID: input?.sessionID, tool: toolName })
          }
        } catch { /* not JSON: the tool says so itself */ }
      }

      /* A look fills nothing in and sends nothing (lib/jobs.js), by the task
       * record too, which outlives a restart (lib/task-record.js). A list of
       * page actions is refused when any action in it would be (lib/browser-steps.js). */
      if (JOBS_ON && input?.sessionID
          && (lookRefuses(toolName, args) || (toolName === STEPS_TOOL && innerCalls(args).some((c) => lookRefuses(c.tool, c.args))))
          && (lookChildren.has(input.sessionID) || records?.of(input.sessionID)?.mode === "look")) {
        tracer.write({ kind: "job.look_refused", sessionID: input.sessionID, tool: toolName })
        const w = who()
        throw new Error(
          `pal-harness: this task is only a look — ${w.name} asked what is on offer, not for it to be done. `
          + `Nothing is filled in or sent on a look. Capture what the page offers, report it, and stop: `
          + `if ${w.he} picks one, the assistant sends you back here to do it.`,
        )
      }

      /* A browser task past its budget, or a step back to a site that blocked
       * it, is refused here with what to do instead (lib/browser-budget.js).
       * Keeping, noting and asking are never refused. */
      if (work && input?.sessionID && work.tracked(input.sessionID) && typeof toolName === "string") {
        const refusal = work.before(input.sessionID, toolName, args)
        if (refusal) {
          tracer.write({ kind: "browser_budget.refused", sessionID: input.sessionID, tool: toolName })
          throw new Error(refusal)
        }
      }

      /* The first browser call of each task carries the task's session, so
       * nas-browser-v2 closes the tabs earlier tasks left open (fresh-task.mjs):
       * on 2026-10-06 a stopped wrong-site task's tab pulled the next task back
       * to it twice. Once per task. The model never sees the stamp: its history
       * goes back without it (harnessArgsOf).
       *
       * EXCEPT in a chat that has opened a desktop app (Spotify): there every
       * browser call is stamped. nas-browser-v2 keeps each chat on its own
       * surface — the web, or the app — by this stamp, and opencode shares ONE
       * MCP connection between every chat, so an unstamped call is the web's
       * (nas-browser-v2 surfaces/registry.mjs). Web-only chats pay nothing. */
      if (typeof toolName === "string" && args && typeof args === "object" && input?.sessionID
          && opensApp(toolName, args)) {
        if (appChats.size >= 512) appChats.delete(appChats.values().next().value)
        appChats.add(input.sessionID)
      }
      if (typeof toolName === "string" && PAGE_TOOL_RE.test(toolName) && input?.sessionID
          && args && typeof args === "object"
          && (!stampedTasks.has(input.sessionID) || appChats.has(input.sessionID))) {
        if (stampedTasks.size >= 512) stampedTasks.delete(stampedTasks.values().next().value)
        stampedTasks.add(input.sessionID)
        args.pal_task = input.sessionID
      }
      if (typeof toolName === "string" && PAGE_TOOL_RE.test(toolName) && input?.sessionID
          && args && typeof args === "object" && turnToStamp.has(input.sessionID)) {
        turnToStamp.delete(input.sessionID)
        turnSeq++
        args.pal_turn = `${input.sessionID}#${bootTag}${turnSeq}`
      }
      /* The page calls of the step after a rebuild ask nas-browser-v2 to
       * forget what it showed this session, so the next view is whole
       * (lib/browser-fresh.js, fresh-task.mjs). Hidden like pal_task. */
      if (fresh && typeof toolName === "string" && PAGE_TOOL_RE.test(toolName) && input?.sessionID) {
        const stamp = fresh.stamp(input.sessionID, args)
        if (stamp) tracer.write({ kind: "browser.fresh.reset", sessionID: input.sessionID, tool: toolName, stamp })
      }

      /* The chat a browser handoff belongs to, so the app can show its card
       * (Open browser, Done) in that thread. Not in the tool's schema: opencode
       * has checked the model's arguments by now and passes these on as they
       * are. ALWAYS overwritten all the same: a value the model made up would
       * put the card in some other chat or none. */
      if (HANDOFF_TOOLS.has(toolName) && args && typeof args === "object") {
        args.session_id = await rootSessionOf(input?.sessionID)
        tracer.write({ kind: "handoff.session", tool: toolName, sessionID: input?.sessionID, root: args.session_id })
      }

      if (VAULT_TOOLS.has(toolName) && args && typeof args === "object") {
        args.session_id = await rootSessionOf(input?.sessionID)
      }

      /* The task's list on its list calls (lib/work-list.js), whatever id the
       * model copied. Hidden like pal_task. */
      if (LIST_TOOLS.has(toolName) && args && typeof args === "object" && childLists.has(input?.sessionID)) {
        args.pal_list = childLists.get(input.sessionID)
      }

      if (NOTE_WRITE_TOOLS.has(toolName) && args && typeof args === "object") {
        args.session_id = String(input?.sessionID ?? "")
      }

      if (DEVICE_TOOLS.has(toolName) && args && typeof args === "object") {
        args.session_id = await rootSessionOf(input?.sessionID)
        args.from_device = THIS_DEVICE
        // His own words this turn, so a device he named ("on my Android
        // phone") wins over the one the chat is on even when the model left
        // `device` empty — 2026-10-15, the timer rang on the Mac.
        args.said = String(personSaid.get(args.session_id) ?? personSaid.get(input?.sessionID) ?? "").slice(0, 500)
        tracer.write({ kind: "device.session", tool: toolName, sessionID: input?.sessionID,
                       root: args.session_id, device: THIS_DEVICE })
      }

      /* An action_do call carries the harness's context in ctx_json — the
       * chat (root session), the agent, George's own words this turn, this
       * device and the project the chat is filed under — ALWAYS overwritten:
       * a ctx_json the model wrote would be its own account of who asked.
       * pal-api reads it only from a caller the harness stands in front of. */
      if (ACTION_DO_TOOLS.has(toolName) && args && typeof args === "object") {
        const root = await rootSessionOf(input?.sessionID)
        const filed = PROJECT_FILING_ON ? await sessionProject(input?.sessionID) : ""
        // Ask-then-act for the inner action (lib/ask-then-act.js): the gate
        // below never sees it, so the question this step ended on rides along
        // and pal-api refuses an action it would ask about until George answers.
        const askedFirst = stepText ? closingQuestion(stepText.said(input?.sessionID, input?.callID)) : ""
        args.ctx_json = harnessContext({
          sessionID: root, agent: input?.agent || await agentOfSession(input?.sessionID),
          said: personSaid.get(root) ?? personSaid.get(input?.sessionID) ?? "",
          device: THIS_DEVICE, project: filed || "", asked: askedFirst,
        })
        /* Driving an app on the Mac (mac.ui.*) has a step budget per turn of
         * George's (lib/actions.js createMacSteps): past it, stop and report. */
        const overBudget = macSteps.before(root, personSaid.get(root) ?? "", String(args.action ?? ""))
        if (overBudget) {
          tracer.write({ kind: "mac_steps.refused", sessionID: input?.sessionID, action: String(args.action ?? "") })
          throw new Error(overBudget)
        }
      }

      /* A made_app_* call in an app's own folder is for THAT app
       * (lib/made-apps.js stampApp): `app` is set to the instance's own app
       * id, ALWAYS overwritten, like a handoff's session. A model that forgot
       * or mistyped the id still works, and a builder in one app's folder
       * cannot run a command in, or publish, another. Before the gate, so the
       * card for a package or a publish names the app that will be touched.
       * Anywhere but an app's folder the call goes as the model wrote it. */
      if (MADE_APPS_ON) {
        const stamped = stampApp(directory, toolName, args)
        if (stamped) {
          tracer.write({ kind: "made_app.stamp", tool: toolName, sessionID: input?.sessionID || "", app: stamped.app,
                         changed: stamped.changed, ...(stamped.changed ? { was: stamped.was } : {}) })
        }
      }

      /* What a click would send, for the approval card, if it turns out to
       * commit: the ledger's record, left on pal-api (browser_answers.py), and
       * only its id on the call. The record used to ride on every click, and a
       * tool call's arguments stay in the model's context: on 2026-10-02 it
       * was 98 KB of the 122 KB of tool-call input, and up to 46% of the
       * context between compactions. ALWAYS overwritten, like the handoff's
       * session: a list or id the model wrote would be its own account. With
       * the ledger off, or the record not left, no id at all — v2 then asks
       * about every submit-like click rather than assume nothing was entered. */
      if (COMMIT_TOOLS.has(toolName) && args && typeof args === "object") {
        args.session_id = await rootSessionOf(input?.sessionID)
        delete args.answers
        delete args.ledger
        // What George said this job may not do (lib/own-words.js); v2 holds it.
        delete args.limits
        const rec = records?.of(input?.sessionID)
        const limits = childLimits.get(input?.sessionID) || (rec ? limitsStamp(rec.limits) : "")
        if (limits) args.limits = limits
        if (ledger && input?.sessionID && await leaveRecord(input.sessionID, ledger.entries(input.sessionID))) {
          args.ledger = input.sessionID
        }
      }

      /* Recipes and the agent that holds no page tools (the recipe guard in
       * lib/actions.js). 2026-11-06 demo. NAZAR: the [ACTIONS] card's recipe stopped at s2
       * with "TAKE OVER … Finish the job from here by hand", and the
       * assistant spent three calls resuming it, with a run_id it had
       * mistyped, until George gave up — the result is now turned into "hand
       * it to `browser` now" (tool.execute.after), and the same site's recipe
       * run again this turn gets that again instead of a run. CTM, both
       * chats: the assistant's first call was flow_lookup, once with a name
       * it made up ("car-insurance-quote"), although [ROUTER] says the task
       * call comes first — its lookup is answered by code with the way on,
       * unless George's own words ask about recipes. And the browser made the
       * same made-up lookup: a name no page, result or task showed this
       * session is dropped, so the lookup lists what the site has (or says it
       * has none) instead of "MISS: nothing named …". */
      if (FLOW_GUARD_ON && input?.sessionID
          && (toolName === "playwright_flow_run" || toolName === "playwright_flow_lookup")) {
        const browserAgent = await runsAsBrowser(input)
        const stopped = stoppedRecipes.get(input.sessionID)
        if (toolName === "playwright_flow_run" && !browserAgent && stopped && siteKey(args?.domain) === stopped.site) {
          tracer.write({ kind: "flow_guard.rerun_refused", sessionID: input.sessionID, domain: args?.domain, flow: args?.flow })
          throw new Error(rerunRefusal(stopped.directive))
        }
        if (toolName === "playwright_flow_lookup" && !browserAgent) {
          const chat = await rootSessionOf(input.sessionID)
          if (!asksAboutRecipes(personSaid.get(chat) ?? personSaid.get(input.sessionID) ?? "")) {
            tracer.write({ kind: "flow_guard.lookup_refused", sessionID: input.sessionID, domain: args?.domain, flow: args?.flow })
            throw new Error(lookupRefusal(currentPerson()))
          }
        }
        if (toolName === "playwright_flow_lookup" && browserAgent && flowNames && typeof args?.flow === "string"
            && args.flow.trim() && !flowNames.knows(input.sessionID, args.flow)) {
          tracer.write({ kind: "flow_guard.lookup_unseen_name", sessionID: input.sessionID, domain: args.domain, flow: args.flow })
          args.flow = ""
        }
      }

      /* A recipe run: its chat and the person's own words, so the questions it
       * asks first (nas-browser-v2 flow-tool.mjs, pal-api recipe_prepare.py)
       * are about what THEY said, never the model's retelling. Always
       * overwritten, like a commit's session. */
      if (recipeLearn && toolName === "playwright_flow_run" && args && typeof args === "object") {
        args.session_id = await rootSessionOf(input?.sessionID)
        args.words = recipeLearn.wordsFor(input?.sessionID, records?.of(input?.sessionID) ?? null)
      }

      /* The assistant's recipe lookup on an address it worked out from a name
       * is refused (lib/site-guess.js): both Zone D runs began with
       * flow_lookup("bury.gov.uk"), the wrong council. Only the chat's own
       * agent — the browser looks up the site it is actually on. */
      if (SITE_GUESS_ON && toolName === "playwright_flow_lookup" && typeof args?.domain === "string" && args.domain.trim()
          && input?.sessionID && await rootSessionOf(input.sessionID) === input.sessionID) {
        const known = await knownHostsOf(input.sessionID)
        if (known && !isKnown(args.domain, known)) {
          tracer.write({ kind: "site_guess.lookup_refused", sessionID: input.sessionID, domain: args.domain })
          throw new Error(refusedLookup(args.domain))
        }
      }

      /* A grant handed back this turn (chat.message above) goes to the task
       * that asked for it, whatever task_id the model wrote, and the task is
       * told which call to make. With two grants for the same agent the note
       * names each task_id, and the model's choice stands. */
      if (toolName === "task" && args && typeof args === "object" && input?.sessionID && handBacks.has(input.sessionID)) {
        const mine = handBacks.get(input.sessionID)
          .filter((g) => g.session !== g.chat && (g.agent || "browser") === args.subagent_type)
        if (mine.length === 1) {
          const g = mine[0]
          const was = String(args.task_id ?? "").trim()
          if (was !== g.session) args.task_id = g.session
          if (typeof args.prompt === "string" && !args.prompt.includes(`#${g.id}`)) {
            args.prompt = `[PAL: ${subagentAsk(g, who())}]\n\n${args.prompt}`
          }
          tracer.write({ kind: "parked.task", sessionID: input.sessionID, id: g.id, taskId: g.session, was })
        }
      }

      /* "That's the wrong website": the task that went there is not carried on
       * (router-core.js WRONG_SITE_RE). The router says so; this holds when the
       * model passes the old task_id anyway. */
      if (toolName === "task" && args?.subagent_type === "browser" && isAbandonedTask
          && String(args.task_id ?? "").trim() && isAbandonedTask(args.task_id)) {
        tracer.write({ kind: "task.wrong_site_new", sessionID: input?.sessionID, was: args.task_id })
        delete args.task_id
      }

      /* "Show 5 more": a resume of a task that has kept matches is told
       * which, so the next few are new ones even after its own context was
       * compacted (lib/captures.js found, lib/browser-budget.js first look). */
      if (captures && toolName === "task" && args?.subagent_type === "browser"
          && String(args.task_id ?? "").trim() && typeof args.prompt === "string") {
        const kept = captures.found(String(args.task_id).trim())
        const names = kept.flatMap((f) => f.items.map((it) => `${it.name} (${f.site})`))
        if (names.length && !args.prompt.includes("[PAL: already kept on this task")) {
          args.prompt = `${args.prompt}\n\n[PAL: already kept on this task and shown to ${who().name} — do not keep or show these again: ${names.slice(-40).join("; ")}]`
          tracer.write({ kind: "found.resume", sessionID: input?.sessionID, kept: names.length })
        }
      }

      /* A name George typed, cut short in a search or a task, is put back as
       * he typed it (lib/cut-names.js): on 2026-10-28 his "NAZAR Cambridge"
       * went out as "NAZ Cambridge" in the web search and the task's title. */
      if (CUT_NAMES_ON && args && typeof args === "object"
          && (toolName === "task" || toolName === "palapi_web_search")) {
        // A resumed browser task's names are its record's, which outlive a
        // restart (lib/task-record.js); otherwise the chat's.
        const kept = records && toolName === "task" && args.subagent_type === "browser"
          ? nameBookOf(records.of(String(args.task_id ?? "").trim())) : null
        const said = kept ?? (saidNames.size ? saidNames.of(input?.sessionID) ?? saidNames.of(await rootSessionOf(input?.sessionID)) : null)
        const fixed = []
        for (const key of said ? (toolName === "task" ? ["description", "prompt"] : ["query"]) : []) {
          if (typeof args[key] !== "string") continue
          const put = putBack(args[key], said)
          if (put.fixed.length) {
            args[key] = put.text
            fixed.push(...put.fixed)
          }
        }
        if (fixed.length) {
          tracer.write({ kind: "cut_names.fixed", sessionID: input?.sessionID, tool: toolName, fixed })
          cutFixed.push(...fixed)
        }
      }

      /* A web address in a browser task that George never gave and no page in
       * this chat showed is taken out (lib/site-guess.js), new task or resume. */
      if (SITE_GUESS_ON && toolName === "task" && args?.subagent_type === "browser"
          && typeof args.prompt === "string" && addressesIn(args.prompt).length) {
        // A copy of an earlier task's note is not the assistant's address: it
        // goes, and a fresh note goes on below if one is taken out now.
        args.prompt = withoutDroppedNotes(args.prompt)
        const known = await knownHostsOf(input?.sessionID)
        if (known) {
          const { prompt, dropped } = dropGuessedAddresses(args.prompt, known)
          if (dropped.length) {
            args.prompt = `${prompt}\n\n${droppedNote(dropped)}`
            tracer.write({ kind: "site_guess.dropped", sessionID: input?.sessionID, dropped })
            siteDropped = dropped
            if (input?.callID) {
              if (droppedByCall.size >= 256) droppedByCall.delete(droppedByCall.keys().next().value)
              droppedByCall.set(input.callID, dropped)
            }
          }
        }
      }

      /* A browser task that licenses defaults has those sentences taken out
       * by code, a line says what went, and the task goes on
       * (answers-ledger.js cutDefaults). Until 2026-11-06 it was refused, to
       * be rewritten and sent again; in that day's demo (CTM chat 1) the
       * refusal fired on "- Start date: ask (usually needs to be within 21
       * days)" — a line telling the browser to ASK — and the assistant never
       * sent it again: it quizzed George with five questions instead, and the
       * job never reached the site. */
      if (ledger && toolName === "task" && args?.subagent_type === "browser" && typeof args.prompt === "string") {
        const { prompt, cut } = cutDefaults(args.prompt)
        if (cut.length) {
          args.prompt = `${prompt}\n\n${defaultsCutNote(cut, currentPerson())}`
          tracer.write({ kind: "task.defaults_cut", sessionID: input?.sessionID, cut })
        }
      }

      /* "Continue" after a browser task was stopped: that task, on its page,
       * not a new one from the form's first page (router-core.js). The router
       * says so too; this holds when the model starts a new task anyway. */
      if (toolName === "task" && args?.subagent_type === "browser" && !String(args.task_id ?? "").trim()
          && browserJobFor && asksToContinue && lastRequestOf) {
        const job = browserJobFor(input?.sessionID)
        if (job?.stopped && asksToContinue(lastRequestOf(input?.sessionID))) {
          args.task_id = job.taskId
          if (typeof args.prompt === "string") {
            args.prompt = "[PAL: this carries on the task that was stopped. The browser is still on its page: go on from "
              + "there, and do not start the form again.]\n\n" + args.prompt
          }
          tracer.write({ kind: "task.resume_stopped", sessionID: input?.sessionID, taskId: job.taskId })
        }
      }

      /* API first, the browser as fallback (George, 2026-10-19). A look-up
       * turn tries web_search / web_read / research before it may start the
       * browser; a resume (task_id) is never held, nor is a turn the router
       * gave another word or none. */
      if (WEB_FIRST_ON && input?.sessionID && categoryOf && webFirstRefusal) {
        const chat = input.sessionID
        if (WEB_LOOKUP_TOOLS.has(toolName) || (toolName === "task" && args?.subagent_type === "research")) {
          if (webTried.size >= 512 && !webTried.has(chat)) webTried.delete(webTried.keys().next().value)
          webTried.set(chat, Date.now())
        }
        const startsBrowser = BROWSER_START_TOOLS.has(toolName)
          || (toolName === "task" && args?.subagent_type === "browser" && !String(args.task_id ?? "").trim())
        const routed = startsBrowser ? categoryOf(chat) : null
        /* A recipe the chat was offered on an [ACTIONS] card is not the
         * browser as a fallback: it fits George's words, and it is one call
         * that reads the answer off the site, so it goes ahead of a search
         * ("Look up the MOT status of my car", 2026-10-28). */
        const carded = routed && (shownCards.get(chat)?.has(recipeCalled(toolName, args)) ?? false)
        if (routed?.category === "web_research" && !carded && !((webTried.get(chat) ?? 0) >= routed.at)) {
          tracer.write({ kind: "web_first.refused", sessionID: chat, tool: toolName })
          throw new Error(webFirstRefusal())
        }
      }

      /* A browser task for a day nothing in this chat points to is held once
       * (lib/task-date.js): on 2026-10-28 George's "for that time", that
       * evening's dinner, went to the browser as "Thursday 29 October". Sent
       * again unchanged, it goes. */
      /* The task record (lib/task-record.js): built from George's own words
       * on a new browser task, his latest words added on a resume. Here,
       * after the checks that refuse the call outright, and before the day
       * check, which reads the chat's history with it. A record that cannot
       * be made costs the record, never the task: the libs' own blocks go on
       * it instead, as before. */
      let rec = null
      let recHistory
      if (records && toolName === "task" && args?.subagent_type === "browser"
          && typeof args.prompt === "string" && input?.sessionID) {
        try {
          ;({ rec, history: recHistory } = await recordFor(input, args))
        } catch (err) {
          tracer.write({ kind: "task_record.error", sessionID: input.sessionID, error: String(err) })
        }
      }

      if (TASK_DATE_ON && toolName === "task" && args?.subagent_type === "browser"
          && typeof args.prompt === "string" && input?.sessionID) {
        const sid = input.sessionID
        const today = dayOf()
        if (taskDays(withoutRecords(args.prompt), today).size) {
          const history = recHistory !== undefined ? recHistory : await chatMessagesOf(sid, "task_date")
          const found = offDays({ task: withoutRecords(args.prompt), said: personSaid.get(sid) ?? "", history, today,
                                  wordsOf: (t) => userWordsOnly(t) })
          if (found) {
            const key = found.off.join(",")
            const held = datesHeld.get(sid) ?? new Set()
            if (held.has(key)) {
              tracer.write({ kind: "task_date.again", sessionID: sid, off: found.off })
              // Sent again unchanged, it goes: the record says so to the browser.
              if (rec) noteClash(rec, { kind: "day", task: found.off, words: found.pointed })
            } else {
              held.add(key)
              if (datesHeld.size >= 256 && !datesHeld.has(sid)) datesHeld.delete(datesHeld.keys().next().value)
              datesHeld.set(sid, held)
              tracer.write({ kind: "task_date.held", sessionID: sid, off: found.off, pointed: found.pointed, from: found.from })
              throw new Error(dateHeldNote(found, who()))
            }
          }
        }
      }

      /* An identifier in a browser task — an account number, a sort code, a
       * phone number, an email … — that no message of George's and no tool
       * result in this chat gave is refused before the browser starts
       * (lib/provenance.js). 2026-11-20: the Voscap task carried bank details
       * the assistant made up, and the browser typed them. Refused only once
       * the chat's whole history was read and lacks it: unread, it goes. */
      if (provenance && toolName === "task" && args?.subagent_type === "browser"
          && typeof args.prompt === "string" && input?.sessionID) {
        const sid = input.sessionID
        let loose = provenance.unsourcedInTask(sid, args.prompt)
        if (loose.length) {
          const history = recHistory ?? await chatMessagesOf(sid, "provenance")
          loose = history ? unsourcedAgainst(loose, history, { wordsOf: (t) => userWordsOnly(t), except: (c) => ledger?.unsourced(c) ?? [] }) : []
          if (!history) tracer.write({ kind: "provenance.unread", sessionID: sid })
        }
        if (loose.length) {
          tracer.write({ kind: "provenance.task_refused", sessionID: sid, kinds: loose.map((v) => v.kind) })
          throw new Error(taskRefusal(loose, currentPerson()))
        }
      }

      /* "Continue" after a research task that never reported: that task, with
       * what it has found, not a new one from nothing (router-core.js). */
      if (toolName === "task" && args?.subagent_type === "research" && !String(args.task_id ?? "").trim()
          && researchJobFor && asksToContinue && lastRequestOf) {
        const job = researchJobFor(input?.sessionID)
        if (job && !job.finished && asksToContinue(lastRequestOf(input?.sessionID))) {
          args.task_id = job.taskId
          if (typeof args.prompt === "string") {
            args.prompt = "[PAL: this carries on the research task that was stopped. Finish from what you have "
              + "already found, and report.]\n\n" + args.prompt
          }
          tracer.write({ kind: "task.resume_research", sessionID: input?.sessionID, taskId: job.taskId })
        }
      }
      if (toolName === "task" && args?.subagent_type === "research" && input?.sessionID) {
        const resumed = String(args.task_id ?? "").trim()
        if (resumed) rememberResearchStart?.(input.sessionID, resumed)
        else startingResearchTasks.set(input.sessionID, Date.now())
      }

      /* Which chat a browser task belongs to, for "Continue" if it is stopped:
       * a resume names its child; a new one is matched to its child's first
       * message (chat.message above). */
      if (toolName === "task" && args?.subagent_type === "browser" && input?.sessionID) {
        const resumed = String(args.task_id ?? "").trim()
        if (resumed) rememberBrowserStart?.(input.sessionID, resumed)
        else startingBrowserTasks.set(input.sessionID, Date.now())
        recipeLearn?.started(input.sessionID)
      }

      /* A resume of a look that asks for the job itself ("book the 19:00")
       * lifts the look: from here the job's steps apply. George's words or
       * the resume's own prompt; the click that books still waits for his
       * OK on the card. */
      const lookRecord = JOBS_ON && toolName === "task" ? records?.of(String(args?.task_id ?? "").trim()) : null
      if (JOBS_ON && toolName === "task" && args?.subagent_type === "browser"
          && (lookChildren.has(String(args.task_id ?? "").trim()) || lookRecord?.mode === "look")) {
        const child = String(args.task_id).trim()
        const jobs = loadJobs(JOBS_FILE)
        const named = jobs.find((j) => j.name === (jobByChild.get(child) || lookRecord?.job))
        // The resume's own words, not the record block on it: the block's
        // "Only a look" line is no ask.
        const asked = withoutRecords(args.prompt)
        const job = (named ? [named] : jobs.filter((j) => j.lookRe))
          .find((j) => asksForIt(j, personSaid.get(input?.sessionID) ?? "") || asksForIt(j, asked))
        if (job) {
          lookChildren.delete(child)
          // On the record too, and the "don't book" that made it a look goes
          // with it, unless these words say it again: his ask for the job
          // itself is newer. The click that books still waits for his OK.
          if (lookRecord) {
            lookRecord.mode = "act"
            lookRecord.clashes = lookRecord.clashes.filter((c) => c.kind !== "look")
            if (lookRecord.limits.noSend && !limitsOf(personSaid.get(input?.sessionID) ?? "").noSend) {
              lookRecord.limits = { ...lookRecord.limits, noSend: false }
              lookRecord.clashes = lookRecord.clashes.filter((c) => c.limit !== "no-send")
              const stamp = limitsStamp(lookRecord.limits)
              if (stamp) childLimits.set(child, stamp)
              else childLimits.delete(child)
            }
            records.changed(lookRecord)
          }
          tracer.write({ kind: "job.look_lifted", sessionID: input?.sessionID, child, job: job.name })
        }
      }

      /* George's own words for the job, on a NEW browser task, as he typed
       * them (lib/own-words.js). On a resume, his latest words too, unless
       * the resume prompt already gives them word for word: on 2026-10-06 his
       * "this isn't Bury st edmunds website - this is bury.gov.uk which is bury
       * North" was resumed as the old task's prompt, wrong address and all. */
      /* With a task record, ONE block carries all of that, rendered fresh
       * from the record on every new task and every resume: George's own
       * words (and on a resume his latest, unless the prompt gives them word
       * for word), what they pin down, his answers, his conditions, and where
       * the task text differs from them. A resume that copied an older record
       * block has it replaced. The own-words, conditions and answers blocks
       * below are the record's sections now, so they are not added again. */
      if (rec && typeof args.prompt === "string") {
        for (const f of cutFixed) noteClash(rec, { kind: "name", from: f.from, to: f.to })
        // An address taken out of an earlier task that this one carries (the
        // chat has shown it since) is no longer "taken out".
        forgetKeptSites(rec, args.prompt)
        if (siteDropped.length) noteClash(rec, { kind: "site_dropped", hosts: siteDropped })
        const resumed = Boolean(String(args.task_id ?? "").trim())
        const task = withoutRecords(args.prompt)
        const latest = personSaid.get(input?.sessionID) ?? ""
        // His latest words, unless they only say go on ("Continue"): then the
        // words the task started with. Not shown again when the prompt
        // already gives them word for word.
        const fresh = resumed && Boolean(latest) && !goesOn(latest)
        const given = fresh && saysWordForWord(task, latest)
        const words = fresh && !given ? latest : rec.words
        const block = renderRecord(rec, {
          words, ownWords: !task.includes(wordsHeader()) && !given,
          conditions: GROUNDING_ON && !task.includes(CONDITIONS_HEAD),
        })
        args.prompt = block ? `${task}\n\n${block}` : task
        records.changed(rec)
        tracer.write({
          kind: "task_record.inject", sessionID: input?.sessionID, id: rec.id, resumed, chars: block.length,
          ...(rec.clashes.length ? { clashes: rec.clashes.map((c) => c.kind) } : {}),
        })
      } else if (toolName === "task" && args?.subagent_type === "browser" && !String(args.task_id ?? "").trim()
          && typeof args.prompt === "string" && !args.prompt.includes(wordsHeader())) {
        const block = wordsBlock(personSaid.get(input?.sessionID) ?? "")
        if (block) {
          args.prompt = `${args.prompt}\n\n${block}`
          tracer.write({ kind: "george_words.inject", sessionID: input?.sessionID })
        }
      } else if (toolName === "task" && args?.subagent_type === "browser" && String(args.task_id ?? "").trim()
          && typeof args.prompt === "string" && !args.prompt.includes(wordsHeader())) {
        const words = personSaid.get(input?.sessionID) ?? ""
        const block = words && !saysWordForWord(args.prompt, words) ? wordsBlock(words) : ""
        if (block) {
          args.prompt = `${args.prompt}\n\n${block}`
          tracer.write({ kind: "george_words.inject_resume", sessionID: input?.sessionID })
        }
      }

      /* The app George was looking at when he asked (lib/screen.js), on a NEW
       * browser task: the job starts in it unless the job names somewhere else.
       * On 2026-10-18 the task said "search the web for Led Zeppelin" with
       * Spotify in front, and the browser went to open.spotify.com. */
      if (toolName === "task" && args?.subagent_type === "browser" && !String(args.task_id ?? "").trim()
          && typeof args.prompt === "string" && !args.prompt.includes(screenHeader())) {
        const block = screenBlock(screens.get(await rootSessionOf(input?.sessionID)))
        if (block) {
          args.prompt = `${args.prompt}\n\n${block}`
          tracer.write({ kind: "screen.inject", sessionID: input?.sessionID })
        }
      }

      /* George's conditions ("I don't eat pork", "under £100"), on a browser
       * task, new or resumed: its report says per item what a page said about
       * each, and the harness checks that against the pages
       * (lib/conditions.js). */
      if (GROUNDING_ON && !rec && toolName === "task" && args?.subagent_type === "browser"
          && typeof args.prompt === "string" && !args.prompt.includes(CONDITIONS_HEAD)) {
        const block = conditionsBlock(conditionsIn(personSaid.get(input?.sessionID) ?? ""), who())
        if (block) {
          args.prompt = `${args.prompt}\n\n${block}`
          tracer.write({ kind: "conditions.inject", sessionID: input?.sessionID })
        }
      }

      /* George's earlier answers in this chat, or on the site this task names
       * (lib/chat-answers.js), on a NEW browser task's prompt. */
      if (chatAnswers && !rec && toolName === "task" && args?.subagent_type === "browser"
          && !String(args.task_id ?? "").trim() && typeof args.prompt === "string") {
        const block = chatAnswers.blockFor(await rootSessionOf(input?.sessionID), args.prompt)
        if (block && !args.prompt.includes(block.split("\n")[0])) {
          args.prompt = `${args.prompt}\n\n${block}`
          tracer.write({ kind: "chat_answers.inject", sessionID: input?.sessionID, rows: block.split("\n").length - 1 })
        }
      }

      /* The job this browser task is (lib/jobs.md), added to its prompt. Only
       * on a NEW task: a resume carries George's answer, whose words ("book
       * it", "cancel that one") must not turn a quote into a booking. Never
       * twice, and after the defaults check, so a task sent back to be
       * rewritten gets its job when it comes back. Picked from George's own
       * words when the prompt carries them (above): the assistant's "any
       * booking notes" made a restaurant search a booking (2026-10-15). */
      if (JOBS_ON && toolName === "task" && args?.subagent_type === "browser"
          && !String(args.task_id ?? "").trim() && typeof args.prompt === "string"
          && !jobInPrompt(args.prompt)) {
        const words = wordsInPrompt(args.prompt)
        // The record already picked it, from the same words (recordFor).
        const job = rec
          ? (rec.job ? loadJobs(JOBS_FILE).find((j) => j.name === rec.job) ?? null : null)
          : pickJob(loadJobs(JOBS_FILE), words || args.prompt)
        if (job) {
          const look = rec ? rec.mode === "look" : onlyALook(job, words, args.prompt)
          args.prompt = `${args.prompt}\n\n${jobBlock(job, undefined, { look })}`
          tracer.write({ kind: "job.inject", sessionID: input?.sessionID, job: job.name, ...(look ? { look } : {}) })
          // A booking: what George's calendar already has for it.
          if (job.endsIn === "book" && !args.prompt.includes(CALENDAR_HEADER)) {
            const asked = `${words}\n${args.prompt.split("\n\n[")[0]}`
            const near = eventsNear(await agendaEvents({ base: API_BASE }), asked)
            if (near.length) {
              args.prompt = `${args.prompt}\n\n${calendarBlock(near, who())}`
              if (calendarByChat.size >= 256 && !calendarByChat.has(input.sessionID)) calendarByChat.delete(calendarByChat.keys().next().value)
              calendarByChat.set(input?.sessionID, near)
              tracer.write({ kind: "calendar.near", sessionID: input?.sessionID, events: near.length })
            }
          }
        }
      }
      /* A spreadsheet the job works through, as a list held by code
       * (lib/work-list.js): made from the attachment or a /files path in
       * George's words or the task, from the row he named, and handed to the
       * browser one row at a time. Then the attachment lines and upload ids,
       * which the browser can do nothing with, are put into words. New task
       * or resume; fail-open. */
      if (toolName === "task" && args?.subagent_type === "browser" && typeof args.prompt === "string" && input?.sessionID) {
        const chat = await rootSessionOf(input.sessionID)
        const said = [personSaid.get(input.sessionID), personSaid.get(chat)].filter(Boolean).join("\n")
        const sources = sourcesIn(args.prompt, said)
        const resumed = String(args.task_id ?? "").trim()
        let listed = ""
        if (sources.length) {
          try {
            // His words first; else the task's own ("start at row 743").
            let range = rowRange(said)
            if (!range.start && !range.end) range = rowRange(withoutRecords(args.prompt))
            const list = await workLists.make(sources, { chat, start: range.start, end: range.end })
            if (list?.id) {
              listed = list.name
              if (!listIdIn(args.prompt)) args.prompt = `${args.prompt}\n\n${listBlock(list, who())}`
              if (resumed) keepLimited(childLists, resumed, list.id)
              if (input.callID) keepLimited(listByCall, input.callID, list.id)
              tracer.write({ kind: "work_list.made", sessionID: input.sessionID, id: list.id, rows: list.rows,
                             start: list.start_row || 0, reused: Boolean(list.reused) })
            }
          } catch (err) {
            tracer.write({ kind: "work_list.error", sessionID: input.sessionID, error: String(err?.message ?? err) })
          }
        }
        // A path given for an attachment nobody filed (not a listed sheet):
        // nothing is there, so the task goes back to be fixed. On 2026-11-24
        // "/files/Old LinkedIn Connections.xlsx (already filed)" was neither.
        for (const a of attachmentsIn(`${said}\n${args.prompt}`).filter((x) => x.name !== listed)) {
          const path = pathsNaming(withoutRecords(args.prompt), a.name)[0]
          if (path && await workLists.pending(a.id)) {
            tracer.write({ kind: "work_list.unfiled_path", sessionID: input.sessionID, path })
            throw new Error(unfiledRefusal(a.name, path, who()))
          }
        }
        const rewritten = rewriteForBrowser(args.prompt, { listed, who: who() })
        if (rewritten !== args.prompt) {
          args.prompt = rewritten
          tracer.write({ kind: "work_list.uploads_worded", sessionID: input.sessionID, listed: Boolean(listed) })
        }
      }

      /* A browser question about a time, fitted to the slots it captured
       * (lib/slot-question.js): one the page does not offer is refused, ones
       * it left out are added, a description naming another time is dropped. */
      if (captures && toolName === "question" && Array.isArray(args?.questions) && input?.sessionID) {
        const slots = slotTimes(captures.items(input.sessionID, "slots"))
        for (const q of slots.length ? args.questions : []) {
          const fit = fitOptions(q?.options, slots)
          if (!fit) continue
          if (fit.invented.length) {
            tracer.write({ kind: "question.slots_refused", sessionID: input.sessionID, invented: fit.invented })
            throw new Error(
              `pal-harness: ${fit.invented.join(", ")} ${fit.invented.length > 1 ? "are" : "is"} not among the times this page offered `
              + `(your "slots" capture: ${slots.join(", ")}). Ask again with the page's own times as the options.`,
            )
          }
          q.options = fit.options
          if (fit.added.length || fit.dropped) {
            tracer.write({ kind: "question.slots_fitted", sessionID: input.sessionID, added: fit.added.length, dropped: fit.dropped })
          }
        }
      }

      /* The browser's questions to George: the page's wording and choices, one
       * question an entry (answers-ledger.js questionProblems). Only the
       * browser's — the assistant may offer choices of its own. */
      if (ledger && toolName === "question") {
        const problems = questionProblems(args)
        if (problems.length && (await describeSession(input?.sessionID)).agent === "browser") {
          tracer.write({ kind: "question.refused", sessionID: input?.sessionID, problems })
          throw new Error(
            `pal-harness: this question was not sent to ${who().name} — ${problems.join(" Also, ")} `
              + "Ask what the page asks, worded as the page words it, with the page's own choices copied exactly "
              + "(no choices for a typed answer), and call the question tool again."
          )
        }
      }
      /* A value the site turned down, stepped around with one of the
       * browser's own (answers-ledger.js heldBy), and a recipe proved with a
       * value nobody gave (chosen). On 2026-10-28 GOV.UK turned down George's
       * IP33 3YU; the browser tried CB2 1QJ, M1 1AE, OX1 1AA and LS1 1BA,
       * and never asked him. Held until he answers a question. */
      if (ledger && input?.sessionID && (ENTRY_HOLD_TOOLS.has(toolName) || toolName === STEPS_TOOL)) {
        const sid = input.sessionID
        const pairs = toolName === STEPS_TOOL
          ? innerCalls(args).filter((c) => ENTRY_HOLD_TOOLS.has(c.tool)).flatMap((c) => enteredPairs(c.tool, c.args))
          : enteredPairs(toolName, args)
        const held = pairs.map(([question, value]) => ({ value, by: ledger.heldBy(sid, { question, value }) })).find((h) => h.by)
        const isProof = toolName === "playwright_flow_run" && (args?.proposal === true || args?.proposal === "true")
        const unsaid = !held && isProof ? ledger.chosen(sid, pairs) : []
        if ((held || unsaid.length) && (await describeSession(sid)).agent === "browser") {
          const w = who()
          const what = toolName === "playwright_flow_run" ? "flow_run did not run" : `"${held?.value ?? ""}" was not entered`
          if (held) {
            tracer.write({ kind: "refusal.held", sessionID: sid, tool: toolName })
            throw new Error(
              `pal-harness: ${what}. The site turned down ${w.name}'s ${held.by.question ? `${held.by.question} ` : ""}"${held.by.value}" — `
                + `it said ${held.by.said} — and a value of your own cannot tell you whether ${w.his} is right. `
                + `Ask ${w.him} with the question tool: give the site's words and ${w.his} value, and ask ${w.him} to check it. `
                + `Then go on with ${w.his} answer.`
            )
          }
          tracer.write({ kind: "flow_run.unsaid_held", sessionID: sid, count: unsaid.length })
          const listed = unsaid.map(([k, v]) => `"${v}" for ${k}`).join(", ")
          throw new Error(
            `pal-harness: ${what}. ${listed} ${unsaid.length > 1 ? "are" : "is"} not in your task, ${w.name}'s answers or the Vault. `
              + `A recipe is proved, and then published, with a value ${w.name} gave, not one you pick: ask ${w.him} with the `
              + `question tool which ${unsaid.map(([k]) => k).join(" and ")} to test it with, and run it with ${w.his} answer.`
          )
        }
      }
      /* An identifier typed with no source, refused once; a change to an
       * answer the page held before this task that George's own words do not
       * ask for, held (answers-ledger.js entryStop). 2026-11-20 (Voscap): the
       * task's made-up bank details were typed, and George's answers were
       * changed on the assistant's retelling of what he wanted. */
      if (ledger && input?.sessionID && ENTRY_STOP_TOOLS.has(toolName)) {
        const stop = ledger.entryStop(input.sessionID, toolName, args, currentPerson())
        if (stop && (await describeSession(input.sessionID)).agent === "browser") {
          stop.commit()
          tracer.write({ kind: `entry_stop.${stop.kind}`, sessionID: input.sessionID, tool: toolName })
          throw new Error(stop.message)
        }
      }

      /* The browser asking George for PAL's part of his request: whom to
       * email, or a named person's address (lib/own-words.js). */
      if (toolName === "question" && Array.isArray(args?.questions) && input?.sessionID) {
        // His words for this task, from its record, else his last in the chat.
        const own = records?.of(input.sessionID)
        const said = own ? [own.words, ...own.said].join("\n") : personSaid.get(await rootSessionOf(input.sessionID)) ?? ""
        const asked = asksForPALsPart(args, said)
        if (asked && (await describeSession(input.sessionID)).agent === "browser") {
          tracer.write({ kind: "question.pals_part", sessionID: input.sessionID, asked: asked.slice(0, 200) })
          throw new Error(palsPartRefusal())
        }
      }

      /* Asked, then acted, in one step (lib/ask-then-act.js): 2026-10-13 "Is
       * that the one you want cancelled?" and schedule_cancel together, and
       * the daily Morning brief went. Refused before the gate, so no card
       * asks George to approve what he has not yet answered. */
      if (stepText && acts(policy, toolName, args, classify)) {
        const asked = closingQuestion(stepText.said(input?.sessionID, input?.callID))
        if (asked) {
          tracer.write({ kind: "ask-then-act.refused", tool: toolName, sessionID: input?.sessionID, asked })
          throw new Error(askFirstRefusal(toolName, asked, who().name))
        }
      }

      /* An address that is a near miss of one George typed, and that nothing
       * in the chat gave, becomes the one he typed (lib/addresses.js). Before
       * the gate, so the card shows the address the call will use: on
       * 2026-10-19 "rkmakol@gmail.com" reached the card as "rkmak@gmail.com". */
      /* And first, what George put on an earlier card for a call of this kind:
       * a field that still says what he replaced says what he put instead
       * (addresses.js keepCorrections). On 2026-10-28 his corrected address
       * was sent, Gmail refused it for the subject, and the retry's card
       * showed the model's wrong address again. */
      if (args && typeof args === "object" && input?.sessionID) {
        const chat = await rootSessionOf(input.sessionID)
        const kept = addressBook.carry(chat, `${toolName}:${capabilityOf(toolName, args)}`, args)
        if (kept.length) {
          noteRan(input.callID, { kept })
          tracer.write({ kind: "card.kept", tool: toolName, sessionID: input.sessionID,
                         fields: kept.map((c) => c.field) })
        }
        const held = addressBook.hold(chat, args)
        if (held.length) {
          noteRan(input.callID, { held })
          tracer.write({ kind: "address.held", tool: toolName, sessionID: input.sessionID,
                         fields: held.map((c) => c.field) })
        }
      }

      /* "Draft this email" is a draft, and an answer is a threaded reply:
       * the wrong mail call for what was asked is refused before its card
       * (lib/gate.js emailCallNudge, 2026-11-16). */
      if (toolName === "palapi_conn_write" && args && typeof args === "object") {
        const nudge = emailCallNudge(args, personSaid.get(input?.sessionID) ?? "", who())
        if (nudge) {
          tracer.write({ kind: "email.nudged", sessionID: input?.sessionID, action: args.action,
                         why: nudge.startsWith("That is a reply") ? "reply" : "draft" })
          throw new Error(nudge)
        }
      }

      /* An email with no subject is refused before it reaches a card: Gmail
       * would refuse it after George had approved it ("Give it a subject."),
       * and a subject is the model's to write, not his. */
      if (toolName === "palapi_conn_write" && args?.app === "google-mail" && args?.action === "send_message"
          && typeof args.params_json === "string") {
        let subject = null
        try { subject = String(JSON.parse(args.params_json)?.subject ?? "") } catch { /* the tool says so itself */ }
        if (subject !== null && !subject.trim()) {
          tracer.write({ kind: "email.no_subject", sessionID: input?.sessionID })
          throw new Error(
            `Give it a subject. Nothing was sent and no approval card went to ${who().name}: `
            + "write a short subject from what the email says and call send_message again.",
          )
        }
      }

      /* An email that says a booking was made when it was declined, or names
       * a day it was not made for, is held once before its card
       * (lib/booking-claims.js). */
      if (bookings && toolName === "palapi_conn_write" && args?.app === "google-mail"
          && args?.action === "send_message" && typeof args.params_json === "string" && input?.sessionID) {
        let body = ""
        try { body = String(JSON.parse(args.params_json)?.body ?? "") } catch { /* the tool says so itself */ }
        const last = bookings.last(await rootSessionOf(input.sessionID))
        const today = dayOf()
        const clash = body ? emailClash(body, last, today) : null
        if (clash) {
          last.held = true
          tracer.write({ kind: "booking.email_held", sessionID: input.sessionID, clash: clash.kind })
          throw new Error(clashNote(clash, last, who(), today))
        }
      }

      if (!GATE_ON) return
      /* Held until answered (lib/approval-hold.js), and noted while it waits
       * so an opencode restart still hands the call back on the go-ahead. */
      const gateAsk = async (req) => {
        const session = input?.sessionID || ""
        const chat = session ? await rootSessionOf(session) : ""
        return awaitApproval({
          ...req, chatId: chat, holds,
          onHeld: parked && session
            ? async (id) => parked.waiting({ id, chat, session, agent: await agentOfSession(session), tool: toolName, args })
            : null,
        })
      }
      /* A file edit that stays in an app's own folder does not ask
       * (lib/made-apps.js, policy.json _made_app_edit). The instance's own
       * directory decides, never the call's arguments: anywhere but an app's
       * folder this answers false and the edit asks as before. Traced only
       * where it could have said yes, and never with a path. */
      const editInsideApp = MADE_APPS_ON
        ? (tool, a) => {
          const found = insideApp(directory, tool, a)
          if (found.inside || found.why !== "not an app folder") {
            tracer.write({ kind: "made_app.edit", tool, sessionID: input?.sessionID || "", inside: found.inside,
                           ...(found.inside ? { app: found.app, files: found.files } : { why: found.why }) })
          }
          return found.inside
        }
        : undefined
      /* And the other way: a read of anything outside the app's folder, in
       * its instance, asks (lib/made-apps.js readAsk). Null everywhere else,
       * so reads outside app folders are as they were. Traced without a path. */
      const readOutsideApp = MADE_APPS_ON
        ? (tool, a) => {
          const asked = readAsk(directory, tool, a)
          if (asked) tracer.write({ kind: "made_app.read", tool, sessionID: input?.sessionID || "", app: asked.app, why: asked.why })
          return asked
        }
        : undefined
      let verdict
      try {
        verdict = await decide({
          policy, toolName, args,
          deps: { classify, awaitApproval: gateAsk, count: budgets ? budgets.count.bind(budgets) : undefined, insideApp: editInsideApp, appRead: readOutsideApp },
          timeoutS: APPROVAL_TIMEOUT_S,
          // Threaded through so awaitApproval can forward them in the
          // POST /approvals/await body. Two server-side uses: the A20
          // approval-edit trace, and the "Allow for this session" bypass
          // (session_bypass.py). An empty session id means the hook had no
          // session to attribute; the bypass never matches "".
          sessionId: input?.sessionID || "",
          agentId: input?.agent || "",
        })
      } catch (err) {
        // Belt and braces: an unexpected throw inside decide() still BLOCKS.
        tracer.write({ kind: "gate.error", tool: toolName, error: String(err) })
        throw new Error(`pal-gate: '${toolName}' could not be evaluated and was DENIED. The action was NOT performed.`)
      }
      // `outcome` and `approvalId` are what turn "why did this not run?" into one
      // grep. Without them, establishing that approval #223 lapsed rather than
      // being refused took the pal-api log, the envelope table and the ntfy cache.
      tracer.write({
        kind: "tool.before", tool: toolName, allow: verdict.allow,
        outcome: verdict.outcome ?? null, approvalId: verdict.id ?? null,
        why: verdict.reason, sessionID: input?.sessionID || "",
        // Which capability a dispatching tool was asked for — the command,
        // the linked app's action, the library action; never its arguments'
        // content. scripts/actions-shadow.py compares it with the turn's cards.
        cap: capabilityOf(toolName, args),
      })
      // Parked: noted by chat, for the go-ahead after George approves it.
      // Claimed: that grant is spent (lib/parked-calls.js).
      if (parked && Number.isFinite(verdict.id)) {
        try {
          const session = input?.sessionID || ""
          if (verdict.outcome === "deferred" && session) {
            parked.park({
              id: verdict.id, chat: await rootSessionOf(session), session,
              agent: await agentOfSession(session), tool: toolName, args,
            })
          } else if (verdict.outcome === "claimed") {
            parked.spent(verdict.id)
            for (const [chat, grants] of handBacks) {
              const left = grants.filter((g) => g.id !== verdict.id)
              if (left.length) handBacks.set(chat, left)
              else handBacks.delete(chat)
            }
          } else {
            // Answered on the card it was held on: nothing left to hand back.
            parked.spent(verdict.id)
          }
        } catch (err) {
          tracer.write({ kind: "parked.error", tool: toolName, error: String(err) })
        }
      }
      if (verdict.stop && input?.sessionID) endTurn(input.sessionID, toolName)
      if (!verdict.allow) throw new Error(verdict.reason)

      /* APPROVE-WITH-EDIT, the other half of the 2026-08-09 bug: the user's
       * corrected params must become the call. The edit REPLACES the args
       * wholesale — pal-api's contract is "corrected params, same shape as the
       * envelope's" (ENVELOPE.md), so a key absent from the edit is a key the
       * user removed, and merging instead would quietly keep it. Mutating in
       * place, key by key, because reassigning `output.args` is silently
       * discarded (lesson 3, and the filing block above). An edit whose shape
       * the tool cannot take fails at the tool's own schema — loudly, which is
       * the right failure for a correction that could not be honoured.
       *
       * The model never sees the edit: opencode keeps its call as written. So
       * what changed is added to the result (tool.execute.after), or it
       * reports its draft, as on 2026-10-19: "emailed the notes to
       * rkmak@gmail.com" after George's corrected address had been sent. */
      if (verdict.edited && typeof verdict.edited === "object" && args && typeof args === "object") {
        const changes = editChanges(args, verdict.edited)
        const byCard = (c) => (verdict.filled ?? []).some((f) => c.field === f || c.field.endsWith(`.${f}`))
        const edited = changes.filter((c) => !byCard(c))
        noteRan(input?.callID, { edited, filled: changes.filter(byCard) })
        // Kept for the calls after this one: if this one fails, opencode runs
        // no after-hook, and the model's retry carries its own values again.
        if (input?.sessionID && edited.length) {
          addressBook.corrected(await rootSessionOf(input.sessionID),
                                `${toolName}:${capabilityOf(toolName, args)}`, input.callID, edited)
        }
        for (const key of Object.keys(args)) {
          if (!(key in verdict.edited)) delete args[key]
        }
        Object.assign(args, verdict.edited)
        tracer.write({
          kind: "gate.edit", tool: toolName, approvalId: verdict.id ?? null,
          keys: Object.keys(verdict.edited),
        })
      }
    },

    "tool.execute.after": async (input, output) => {
      tracer.write({
        kind: "tool.after",
        tool: input?.tool,
        title: output?.title,
        // resultText: an MCP tool's result is {content: [...]}, not `output`.
        output_chars: resultText(output).length,
      })
      /* A web tool's pictures, from the result's `_meta` onto the part's
       * `metadata`, where the app reads them and no model does (lib/media-meta.js). */
      if (carryMedia(output)) {
        tracer.write({ kind: "media.carried", tool: input?.tool,
                       items: output.metadata.palMedia?.items?.length ?? 0 })
      }
      /* What the tool returned, as it returned it — before any note below is
       * added — is a source for the values in it (lib/provenance.js). */
      if (provenance && input?.sessionID) {
        try {
          provenance.noteCall(input.sessionID, String(input?.tool ?? ""), input?.args, resultText(output),
            { metadata: output?.metadata, except: (c) => ledger?.unsourced(c) ?? [] })
        } catch (err) {
          tracer.write({ kind: "provenance.error", error: String(err) })
        }
      }
      if (fresh && PAGE_TOOL_RE.test(String(input?.tool ?? ""))) fresh.reached(input?.sessionID)
      /* A change PAL made on the Mac (an action_do mac.* call that answered an
       * undo_token): the chat's next "undo that" is mac.undo. */
      if (ACTION_DO_TOOLS.has(String(input?.tool ?? "")) && input?.sessionID) {
        const change = macChangeOf(input.tool, input?.args, resultText(output))
        if (change) macChanges.note(await rootSessionOf(input.sessionID), change)
        const watch = macWatchOf(input.tool, input?.args, resultText(output))
        if (watch) macWatching.note(await rootSessionOf(input.sessionID), watch)
      }
      if (oneJob && input?.tool === "task") oneJob.release(input?.callID)
      if (pageIds && input?.sessionID) pageIds.saw(input.sessionID, resultText(output))
      /* The recipes a lookup or a run showed this session; and a run that
       * stopped, come back to an agent with no page tools, turned into what
       * to do now: hand the job to `browser`, on the page it stopped on
       * (the recipe guard in lib/actions.js; the before hook above says why). */
      if (FLOW_GUARD_ON && input?.sessionID && /^playwright_(?:flow_lookup|flow_run|browser_task)$/.test(String(input?.tool ?? ""))) {
        try {
          flowNames?.saw(input.sessionID, resultText(output))
          const run = input.tool === "playwright_flow_run" ? stoppedRun(resultText(output)) : null
          if (run && !(await runsAsBrowser(input))) {
            const chat = await rootSessionOf(input.sessionID)
            const words = personSaid.get(chat) ?? personSaid.get(input.sessionID) ?? String(input?.args?.words ?? "")
            const directive = delegateDirective(run, { params: input?.args?.params, words, person: currentPerson() })
            if (replaceResult(output, directive)) {
              if (stoppedRecipes.size >= 256 && !stoppedRecipes.has(input.sessionID)) stoppedRecipes.delete(stoppedRecipes.keys().next().value)
              stoppedRecipes.set(input.sessionID, { site: siteKey(run.domain || input?.args?.domain), directive })
              tracer.write({ kind: "flow_guard.delegate", sessionID: input.sessionID, run: run.kind,
                             domain: run.domain, flow: run.flow, step: run.step })
            }
          }
        } catch (err) {
          tracer.write({ kind: "flow_guard.error", error: String(err) })
        }
      }
      /* What the result says is a source for an address; then, if what ran is
       * not the call the model wrote, the result says so (lib/addresses.js). */
      if (input?.sessionID) {
        const chat = await rootSessionOf(input.sessionID)
        addressBook.saw(chat, resultText(output))
        addressBook.ran(chat, input.callID)
      }
      if (input?.tool === "question" && input?.sessionID) {
        if (lastAnswers.size >= 256 && !lastAnswers.has(input.sessionID)) lastAnswers.delete(lastAnswers.keys().next().value)
        lastAnswers.set(input.sessionID, resultText(output).slice(-2000))
        /* "Change task" instead of an answer (lib/own-words.js). A
         * sub-agent may have no tool for it: it reports, and its parent is
         * handed the words with the task's result, below. */
        const instead = insteadIn(output?.metadata?.answers)
        if (instead && (await describeSession(input.sessionID)).parentID) {
          if (insteadByChild.size >= 256 && !insteadByChild.has(input.sessionID)) insteadByChild.delete(insteadByChild.keys().next().value)
          insteadByChild.set(input.sessionID, instead)
          appendToResult(output, insteadNote())
          tracer.write({ kind: "question.instead", sessionID: input.sessionID, sub: true })
        } else if (instead) {
          tracer.write({ kind: "question.instead", sessionID: input.sessionID, sub: false })
        }
        /* "Have a look at the email from Daniel": the browser cannot open his
         * mail, so it stops and reports, and the assistant fetches it. */
        const pointed = answersOf(input?.args?.questions, output?.metadata?.answers).filter(pointsElsewhere)
        if (pointed.length && await runsAsBrowser(input)) {
          if (pointedByChild.size >= 256 && !pointedByChild.has(input.sessionID)) pointedByChild.delete(pointedByChild.keys().next().value)
          pointedByChild.set(input.sessionID, [...(pointedByChild.get(input.sessionID) ?? []), ...pointed])
          appendToResult(output, lookElsewhereNote(currentPerson()))
          tracer.write({ kind: "question.points_elsewhere", sessionID: input.sessionID, count: pointed.length })
        }
      }
      /* The browser found what the pointer pointed at with its own lookup
       * (nas-browser-v2 lookup.mjs): nothing is left for the assistant to fetch. */
      if (input?.tool === "playwright_browser_lookup" && pointedByChild.has(input?.sessionID)
          && /^Found in .+?'s files: /m.test(resultText(output))) {
        pointedByChild.delete(input.sessionID)
        tracer.write({ kind: "lookup.found_pointer", sessionID: input.sessionID })
      }
      if (input?.tool === "task" && pointedByChild.size && typeof output?.output === "string") {
        const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1]
          || String(input?.args?.task_id ?? "").trim()
        const pointed = child ? pointedByChild.get(child) : undefined
        if (pointed) {
          pointedByChild.delete(child)
          appendToResult(output, lookElsewhereOnTask(pointed, child, currentPerson()))
          tracer.write({ kind: "task.points_elsewhere", sessionID: input?.sessionID, child })
        }
      }
      if (input?.tool === "task" && insteadByChild.size && typeof output?.output === "string") {
        const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1]
          || String(input?.args?.task_id ?? "").trim()
        const words = child ? insteadByChild.get(child) : ""
        if (words) {
          insteadByChild.delete(child)
          appendToResult(output, insteadOnTask(words))
          tracer.write({ kind: "task.instead", sessionID: input?.sessionID, child })
        }
      }
      /* A browser task with a work list: its result ends with the counts as
       * code kept them, so the reply gives George those and not the browser's
       * retelling (lib/work-list.js). */
      const listOfCall = input?.tool === "task" && input?.callID ? listByCall.get(input.callID) : undefined
      if (listOfCall && typeof output?.output === "string") {
        listByCall.delete(input.callID)
        const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1]
        if (child) keepLimited(childLists, child, listOfCall)
        try {
          if (appendToResult(output, resultLine(await workLists.get(listOfCall), who()))) {
            tracer.write({ kind: "work_list.result", sessionID: input?.sessionID, id: listOfCall })
          }
        } catch (err) {
          tracer.write({ kind: "work_list.result_error", sessionID: input?.sessionID, error: String(err?.message ?? err) })
        }
      }
      /* An address taken out of the browser task the assistant sent: its
       * result says so, so the assistant neither pastes it in again nor tells
       * George the site could not be reached (lib/site-guess.js). */
      const dropped = input?.tool === "task" && input?.callID ? droppedByCall.get(input.callID) : undefined
      if (dropped) {
        droppedByCall.delete(input.callID)
        if (appendToResult(output, droppedResultNote(dropped, currentPerson()))) {
          tracer.write({ kind: "site_guess.told", sessionID: input?.sessionID, dropped })
        }
      }
      const ran = input?.callID ? ranChanges.get(input.callID) : undefined
      if (ran) {
        ranChanges.delete(input.callID)
        if (appendToResult(output, ranNote({ ...ran, name: who().name }))) {
          tracer.write({ kind: "ran.note", tool: input?.tool, sessionID: input?.sessionID,
                         edited: ran.edited.map((c) => c.field), held: ran.held.map((c) => c.field),
                         filled: ran.filled.map((c) => c.field), kept: ran.kept.map((c) => c.field) })
        }
      }
      /* A `browser` task's result, for the router: the chat now has a browser
       * job open, and George's next message may be his answer to it
       * (router-core.js browserJobs). */
      const isBrowserTask = input?.tool === "task" && input?.args?.subagent_type === "browser"
      let browserJob = null
      if (rememberBrowserTask && isBrowserTask) {
        try {
          const job = rememberBrowserTask(input?.sessionID, output?.output)
          browserJob = job
          if (job) tracer.write({ kind: "browser.job", sessionID: input?.sessionID, taskId: job.taskId, waiting: job.waiting })
        } catch (err) {
          tracer.write({ kind: "browser.job.error", error: String(err) })
        }
      }
      /* A `research` task's result: "continue" now means that finished job. */
      if (rememberResearchTask && input?.tool === "task" && input?.args?.subagent_type === "research") {
        try {
          const job = rememberResearchTask(input?.sessionID, output?.output)
          if (job) tracer.write({ kind: "research.job", sessionID: input?.sessionID, taskId: job.taskId })
        } catch (err) {
          tracer.write({ kind: "research.job.error", error: String(err) })
        }
      }
      /* What the assistant does once the job is back (lib/jobs.md ### After),
       * on the end of the result — after the captures and the record it
       * refers to, so it is appended last, below. */
      let after = ""
      if (JOBS_ON && isBrowserTask) {
        try {
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(String(output?.output ?? "")) || [])[1] || ""
          const name = jobInPrompt(input?.args?.prompt) || jobByChild.get(child) || ""
          if (child && name) {
            if (jobByChild.size >= 256 && !jobByChild.has(child)) jobByChild.delete(jobByChild.keys().next().value)
            jobByChild.set(child, name)
          }
          const job = name ? loadJobs(JOBS_FILE).find((j) => j.name === name) : null
          const look = lookInPrompt(input?.args?.prompt) || lookChildren.has(child)
          after = job ? afterBlock(job, { look }) : ""
          // The calendar the booking was told about: the assistant checks the
          // time against it too.
          if (child && !calendarByChild.has(child) && !String(input?.args?.task_id ?? "").trim()) {
            const near = calendarByChat.get(input?.sessionID)
            if (near) {
              calendarByChat.delete(input?.sessionID)
              if (calendarByChild.size >= 256) calendarByChild.delete(calendarByChild.keys().next().value)
              calendarByChild.set(child, near)
            }
          }
          const near = child ? calendarByChild.get(child) : null
          if (job && near) after = `${after}\n\n${afterCalendarBlock(near, who())}`
        } catch (err) {
          tracer.write({ kind: "job.error", error: String(err) })
        }
      }
      /* A stall the browser had on the way, on its result: George was told on
       * his phone, and the assistant should know it too (lib/stall-watch.js). */
      if (isBrowserTask && stallNotes.has(input?.sessionID)) {
        const line = stallNotes.get(input.sessionID)
        stallNotes.delete(input.sessionID)
        appendToResult(output, `[PAL, on the way: ${line}]`)
      }
      /* The job ended: learned as a recipe when it ended well and the browser
       * saw it done on a site (lib/recipe-learn.js). Its line goes on the
       * result, for the assistant to pass on. */
      if (recipeLearn && isBrowserTask && typeof output?.output === "string") {
        try {
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1] || ""
          const line = await recipeLearn.afterBrowserTask({
            chat: input?.sessionID, child, output: output.output, waiting: Boolean(browserJob?.waiting),
            record: child ? records?.of(child) ?? null : null,
            ledgerRows: child && ledger ? ledger.entries(child) : [],
            brief: String(input?.args?.prompt ?? ""),
          })
          if (line) appendToResult(output, line)
        } catch (err) {
          tracer.write({ kind: "recipe_learn.error", error: String(err) })
        }
      }
      /* A new browser task whose only turn did nothing but say what it was
       * about to do (lib/runaway.js redoEmptyTurn): the same browser is asked
       * to do it, and its report takes the sentence's place. */
      if (isBrowserTask && typeof output?.output === "string" && !String(input?.args?.task_id ?? "").trim()) {
        try {
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1]
          const redone = child ? await redoEmptyTurn(child, {
            read: async (sid) => (await readSession(sid)).messages,
            prompt: (sid, body) => askBrowser(sid, body, EMPTY_TURN_TIMEOUT_MS),
          }) : null
          if (redone) {
            output.output = withReportReplaced(output.output, redone.report)
            tracer.write({ kind: "browser.empty_turn_redone", sessionID: input?.sessionID, child, chars: redone.report.length })
          }
        } catch (err) {
          tracer.write({ kind: "browser.empty_turn.error", error: String(err) })
        }
      }
      /* A report the browser's output limit ended mid-way (lib/runaway.js):
       * the browser that wrote it goes on from the cut and the rest joins the
       * report where it stopped. One still cut is said to be, on the result,
       * first, so it is not relayed as the whole. */
      if (isBrowserTask && typeof output?.output === "string") {
        try {
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(output.output) || [])[1]
          /* A form's cut report is written from PAL's record instead (lib/capped-report.js). */
          const coded = child ? await cappedReportFor(child, { read: async (sid) => (await readSession(sid)).messages, ledger, work }) : null
          if (coded) {
            output.output = withReportReplaced(output.output, coded)
            tracer.write({ kind: "browser.report_capped", sessionID: input?.sessionID, child, chars: coded.length })
          }
          const carried = child && !coded ? await continueReport(child, {
            read: async (sid) => (await readSession(sid)).messages,
            prompt: (sid, body) => askBrowser(sid, body),
          }) : null
          if (carried?.added) output.output = withReportAdded(output.output, carried.added)
          if (carried) {
            tracer.write({ kind: "browser.report_continued", sessionID: input?.sessionID, child, pieces: carried.pieces, chars: carried.added.length, stillCut: carried.stillCut })
          }
          if (carried?.stillCut) {
            appendToResult(output, "[PAL: the browser's report above was cut off at its output limit, so it ends mid-way and anything after the cut is lost. "
              + `What was captured below is complete. Tell ${who().name} the report was cut short; do not fill in the rest yourself.]`)
            tracer.write({ kind: "browser.report_cut", sessionID: input?.sessionID, child })
          }
        } catch (err) {
          tracer.write({ kind: "browser.report_cut.error", error: String(err) })
        }
      }
      /* The report held against what its sub-agent read (lib/grounding.js):
       * a link no page showed is marked where it stands, and the note says
       * which links, which names and which of George's conditions no page
       * backs. After the cut report is dealt with, before PAL's own blocks. */
      if (GROUNDING_ON && input?.tool === "task" && READING_AGENTS.has(String(input?.args?.subagent_type ?? ""))
          && typeof output?.output === "string") {
        try {
          const child = TASK_ID_RE.exec(output.output)?.[1]
          const read = child ? await readChild(child, { fresh: true }) : null
          const { head, report } = splitTaskResult(output.output)
          if (read && report.trim()) {
            const links = unseenLinks(report, read.seen)
            const names = unseenNames(report, read.seen)
            const conditions = reportLines(report, read.conds, read.seen.pages(), who())
            if (links.length) {
              const at = output.output.indexOf(report, head.length)
              output.output = output.output.slice(0, at) + markLinks(report, links, REPORT_MARK) + output.output.slice(at + report.length)
            }
            const note = reportNote({ links, names, conditions })
            if (note) appendToResult(output, note)
            tracer.write({ kind: "grounding.report", sessionID: input?.sessionID, child, links: links.length, names: names.length, conditions: conditions.length })
          }
        } catch (err) {
          tracer.write({ kind: "grounding.error", error: String(err) })
        }
      }
      /* A capture, kept for the task's result; and on the task's result, every
       * capture its browser made, before the ledger's record. */
      if (captures) {
        try {
          if (input?.tool === "playwright_browser_capture") {
            if (captures.note(input?.sessionID, resultText(output))) tracer.write({ kind: "capture.note", sessionID: input?.sessionID })
          } else if (input?.tool === "playwright_browser_found") {
            /* What the browser kept, held against what George asked for: on
             * 2026-10-30 "a MacBook Pro extension cable" came back as five
             * hubs and docks. An item whose name does not say it is that kind
             * of thing is kept, marked, and the browser is told at once. */
            const item = records && input?.sessionID ? records.of(input.sessionID)?.item : null
            const kindOf = item?.heads?.length ? (name) => saysKind(name, item.heads) : null
            if (captures.noteFound(input?.sessionID, resultText(output), { kindOf })) {
              tracer.write({ kind: "capture.found", sessionID: input?.sessionID })
              const off = kindOf ? (parseFound(resultText(output))?.items ?? []).filter((it) => !kindOf(it.name)) : []
              if (off.length && appendToResult(output, offKindNote(item, off, who()))) {
                tracer.write({ kind: "capture.off_kind", sessionID: input?.sessionID, count: off.length })
              }
            }
          } else if (input?.tool === "playwright_browser_save") {
            if (captures.noteSaved(input?.sessionID, resultText(output))) tracer.write({ kind: "capture.saved", sessionID: input?.sessionID })
          } else if (input?.tool === "playwright_browser_vault_list") {
            if (captures.noteVault(input?.sessionID, resultText(output))) tracer.write({ kind: "capture.vault", sessionID: input?.sessionID })
          } else if (input?.tool === "playwright_browser_commit" || input?.tool === "playwright_browser_click") {
            if (captures.noteDraft(input?.sessionID, resultText(output))) tracer.write({ kind: "capture.draft", sessionID: input?.sessionID })
          } else if (isBrowserTask) {
            const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(String(output?.output ?? "")) || [])[1]
            // Matches kept before this turn went out with an earlier result.
            const asked = records && child ? records.of(child)?.item : null
            const block = child ? captures.render(child, { since: work?.summary(child)?.foundAtStart ?? 0, kind: kindWords(asked) }) : ""
            if (block && appendToResult(output, block)) tracer.write({ kind: "capture.render", sessionID: input?.sessionID, child })
          }
        } catch (err) {
          tracer.write({ kind: "capture.error", error: String(err) })
        }
      }
      /* The budget's, the block's and the first look's notes on a browser
       * step's result (lib/browser-budget.js) — after the captures above, so
       * a browser_found's matches are counted on its own result. */
      if (work && input?.sessionID && work.tracked(input.sessionID) && typeof input?.tool === "string") {
        try {
          const found = captures ? captures.foundCount(input.sessionID) : undefined
          const notes = input.tool === STEPS_TOOL
            ? browserBudgetAfter(work, input.sessionID, input?.args, resultText(output), { found })
            : work.after(input.sessionID, input.tool, resultText(output), { found, args: input?.args })
          if (notes.length && appendToResult(output, notes.join("\n"))) {
            tracer.write({ kind: "browser_budget.note", sessionID: input.sessionID, tool: input.tool, count: notes.length })
          }
        } catch (err) {
          tracer.write({ kind: "browser_budget.error", error: String(err) })
        }
      }
      /* Sites that blocked the browser, and a budget it ran out of, on the
       * task's result: the assistant tells George (lib/browser-budget.js). */
      if (work && isBrowserTask) {
        try {
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(String(output?.output ?? "")) || [])[1]
          const about = child ? work.resultBlock(child) : ""
          if (about && appendToResult(output, about)) tracer.write({ kind: "browser_budget.render", sessionID: input?.sessionID, child })
        } catch (err) {
          tracer.write({ kind: "browser_budget.error", error: String(err) })
        }
      }
      /* A browser task's record keeps George's answers to its questions, and
       * a copy of what its run has noted, once the ledger has read this call
       * (lib/task-record.js). */
      const noteRecord = () => {
        const rec = records && input?.sessionID ? records.of(input.sessionID) : null
        if (!rec) return
        try {
          if (input?.tool === "question") {
            const qs = Array.isArray(input?.args?.questions) ? input.args.questions : []
            const as = Array.isArray(output?.metadata?.answers) ? output.metadata.answers : []
            let noted = 0
            qs.forEach((q, i) => {
              const a = [as[i]].flat().filter(Boolean).join(", ")
              // An answer that only says where to look is no answer to a page's
              // question: it is not carried as one (lib/chat-answers.js).
              if (q?.question && a && !insteadIn(a) && !pointsElsewhere(a) && noteRecordAnswer(rec, q.question, a, "browser")) noted++
            })
            if (noted) {
              records.changed(rec)
              tracer.write({ kind: "task_record.answers", sessionID: input.sessionID, id: rec.id, noted })
            }
          } else if (String(input?.tool || "").startsWith("playwright_")) {
            noteRun(input.sessionID)
          }
        } catch (err) {
          tracer.write({ kind: "task_record.error", sessionID: input?.sessionID, error: String(err) })
        }
      }
      if (!ledger) {
        noteRecord()
        if (after && appendToResult(output, after)) tracer.write({ kind: "job.after", sessionID: input?.sessionID })
        return
      }
      try {
        const sid = input?.sessionID
        if (input?.tool === "question") {
          ledger.noteAnswers(sid, output?.metadata?.answers, input?.args?.questions)
          const browsing = ledger.snapshot(sid)
          if (chatAnswers && browsing) {
            const chat = await rootSessionOf(sid)
            let host = ""
            try { host = browsing.url ? new URL(browsing.url).hostname : "" } catch { host = "" }
            const qs = Array.isArray(input?.args?.questions) ? input.args.questions : []
            const as = Array.isArray(output?.metadata?.answers) ? output.metadata.answers : []
            qs.forEach((q, i) => {
              const a = [as[i]].flat().filter(Boolean).join(", ")
              if (q?.question && a && !pointsElsewhere(a)) chatAnswers.note(chat, host, q.question, a)
            })
          }
        } else if (String(input?.tool || "").startsWith("playwright_browser_")) {
          // A list's actions each with its own arguments and lines (lib/browser-steps.js).
          const calls = input.tool === STEPS_TOOL
            ? innerResults(input?.args, resultText(output)).filter((r) => r.ok)
            : [{ tool: input.tool, args: input?.args, text: resultText(output) }]
          const warnings = calls.flatMap((c) => ledger.noteEntries(sid, c.tool, c.args, c.text))
          if (warnings.length) {
            appendToResult(output, warnings.join("\n"))
            tracer.write({ kind: "ledger.warn", sessionID: sid, tool: input.tool, count: warnings.length })
          }
        } else if (isBrowserTask) {
          // After the router has read the result: the record goes on its end.
          const child = (/<task id="(ses_[A-Za-z0-9]+)"/.exec(String(output?.output ?? "")) || [])[1]
          const record = child ? ledger.render(child) : ""
          if (record && appendToResult(output, record)) tracer.write({ kind: "ledger.render", sessionID: sid, child })
          if (KEEP_ANSWERS_ON && child) {
            const offered = await offerAnswers(sid, child)
            if (offered) {
              const w = who()
              appendToResult(output, `[PAL asked ${w.name}, on ${w.his} phone, whether to keep ${offered === 1 ? `one of ${w.his} answers` : `${offered} of ${w.his} answers`} in ${w.his} Vault for next time. Nothing for you to do.]`)
              tracer.write({ kind: "answers.offer", sessionID: sid, child, offered })
            }
          }
        }
      } catch (err) {
        tracer.write({ kind: "ledger.error", error: String(err) })
      } finally {
        noteRecord()
        if (after && appendToResult(output, after)) tracer.write({ kind: "job.after", sessionID: input?.sessionID })
      }
    },
  }

  /* What did not run (lib/refused-calls.js). A call tool.execute.before
   * throws on never ran, whichever check refused it; each call it lets through
   * did. An answer written after the turn's last call was refused has its
   * claims about that call marked, once the grounding check is done with it.
   * 2026-10-21: "I also did a quick scan" of a find ask-then-act had refused. */
  /* A browser task refused by a check after it took the chat's browser
   * (lib/one-browser-job.js) never runs, so it never comes back to let go. */
  if (oneJob) {
    const before = hooks["tool.execute.before"]
    hooks["tool.execute.before"] = async (input, output) => {
      try {
        await before(input, output)
      } catch (err) {
        if (input?.tool === "task") oneJob.release(input?.callID)
        throw err
      }
    }
  }
  if (refusedCalls) {
    const before = hooks["tool.execute.before"]
    hooks["tool.execute.before"] = async (input, output) => {
      try {
        await before(input, output)
      } catch (err) {
        try { refusedCalls.refused(input?.sessionID, input?.tool, output?.args) } catch {}
        throw err
      }
      // Bookkeeping: a fault here must never stop a call the checks let through.
      try { refusedCalls.ran(input?.sessionID, input?.tool, output?.args) } catch {}
    }
    const complete = hooks["experimental.text.complete"]
    hooks["experimental.text.complete"] = async (input, output) => {
      await complete(input, output)
      try {
        const checked = refusedCalls.check(input?.sessionID, output?.text)
        if (checked) {
          output.text = checked.text
          tracer.write({ kind: "refused.claim", sessionID: input?.sessionID, claims: checked.claims })
        }
      } catch (err) {
        tracer.write({ kind: "refused.claim_error", error: String(err) })
      }
    }
  }
  /* An answer that says something was added or saved when every change this
   * turn failed, or that a card is waiting when none is (lib/done-claims.js).
   * Wrapped after refused-calls, so a sentence it marked is not marked twice. */
  if (doneClaims) {
    const before = hooks["tool.execute.before"]
    hooks["tool.execute.before"] = async (input, output) => {
      try {
        await before(input, output)
      } catch (err) {
        try { doneClaims.started(input?.sessionID, input?.callID, input?.tool, output?.args, { refused: true }) } catch {}
        throw err
      }
      try { doneClaims.started(input?.sessionID, input?.callID, input?.tool, output?.args) } catch {}
    }
    const after = hooks["tool.execute.after"]
    hooks["tool.execute.after"] = async (input, output) => {
      // The result as the tool gave it, before the hooks below add to it.
      try { doneClaims.finished(input?.sessionID, input?.callID, resultText(output)) } catch {}
      return after(input, output)
    }
    const complete = hooks["experimental.text.complete"]
    hooks["experimental.text.complete"] = async (input, output) => {
      await complete(input, output)
      const sid = input?.sessionID
      try {
        // The person's chat only, like reviewClaims: a sub-agent's report goes
        // through its task result, not to the person.
        if (!sid || typeof output?.text !== "string" || await isSubagentTurn({}, sid)) return
        if (!output.text.includes(REFUSED_HEAD)) {
          const done = doneClaims.checkDone(sid, output.text)
          if (done) {
            output.text = done.text
            tracer.write({ kind: "done.claim", sessionID: sid, claims: done.claims })
          }
        }
        if (sid && typeof output?.text === "string" && cardClaims(output.text).length) {
          const rows = await questionApi().pending()
          let card = checkCard(output.text, rows, [sid])
          // A card a sub-agent of this chat raised is this chat's too.
          for (const r of card ? rows : []) {
            if (r?.session_id && await rootSessionOf(r.session_id) === sid) { card = null; break }
          }
          if (card) {
            output.text = card.text
            tracer.write({ kind: "card.claim", sessionID: sid, claims: card.claims })
          }
        }
      } catch (err) {
        // FAIL-OPEN: pal-api not answering leaves the answer as written.
        tracer.write({ kind: "done.claim_error", error: String(err) })
      }
    }
  }
  return hooks
}

// opencode's documented plugin shape is a DEFAULT export; this file has always
// used a named one, and `opencode run` accepts it — so the named export is not
// the reason `serve` never fires chat.message. Both are exported now anyway,
// because "which export does the loader take?" is a question worth deleting
// rather than answering, and the two cost one line.
export default PALHarness
