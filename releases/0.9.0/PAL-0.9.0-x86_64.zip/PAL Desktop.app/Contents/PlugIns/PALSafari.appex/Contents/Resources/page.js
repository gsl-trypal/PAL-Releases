"use strict";
(() => {
  // src/lib/frames.ts
  var MAX_FRAME_BYTES = 1024 * 1024;
  var BridgeError = class extends Error {
    kind;
    reason;
    constructor(kind, message, reason) {
      super(message);
      this.name = "BridgeError";
      this.kind = kind;
      if (reason) this.reason = reason;
    }
  };
  var encoder = new TextEncoder();
  var decoder = new TextDecoder("utf-8", { fatal: true });

  // src/lib/rules.ts
  var SECURE_TOKENS = /* @__PURE__ */ new Set(["one-time-code", "current-password", "new-password"]);
  var SECURE_NAME = /(^|[^a-z])(cc[-_]?(number|num|csc|cvc|cvv|exp)|card[-_]?(number|num|no)|cvv2?|cvc2?|csc|security[-_]?code|one[-_]?time[-_]?code|otp)([^a-z]|$)/i;
  function isSecureField(el) {
    if (!el || !el.tagName) return false;
    const tag2 = el.tagName.toLowerCase();
    if (tag2 !== "input" && tag2 !== "textarea") return false;
    const attr2 = (n) => el.getAttribute ? el.getAttribute(n) ?? "" : "";
    const type = (el.type || attr2("type") || "text").toLowerCase();
    if (type === "password") return true;
    if (type === "hidden") return false;
    const tokens = attr2("autocomplete").toLowerCase().split(/\s+/).filter(Boolean);
    for (const t of tokens) {
      if (t.startsWith("cc-") || SECURE_TOKENS.has(t)) return true;
    }
    if (SECURE_NAME.test(attr2("name")) || SECURE_NAME.test(attr2("id"))) return true;
    return false;
  }
  function checkField(el) {
    if (isSecureField(el)) {
      throw new BridgeError(
        "refused",
        "That is a password, card or one-time-code field. PAL never reads or types in it \u2014 they fill it in themselves.",
        "secure"
      );
    }
  }

  // src/lib/outline.ts
  var ELEMENT = 1;
  var TEXT = 3;
  var NAME_MAX = 200;
  var OPTIONS_SHOWN = 30;
  var ACTIONABLE = /* @__PURE__ */ new Set([
    "button",
    "link",
    "textbox",
    "searchbox",
    "checkbox",
    "radio",
    "combobox",
    "listbox",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "slider",
    "spinbutton",
    "switch",
    "option",
    "treeitem"
  ]);
  var QUIET_WHEN_UNNAMED = /* @__PURE__ */ new Set([
    "generic",
    "group",
    "region",
    "form",
    "rowgroup",
    "article",
    "figure",
    "blockquote",
    "paragraph",
    "label",
    "search",
    "status",
    "note",
    "definition",
    "term",
    "time",
    "math",
    "listitem"
  ]);
  var SKIPPED_TAGS = /* @__PURE__ */ new Set([
    "script",
    "style",
    "noscript",
    "template",
    "head",
    "meta",
    "link",
    "title",
    "base",
    "param",
    "source",
    "track",
    "hr",
    "wbr",
    "datalist",
    "object",
    "embed",
    "map"
  ]);
  var INLINE_TAGS = /* @__PURE__ */ new Set([
    "b",
    "i",
    "em",
    "strong",
    "span",
    "small",
    "code",
    "abbr",
    "time",
    "mark",
    "sub",
    "sup",
    "u",
    "s",
    "q",
    "cite",
    "kbd",
    "var",
    "font",
    "bdi",
    "bdo",
    "data",
    "del",
    "ins",
    "dfn",
    "samp",
    "tt",
    "big",
    "strike",
    "nobr",
    "br",
    "a"
  ]);
  var NAME_FROM_CONTENT = /* @__PURE__ */ new Set([
    "button",
    "link",
    "heading",
    "tab",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "option",
    "checkbox",
    "radio",
    "switch",
    "treeitem",
    "cell",
    "gridcell",
    "columnheader",
    "rowheader",
    "tooltip"
  ]);
  var SHOWS_VALUE = /* @__PURE__ */ new Set(["textbox", "searchbox", "combobox", "slider", "spinbutton"]);
  var TOGGLES = /* @__PURE__ */ new Set(["checkbox", "radio", "switch", "menuitemcheckbox", "menuitemradio"]);
  var KNOWN_ROLES = /* @__PURE__ */ new Set([
    ...ACTIONABLE,
    "alert",
    "alertdialog",
    "application",
    "article",
    "banner",
    "blockquote",
    "caption",
    "cell",
    "code",
    "columnheader",
    "complementary",
    "contentinfo",
    "definition",
    "dialog",
    "directory",
    "document",
    "feed",
    "figure",
    "form",
    "generic",
    "grid",
    "gridcell",
    "group",
    "heading",
    "img",
    "image",
    "list",
    "listitem",
    "log",
    "main",
    "marquee",
    "math",
    "menu",
    "menubar",
    "meter",
    "navigation",
    "none",
    "note",
    "paragraph",
    "presentation",
    "progressbar",
    "radiogroup",
    "region",
    "row",
    "rowgroup",
    "rowheader",
    "scrollbar",
    "search",
    "separator",
    "status",
    "table",
    "tablist",
    "tabpanel",
    "term",
    "time",
    "timer",
    "toolbar",
    "tooltip",
    "tree",
    "treegrid",
    "iframe",
    "label",
    "legend"
  ]);
  function tagOf(el) {
    return (el.tagName || "").toLowerCase();
  }
  function attr(el, name) {
    return el.getAttribute(name) ?? "";
  }
  function clean(s) {
    return s.replace(/[\s ]+/g, " ").trim();
  }
  function oneLine(s, max = NAME_MAX) {
    const flat = clean(s);
    return flat.length > max ? flat.slice(0, max - 1) + "\u2026" : flat;
  }
  function quote(s) {
    return '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
  }
  function isElement(n) {
    return n.nodeType === ELEMENT;
  }
  function roleOf(el) {
    const tag2 = tagOf(el);
    if (SKIPPED_TAGS.has(tag2)) return "skip";
    const explicit = attr(el, "role").toLowerCase().split(/\s+/).find((r) => KNOWN_ROLES.has(r));
    if (explicit) {
      if (explicit === "none" || explicit === "presentation") return "";
      if (explicit === "image") return "img";
      return explicit;
    }
    switch (tag2) {
      case "a":
      case "area":
        return el.hasAttribute("href") ? "link" : "generic";
      case "button":
      case "summary":
        return "button";
      case "input": {
        const type = (attr(el, "type") || el.type || "text").toLowerCase();
        if (type === "hidden") return "skip";
        if (["button", "submit", "reset", "image", "color", "file"].includes(type)) return "button";
        if (type === "checkbox") return "checkbox";
        if (type === "radio") return "radio";
        if (type === "range") return "slider";
        if (type === "number") return "spinbutton";
        if (type === "search") return el.hasAttribute("list") ? "combobox" : "searchbox";
        return el.hasAttribute("list") ? "combobox" : "textbox";
      }
      case "textarea":
        return "textbox";
      case "select":
        return el.multiple || (el.size ?? 0) > 1 ? "listbox" : "combobox";
      case "option":
        return "option";
      case "optgroup":
        return "group";
      case "img":
        return el.getAttribute("alt") === "" ? "" : "img";
      case "svg":
        return "img";
      case "h1":
      case "h2":
      case "h3":
      case "h4":
      case "h5":
      case "h6":
        return "heading";
      case "ul":
      case "ol":
      case "menu":
        return "list";
      case "li":
        return "listitem";
      case "table":
        return "table";
      case "tr":
        return "row";
      case "td":
        return "cell";
      case "th":
        return attr(el, "scope") === "row" ? "rowheader" : "columnheader";
      case "thead":
      case "tbody":
      case "tfoot":
        return "rowgroup";
      case "caption":
        return "caption";
      case "nav":
        return "navigation";
      case "main":
        return "main";
      case "header":
        return "banner";
      case "footer":
        return "contentinfo";
      case "aside":
        return "complementary";
      case "form":
        return "form";
      case "section":
        return "region";
      case "article":
        return "article";
      case "dialog":
        return "dialog";
      case "fieldset":
      case "details":
      case "address":
        return "group";
      case "legend":
        return "legend";
      case "label":
        return "label";
      case "p":
        return "paragraph";
      case "blockquote":
        return "blockquote";
      case "figure":
        return "figure";
      case "iframe":
      case "frame":
        return "iframe";
      case "progress":
        return "progressbar";
      case "meter":
        return "meter";
      case "output":
        return "status";
      case "search":
        return "search";
      default:
        return "generic";
    }
  }
  function describe(el, env2) {
    let role = roleOf(el);
    if (isEditingHost(el) && (role === "generic" || role === "" || role === "paragraph")) role = "textbox";
    if ((role === "generic" || role === "" || role === "listitem" || role === "row" || role === "img" || role === "cell" || role === "paragraph" || role === "label") && clickable(el, env2)) {
      role = "button";
    }
    return { role, name: nameOf(el, role, env2) };
  }
  function isEditingHost(el) {
    const v = el.getAttribute("contenteditable");
    return v !== null && v.toLowerCase() !== "false";
  }
  function clickable(el, env2) {
    if (el.hasAttribute("onclick")) return true;
    const tabindex = el.getAttribute("tabindex");
    if (tabindex !== null && tabindex !== "" && Number(tabindex) >= 0 && tagOf(el) !== "body") return true;
    return env2.isClickable ? env2.isClickable(el) : false;
  }
  function nameOf(el, role, env2) {
    const labelledBy = attr(el, "aria-labelledby").trim();
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id) => env2.byId(id, el)).filter((n) => !!n).map((n) => textOf(n, env2, el)).join(" ");
      if (clean(text)) return oneLine(text);
    }
    const ariaLabel = attr(el, "aria-label");
    if (clean(ariaLabel)) return oneLine(ariaLabel);
    const tag2 = tagOf(el);
    if (tag2 === "input" || tag2 === "textarea" || tag2 === "select") {
      const type = (attr(el, "type") || el.type || "").toLowerCase();
      if (tag2 === "input" && ["button", "submit", "reset"].includes(type)) {
        const v = el.value ?? attr(el, "value");
        if (clean(v)) return oneLine(v);
        return type === "submit" ? "Submit" : type === "reset" ? "Reset" : "";
      }
      if (tag2 === "input" && type === "image") {
        return oneLine(attr(el, "alt") || attr(el, "value") || "Submit");
      }
      const fromLabels = labelText(el, env2);
      if (fromLabels) return fromLabels;
      const title2 = attr(el, "title");
      if (clean(title2)) return oneLine(title2);
      const placeholder = attr(el, "placeholder") || attr(el, "aria-placeholder");
      return oneLine(placeholder);
    }
    if (tag2 === "img" || tag2 === "area") {
      const alt = attr(el, "alt");
      if (clean(alt)) return oneLine(alt);
    }
    if (tag2 === "svg") {
      const title2 = Array.from(el.childNodes).find((c) => isElement(c) && tagOf(c) === "title");
      if (title2) return oneLine(textOf(title2, env2));
    }
    if (tag2 === "fieldset" || tag2 === "table" || tag2 === "figure") {
      const want = tag2 === "fieldset" ? "legend" : tag2 === "table" ? "caption" : "figcaption";
      const child = Array.from(el.childNodes).find((c) => isElement(c) && tagOf(c) === want);
      if (child) {
        const t = textOf(child, env2);
        if (clean(t)) return oneLine(t);
      }
    }
    if (tag2 === "iframe" || tag2 === "frame") {
      const title2 = attr(el, "title");
      if (clean(title2)) return oneLine(title2);
    }
    if (isEditingHost(el) && role === "textbox") {
      const fromLabels = labelText(el, env2);
      if (fromLabels) return fromLabels;
    }
    if (NAME_FROM_CONTENT.has(role) || role === "button" && tag2 !== "input") {
      const text = textOf(el, env2);
      if (clean(text)) return oneLine(text);
    }
    const title = attr(el, "title");
    return clean(title) ? oneLine(title) : "";
  }
  function labelText(el, env2) {
    const labels = el.labels ? Array.from(el.labels) : [];
    const text = labels.map((l) => textOf(l, env2, el)).join(" ");
    return clean(text) ? oneLine(text) : "";
  }
  function textOf(node, env2, skip, ownLabel = true) {
    const parts = [];
    let length = 0;
    const walk = (n) => {
      if (length > 2e3) return;
      if (n.nodeType === TEXT) {
        const t = n.nodeValue ?? "";
        parts.push(t);
        length += t.length;
        return;
      }
      if (!isElement(n)) {
        for (const c of Array.from(n.childNodes)) walk(c);
        return;
      }
      if (n === skip) return;
      const tag2 = tagOf(n);
      if (SKIPPED_TAGS.has(tag2) || env2.isHidden(n)) return;
      if (tag2 === "br") {
        parts.push(" ");
        return;
      }
      if (tag2 === "input" || tag2 === "textarea" || tag2 === "select") return;
      const label2 = attr(n, "aria-label");
      if (clean(label2) && (n !== node || ownLabel)) {
        parts.push(" " + label2 + " ");
        length += label2.length;
        return;
      }
      if (tag2 === "img") {
        parts.push(" " + attr(n, "alt") + " ");
        return;
      }
      if (tag2 === "svg") return;
      const block = !INLINE_TAGS.has(tag2);
      if (block) parts.push(" ");
      for (const c of childrenOf(n, env2)) walk(c);
      if (block) parts.push(" ");
    };
    walk(node);
    return clean(parts.join(""));
  }
  function childrenOf(el, env2) {
    const shadow = env2.shadowRoot ? env2.shadowRoot(el) : el.shadowRoot ?? null;
    if (shadow) return Array.from(shadow.childNodes);
    if (tagOf(el) === "slot" && env2.assigned) {
      const assigned = env2.assigned(el);
      if (assigned && assigned.length) return assigned;
    }
    return Array.from(el.childNodes);
  }
  function valueOf(el, role, env2) {
    if (isSecureField(el)) return "";
    const tag2 = tagOf(el);
    if (tag2 === "select") {
      const options = el.options ? Array.from(el.options) : [];
      const chosen = options.filter((o) => o.selected).map((o) => textOf(o, env2));
      return oneLine(chosen.join(", "));
    }
    if (tag2 === "input" || tag2 === "textarea") return oneLine(el.value ?? "");
    if (role === "slider" || role === "spinbutton") {
      return oneLine(attr(el, "aria-valuetext") || attr(el, "aria-valuenow"));
    }
    if (isEditingHost(el)) return oneLine(textOf(el, env2, void 0, false));
    return "";
  }
  function isChecked(el, role) {
    if (!TOGGLES.has(role)) return false;
    if (el.checked === true) return true;
    return attr(el, "aria-checked") === "true";
  }
  function isDisabled(el) {
    return el.disabled === true || attr(el, "aria-disabled") === "true";
  }
  function isSelected(el, role) {
    if (role === "option" && el.selected === true) return true;
    return attr(el, "aria-selected") === "true";
  }
  function isInlineText(el, env2) {
    const tag2 = tagOf(el);
    if (!INLINE_TAGS.has(tag2)) return false;
    if (tag2 === "a" && el.hasAttribute("href")) return false;
    if (el.hasAttribute("role") || clean(attr(el, "aria-label")) || clickable(el, env2)) return false;
    for (const c of Array.from(el.childNodes)) {
      if (c.nodeType === TEXT) continue;
      if (!isElement(c)) continue;
      if (!isInlineText(c, env2)) return false;
    }
    return true;
  }
  function buildOutline(root, env2, opts) {
    const lines = [];
    const refs = /* @__PURE__ */ new Map();
    let chars = 0;
    let printed = 0;
    let truncated = false;
    const emit = (depth, text) => {
      if (truncated) return false;
      if (printed >= opts.maxNodes) {
        truncated = true;
        return false;
      }
      const line = "  ".repeat(depth) + "- " + text;
      if (chars + line.length + 1 > opts.maxChars) {
        truncated = true;
        return false;
      }
      lines.push(line);
      chars += line.length + 1;
      printed += 1;
      return true;
    };
    const visitChildren = (kids, depth, named, parentRole) => {
      let run = [];
      const flush = () => {
        if (!run.length) return;
        const text = oneLine(run.join(""));
        run = [];
        if (text && !named) emit(depth, `text ${quote(text)}`);
      };
      for (const kid of kids) {
        if (truncated) return;
        if (kid.nodeType === TEXT) {
          run.push(kid.nodeValue ?? "");
          continue;
        }
        if (!isElement(kid)) {
          flush();
          visitChildren(Array.from(kid.childNodes), depth, named, parentRole);
          continue;
        }
        if (env2.isHidden(kid) || SKIPPED_TAGS.has(tagOf(kid))) continue;
        if (tagOf(kid) === "br") {
          run.push(" ");
          continue;
        }
        if (isInlineText(kid, env2)) {
          run.push(textOf(kid, env2));
          continue;
        }
        flush();
        visit(kid, depth, named, parentRole);
      }
      flush();
    };
    const visit = (el, depth, insideNamed, parentRole) => {
      if (truncated) return;
      let { role, name } = describe(el, env2);
      if (role === "skip") return;
      const tag2 = tagOf(el);
      if (insideNamed && role === "img") return;
      if (role === "img" && !name && tag2 === "svg") return;
      if (tag2 === "legend" || tag2 === "caption" || tag2 === "figcaption") return;
      if (role === "label") {
        visitChildren(childrenOf(el, env2), depth, true, parentRole);
        return;
      }
      const quiet = role === "" || QUIET_WHEN_UNNAMED.has(role) && !name;
      let next = depth;
      if (!quiet) {
        const secure = isSecureField(el);
        let line = role;
        if (name) line += " " + quote(name);
        const flags = [];
        if (secure) flags.push("secure");
        if (role === "heading") {
          const level = attr(el, "aria-level") || (/^h[1-6]$/.test(tag2) ? tag2.slice(1) : "");
          if (level) flags.push(`level=${level}`);
        }
        if (isDisabled(el)) flags.push("disabled");
        if (isChecked(el, role)) flags.push("checked");
        if (attr(el, "aria-pressed") === "true") flags.push("pressed");
        if (isSelected(el, role)) flags.push("selected");
        if (attr(el, "aria-expanded") === "true") flags.push("expanded");
        if (env2.focused === el) flags.push("focused");
        const ref = ACTIONABLE.has(role) ? `e${refs.size + 1}` : null;
        if (ref) flags.push(`ref=${ref}`);
        if (flags.length) line += " " + flags.map((f) => `[${f}]`).join(" ");
        if (SHOWS_VALUE.has(role) && !secure) {
          const value = valueOf(el, role, env2);
          if (value) line += ": " + value;
        }
        if (!emit(depth, line)) return;
        if (ref) refs.set(ref, { el, role, name });
        next = depth + 1;
        if (secure) return;
      }
      if (tag2 === "select") {
        const options = el.options ? Array.from(el.options) : [];
        const shown = options.slice(0, OPTIONS_SHOWN);
        for (const o of shown) {
          const text = oneLine(textOf(o, env2));
          if (!text) continue;
          emit(next, `option ${quote(text)}${o.selected ? " [selected]" : ""}`);
        }
        if (options.length > shown.length) emit(next, `text ${quote(`and ${options.length - shown.length} more options`)}`);
        return;
      }
      if (tag2 === "textarea" || tag2 === "input") return;
      if (role === "textbox" && isEditingHost(el)) return;
      if (role === "iframe") {
        const doc = env2.frameDocument ? env2.frameDocument(el) : null;
        if (doc) visitChildren(Array.from(doc.childNodes), next, false, role);
        return;
      }
      const named = !quiet && !!name && (NAME_FROM_CONTENT.has(role) || role === "button");
      visitChildren(childrenOf(el, env2), next, insideNamed || named, quiet ? parentRole : role);
    };
    const title = oneLine(opts.title ?? "");
    emit(0, title ? `document ${quote(title)}` : "document");
    const start = isElement(root) && tagOf(root) === "html" ? Array.from(root.childNodes).filter((n) => !(isElement(n) && tagOf(n) === "head")) : Array.from(root.childNodes);
    visitChildren(start, 1, false, "document");
    return { text: lines.join("\n"), refs, truncated, nodes: printed };
  }
  function sameAs(entry, env2) {
    const now = describe(entry.el, env2);
    return now.role === entry.role && now.name === entry.name;
  }

  // src/lib/act.ts
  var ACTIONS = [
    "click",
    "double_click",
    "right_click",
    "focus",
    "type",
    "set_value",
    "select",
    "key",
    "hover",
    "scroll"
  ];
  var TEXT_INPUT_TYPES = /* @__PURE__ */ new Set([
    "",
    "text",
    "search",
    "email",
    "url",
    "tel",
    "number",
    "password",
    "date",
    "datetime-local",
    "month",
    "week",
    "time"
  ]);
  function tag(el) {
    return el.tagName.toLowerCase();
  }
  function isTextField(el) {
    const t = tag(el);
    if (t === "textarea") return true;
    if (t !== "input") return false;
    return TEXT_INPUT_TYPES.has((el.type || el.getAttribute("type") || "").toLowerCase());
  }
  function label(el, env2) {
    const { role, name } = env2.describe(el);
    return name ? `${role} "${name}"` : `the ${role || "element"}`;
  }
  function centre(el) {
    try {
      el.scrollIntoView?.({ block: "center", inline: "center", behavior: "instant" });
    } catch {
      el.scrollIntoView?.();
    }
    const r = el.getBoundingClientRect?.() ?? { left: 0, top: 0, width: 0, height: 0 };
    return { clientX: Math.round(r.left + r.width / 2), clientY: Math.round(r.top + r.height / 2) };
  }
  function fire(el, env2, kind, type, init = {}) {
    const ev = env2.makeEvent(kind, type, { bubbles: true, cancelable: true, composed: true, ...init });
    el.dispatchEvent(ev);
    return ev;
  }
  function press(el, env2, button = 0, count = 1) {
    const at = centre(el);
    const common = { ...at, button };
    fire(el, env2, "pointer", "pointerover", { ...at, pointerType: "mouse", isPrimary: true });
    fire(el, env2, "mouse", "mouseover", at);
    fire(el, env2, "pointer", "pointermove", { ...at, pointerType: "mouse", isPrimary: true });
    fire(el, env2, "mouse", "mousemove", at);
    for (let i = 1; i <= count; i++) {
      fire(el, env2, "pointer", "pointerdown", { ...common, buttons: button === 2 ? 2 : 1, pointerType: "mouse", isPrimary: true, detail: i });
      const down = fire(el, env2, "mouse", "mousedown", { ...common, buttons: button === 2 ? 2 : 1, detail: i });
      if (!down.defaultPrevented && i === 1) el.focus?.({ preventScroll: true });
      fire(el, env2, "pointer", "pointerup", { ...common, buttons: 0, pointerType: "mouse", isPrimary: true, detail: i });
      fire(el, env2, "mouse", "mouseup", { ...common, buttons: 0, detail: i });
      if (button === 0) fire(el, env2, "mouse", "click", { ...common, buttons: 0, detail: i });
    }
    if (button === 0 && count === 2) fire(el, env2, "mouse", "dblclick", { ...common, buttons: 0, detail: 2 });
    if (button === 2) fire(el, env2, "mouse", "contextmenu", { ...common, buttons: 0 });
  }
  async function settle(env2, watch) {
    await env2.sleep(env2.settleMs ?? 350);
    const changed = watch.changed();
    watch.stop();
    return changed;
  }
  var NAMED_KEYS = {
    enter: { key: "Enter", code: "Enter", keyCode: 13 },
    return: { key: "Enter", code: "Enter", keyCode: 13 },
    tab: { key: "Tab", code: "Tab", keyCode: 9 },
    escape: { key: "Escape", code: "Escape", keyCode: 27 },
    esc: { key: "Escape", code: "Escape", keyCode: 27 },
    backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
    delete: { key: "Delete", code: "Delete", keyCode: 46 },
    forwarddelete: { key: "Delete", code: "Delete", keyCode: 46 },
    space: { key: " ", code: "Space", keyCode: 32 },
    arrowup: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
    up: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
    arrowdown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
    down: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
    arrowleft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
    left: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
    arrowright: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
    right: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
    home: { key: "Home", code: "Home", keyCode: 36 },
    end: { key: "End", code: "End", keyCode: 35 },
    pageup: { key: "PageUp", code: "PageUp", keyCode: 33 },
    pagedown: { key: "PageDown", code: "PageDown", keyCode: 34 }
  };
  function parseKey(spec) {
    const parts = (spec.trim() === "+" ? ["+"] : spec.endsWith("++") ? [...spec.slice(0, -2).split("+"), "+"] : spec.split("+")).map((p) => p === " " ? p : p.trim()).filter((p) => p !== "");
    const out = { key: "", code: "", keyCode: 0, metaKey: false, ctrlKey: false, altKey: false, shiftKey: false };
    for (const raw of parts) {
      const p = raw.toLowerCase();
      if (["cmd", "command", "meta", "\u2318", "super", "controlormeta"].includes(p)) out.metaKey = true;
      else if (["ctrl", "control", "\u2303"].includes(p)) out.ctrlKey = true;
      else if (["alt", "option", "opt", "\u2325"].includes(p)) out.altKey = true;
      else if (["shift", "\u21E7"].includes(p)) out.shiftKey = true;
      else if (NAMED_KEYS[p]) Object.assign(out, NAMED_KEYS[p]);
      else if (/^f([1-9]|1[0-2])$/.test(p)) Object.assign(out, { key: raw.toUpperCase(), code: raw.toUpperCase(), keyCode: 111 + Number(p.slice(1)) });
      else if ([...raw].length === 1) {
        const ch = raw;
        const upper = ch.toUpperCase();
        const isLetter = /^[a-z]$/i.test(ch);
        const isDigit = /^[0-9]$/.test(ch);
        out.key = out.shiftKey && isLetter ? upper : ch;
        out.code = isLetter ? `Key${upper}` : isDigit ? `Digit${ch}` : "";
        out.keyCode = isLetter ? upper.charCodeAt(0) : isDigit ? ch.charCodeAt(0) : 0;
      } else {
        throw new BridgeError("invalid", `PAL doesn't know the key "${raw}".`);
      }
    }
    if (!out.key) throw new BridgeError("invalid", `"${spec}" names no key to press.`);
    return out;
  }
  function typedBy(k) {
    if (k.metaKey || k.ctrlKey) return "";
    if ([...k.key].length === 1) return k.key;
    return "";
  }
  function insertIntoField(el, env2, text) {
    const value = el.value ?? "";
    const start = el.selectionStart ?? value.length;
    const end = el.selectionEnd ?? start;
    const next = value.slice(0, start) + text + value.slice(end);
    env2.setValue(el, next);
    const caret = start + text.length;
    try {
      el.selectionStart = caret;
      el.selectionEnd = caret;
    } catch {
    }
  }
  function deleteInField(el, env2, forward) {
    const value = el.value ?? "";
    let start = el.selectionStart ?? value.length;
    let end = el.selectionEnd ?? start;
    if (start === end) {
      if (forward) end = Math.min(value.length, end + 1);
      else start = Math.max(0, start - 1);
    }
    if (start === end) return false;
    env2.setValue(el, value.slice(0, start) + value.slice(end));
    try {
      el.selectionStart = start;
      el.selectionEnd = start;
    } catch {
    }
    return true;
  }
  function typeChar(el, env2, ch) {
    const k = ch === "\n" ? { ...NAMED_KEYS.enter } : parseKeyChar(ch);
    const down = fire(el, env2, "keyboard", "keydown", { ...k });
    if (down.defaultPrevented) {
      fire(el, env2, "keyboard", "keyup", { ...k });
      return;
    }
    fire(el, env2, "keyboard", "keypress", { ...k, charCode: ch.charCodeAt(0) });
    if (env2.isEditor(el)) {
      env2.insertText(el, ch);
    } else if (ch === "\n" && tag(el) !== "textarea") {
    } else {
      const inputType = ch === "\n" ? "insertLineBreak" : "insertText";
      const before = fire(el, env2, "input", "beforeinput", { inputType, data: ch === "\n" ? null : ch });
      if (!before.defaultPrevented) {
        insertIntoField(el, env2, ch);
        fire(el, env2, "input", "input", { inputType, data: ch === "\n" ? null : ch, cancelable: false });
      }
    }
    fire(el, env2, "keyboard", "keyup", { ...k });
  }
  function parseKeyChar(ch) {
    const isLetter = /^[a-z]$/i.test(ch);
    const isDigit = /^[0-9]$/.test(ch);
    return {
      key: ch,
      code: ch === " " ? "Space" : isLetter ? `Key${ch.toUpperCase()}` : isDigit ? `Digit${ch}` : "",
      keyCode: isLetter ? ch.toUpperCase().charCodeAt(0) : isDigit || ch === " " ? ch.charCodeAt(0) : 0,
      shiftKey: isLetter && ch !== ch.toLowerCase()
    };
  }
  function editable(el, env2) {
    return isTextField(el) || env2.isEditor(el);
  }
  function readBack(el, env2) {
    if (env2.isEditor(el)) return env2.describe(el).name;
    return el.value ?? "";
  }
  async function perform(el, args, env2) {
    const action = args.action;
    if (!ACTIONS.includes(action)) throw new BridgeError("invalid", `PAL can't ${args.action} on a page.`);
    const targetless = action === "type" || action === "key" || action === "scroll";
    if (!el && !targetless) throw new BridgeError("invalid", `${action} needs a ref from the last page.snapshot.`);
    const target = el ?? (action === "scroll" ? null : env2.activeElement());
    if (action !== "scroll") {
      if (!target) throw new BridgeError("not_found", "Nothing on the page has focus to type into.");
      checkField(target);
    }
    const what = target ? label(target, env2) : "the page";
    const greyed = () => {
      if (target && (target.disabled === true || target.getAttribute("aria-disabled") === "true")) {
        throw new BridgeError("unsupported", `${what} is greyed out right now.`);
      }
    };
    switch (action) {
      case "click":
      case "double_click":
      case "right_click": {
        greyed();
        const t = target;
        const before = { checked: t.checked, value: t.value };
        const watch = env2.watch();
        press(t, env2, action === "right_click" ? 2 : 0, action === "double_click" ? 2 : 1);
        const changed = await settle(env2, watch);
        const toggled = before.checked !== void 0 && before.checked !== t.checked;
        const verb = action === "click" ? "Clicked" : action === "double_click" ? "Double-clicked" : "Right-clicked";
        return {
          effect: changed || toggled ? "confirmed" : "unverifiable",
          detail: `${verb} ${what}${toggled ? t.checked ? " (now on)" : " (now off)" : ""}.`
        };
      }
      case "hover": {
        const t = target;
        const at = centre(t);
        const watch = env2.watch();
        fire(t, env2, "pointer", "pointerover", { ...at, pointerType: "mouse", isPrimary: true });
        fire(t, env2, "pointer", "pointerenter", { ...at, pointerType: "mouse", isPrimary: true, bubbles: false });
        fire(t, env2, "mouse", "mouseover", at);
        fire(t, env2, "mouse", "mouseenter", { ...at, bubbles: false });
        fire(t, env2, "pointer", "pointermove", { ...at, pointerType: "mouse", isPrimary: true });
        fire(t, env2, "mouse", "mousemove", at);
        const changed = await settle(env2, watch);
        return { effect: changed ? "confirmed" : "unverifiable", detail: `Pointed at ${what}.` };
      }
      case "focus": {
        const t = target;
        t.focus?.({ preventScroll: false });
        const ok = env2.activeElement() === t;
        return { effect: ok ? "confirmed" : "suspected_noop", detail: ok ? `Put the focus in ${what}.` : `${what} didn't take the focus.` };
      }
      case "type": {
        greyed();
        const t = target;
        const text = args.text ?? "";
        if (!text) throw new BridgeError("invalid", "type needs text.");
        if (!editable(t, env2)) throw new BridgeError("unsupported", `${what} doesn't take typing.`);
        if (env2.activeElement() !== t) {
          t.focus?.({ preventScroll: false });
          if (!env2.isEditor(t) && t.value !== void 0) {
            try {
              t.selectionStart = t.value.length;
              t.selectionEnd = t.value.length;
            } catch {
            }
          }
        }
        const before = readBack(t, env2);
        for (const ch of text) typeChar(t, env2, ch);
        if (!env2.isEditor(t)) fire(t, env2, "event", "change", { cancelable: false });
        const after = readBack(t, env2);
        const took = after !== before && (env2.isEditor(t) || after.includes(text.replace(/\n/g, tag(t) === "textarea" ? "\n" : "")));
        return {
          effect: took ? "confirmed" : after !== before ? "unverifiable" : "suspected_noop",
          detail: took ? `Typed into ${what}.` : `Typed into ${what}, but its text didn't change as expected.`
        };
      }
      case "set_value": {
        greyed();
        const t = target;
        const text = args.text ?? "";
        if (tag(t) === "select") return chooseNative(t, text, env2, what);
        if (env2.isEditor(t)) {
          t.focus?.({ preventScroll: false });
          env2.selectAll(t);
          env2.insertText(t, text);
          const now = readBack(t, env2);
          return { effect: now.includes(text.trim().slice(0, 40)) ? "confirmed" : "unverifiable", detail: `Set ${what}.` };
        }
        if (t.value === void 0) throw new BridgeError("unsupported", `${what} has no value to set.`);
        const type = (t.type || "").toLowerCase();
        if (type === "checkbox" || type === "radio") {
          const want = /^(1|true|on|yes|checked)$/i.test(text.trim());
          if (t.checked !== want) press(t, env2);
          return { effect: t.checked === want ? "confirmed" : "suspected_noop", detail: `${want ? "Ticked" : "Unticked"} ${what}.` };
        }
        t.focus?.({ preventScroll: false });
        fire(t, env2, "input", "beforeinput", { inputType: "insertReplacementText", data: text });
        env2.setValue(t, text);
        fire(t, env2, "input", "input", { inputType: "insertReplacementText", data: text, cancelable: false });
        fire(t, env2, "event", "change", { cancelable: false });
        const ok = t.value === text;
        return { effect: ok ? "confirmed" : "suspected_noop", detail: ok ? `Set ${what} to the text.` : `${what} didn't keep the text.` };
      }
      case "select": {
        greyed();
        const t = target;
        const option = (args.option ?? "").trim();
        if (!option) throw new BridgeError("invalid", "select needs an option.");
        if (tag(t) === "select") return chooseNative(t, option, env2, what);
        return chooseCustom(t, option, env2, what);
      }
      case "key": {
        const t = target;
        const k = parseKey(args.key ?? "");
        const down = fire(t, env2, "keyboard", "keydown", { ...k });
        let detail = `Pressed ${args.key} in ${what}.`;
        let effect = "unverifiable";
        const typed = typedBy(k);
        if (!down.defaultPrevented) {
          if (typed) {
            fire(t, env2, "keyboard", "keypress", { ...k, charCode: typed.charCodeAt(0) });
            if (editable(t, env2)) {
              if (env2.isEditor(t)) env2.insertText(t, typed);
              else {
                insertIntoField(t, env2, typed);
                fire(t, env2, "input", "input", { inputType: "insertText", data: typed, cancelable: false });
              }
              effect = "confirmed";
            }
          } else if (k.key === "Enter") {
            fire(t, env2, "keyboard", "keypress", { ...k, charCode: 13 });
            if (tag(t) === "textarea" || env2.isEditor(t)) {
              if (env2.isEditor(t)) env2.insertText(t, "\n");
              else {
                insertIntoField(t, env2, "\n");
                fire(t, env2, "input", "input", { inputType: "insertLineBreak", data: null, cancelable: false });
              }
              effect = "confirmed";
            }
          } else if (k.key === "Tab") {
            const next = env2.focusable(t, k.shiftKey);
            if (next) {
              next.focus?.({ preventScroll: false });
              effect = env2.activeElement() === next ? "confirmed" : "unverifiable";
              detail = `Pressed ${args.key}: the focus is on ${label(next, env2)}.`;
            }
          } else if ((k.key === "Backspace" || k.key === "Delete") && isTextField(t)) {
            if (deleteInField(t, env2, k.key === "Delete")) {
              fire(t, env2, "input", "input", {
                inputType: k.key === "Delete" ? "deleteContentForward" : "deleteContentBackward",
                data: null,
                cancelable: false
              });
              effect = "confirmed";
            } else effect = "suspected_noop";
          } else if ((k.metaKey || k.ctrlKey) && k.key.toLowerCase() === "a" && editable(t, env2)) {
            env2.selectAll(t);
            effect = "confirmed";
          }
        }
        fire(t, env2, "keyboard", "keyup", { ...k });
        return { effect, detail };
      }
      case "scroll": {
        const direction = (args.direction || "down").toLowerCase();
        const amount = Math.min(20, Math.max(1, Number(args.amount ?? 3) || 3));
        const step = 120 * amount;
        const [dx, dy] = direction === "up" ? [0, -step] : direction === "left" ? [-step, 0] : direction === "right" ? [step, 0] : [0, step];
        const before = env2.scrollPosition(target);
        env2.scrollBy(target, dx, dy);
        await env2.sleep(80);
        const after = env2.scrollPosition(target);
        const moved = before.x !== after.x || before.y !== after.y;
        return {
          effect: moved ? "confirmed" : "suspected_noop",
          detail: moved ? `Scrolled ${what} ${direction}.` : `${what} didn't scroll ${direction} (already at the end?).`
        };
      }
    }
  }
  function pickOption(options, want, textOf2, valueOf2 = () => "") {
    const norm = (s) => s.replace(/\s+/g, " ").trim().toLowerCase();
    const w = norm(want);
    const exact = options.find((o) => norm(textOf2(o)) === w);
    if (exact) return exact;
    const byValue = options.find((o) => norm(valueOf2(o)) === w);
    if (byValue) return byValue;
    const starts = options.filter((o) => norm(textOf2(o)).startsWith(w));
    if (starts.length === 1) return starts[0];
    const contains = options.filter((o) => norm(textOf2(o)).includes(w));
    if (contains.length === 1) return contains[0];
    const pool = (starts.length ? starts : contains.length ? contains : options).map(textOf2).slice(0, 20);
    if (starts.length > 1 || contains.length > 1) {
      throw new BridgeError("not_found", `More than one option matches "${want}": ${pool.join("; ")}.`);
    }
    throw new BridgeError("not_found", `There is no option "${want}". The options are: ${pool.join("; ")}.`);
  }
  function chooseNative(el, want, env2, what) {
    const options = el.options ? Array.from(el.options).filter((o) => !o.disabled) : [];
    const option = pickOption(options, want, (o) => o.text, (o) => o.value);
    el.focus?.({ preventScroll: false });
    env2.setValue(el, option.value);
    option.selected = true;
    fire(el, env2, "input", "input", { cancelable: false });
    fire(el, env2, "event", "change", { cancelable: false });
    const ok = option.selected && el.value === option.value;
    return { effect: ok ? "confirmed" : "suspected_noop", detail: `Chose "${option.text.trim()}" in ${what}.` };
  }
  async function chooseCustom(el, want, env2, what) {
    let options = env2.optionsFor(el);
    if (!options.length) {
      press(el, env2);
      await env2.sleep(env2.settleMs ?? 350);
      options = env2.optionsFor(el);
    }
    if (!options.length) throw new BridgeError("not_found", `${what} shows no options to choose from.`);
    const option = pickOption(options, want, (o) => o.name);
    const watch = env2.watch();
    press(option.el, env2);
    const changed = await settle(env2, watch);
    return { effect: changed ? "confirmed" : "unverifiable", detail: `Chose "${option.name}" in ${what}.` };
  }

  // src/content/page-agent.ts
  function shadowOf(el) {
    const api = globalThis.chrome?.dom;
    try {
      if (api?.openOrClosedShadowRoot) return api.openOrClosedShadowRoot(el);
    } catch {
    }
    return el.shadowRoot;
  }
  function deepActive() {
    let el = document.activeElement;
    for (let i = 0; i < 20 && el; i++) {
      const inner = shadowOf(el)?.activeElement ?? null;
      if (!inner) break;
      el = inner;
    }
    if (el && el.tagName === "IFRAME") {
      try {
        const doc = el.contentDocument;
        if (doc?.activeElement && doc.activeElement !== doc.body) return doc.activeElement;
      } catch {
      }
    }
    return el === document.body ? null : el;
  }
  function isHidden(el) {
    if (el.hasAttribute("hidden") || el.getAttribute("aria-hidden") === "true" || el.hasAttribute("inert")) return true;
    const view = el.ownerDocument?.defaultView ?? window;
    let style;
    try {
      style = view.getComputedStyle(el);
    } catch {
      return false;
    }
    if (style.display === "none") return true;
    if (style.visibility === "hidden" || style.visibility === "collapse") return true;
    if (style.contentVisibility === "hidden") return true;
    return false;
  }
  function isClickable(el) {
    const view = el.ownerDocument?.defaultView ?? window;
    try {
      if (view.getComputedStyle(el).cursor !== "pointer") return false;
      const parent = el.parentElement;
      return !parent || view.getComputedStyle(parent).cursor !== "pointer";
    } catch {
      return false;
    }
  }
  function byId(id, near) {
    const root = near.getRootNode();
    return (root.getElementById ? root.getElementById(id) : null) ?? near.ownerDocument?.getElementById(id) ?? null;
  }
  function env() {
    return {
      isHidden: (el) => isHidden(el),
      byId: (id, near) => byId(id, near),
      focused: deepActive(),
      shadowRoot: (el) => shadowOf(el),
      frameDocument: (el) => {
        try {
          return el.contentDocument;
        } catch {
          return null;
        }
      },
      assigned: (slot) => {
        const s = slot;
        return typeof s.assignedNodes === "function" ? s.assignedNodes({ flatten: true }) : null;
      },
      isClickable: (el) => isClickable(el)
    };
  }
  var EVENT_TYPES = {
    pointer: "PointerEvent",
    mouse: "MouseEvent",
    keyboard: "KeyboardEvent",
    input: "InputEvent",
    focus: "FocusEvent",
    event: "Event"
  };
  function makeEvent(kind, type, init) {
    const ctor = window[EVENT_TYPES[kind]];
    const full = kind === "event" ? init : { view: window, ...init };
    if (ctor) return new ctor(type, full);
    const Mouse = window.MouseEvent;
    return kind === "pointer" ? new Mouse(type, full) : new Event(type, full);
  }
  function nativeSetter(el) {
    for (let p = Object.getPrototypeOf(el); p; p = Object.getPrototypeOf(p)) {
      const desc = Object.getOwnPropertyDescriptor(p, "value");
      if (desc?.set) return (v) => desc.set.call(el, v);
    }
    return null;
  }
  var FOCUSABLE = "a[href], button, input:not([type=hidden]), select, textarea, [tabindex], [contenteditable]:not([contenteditable=false]), summary, iframe";
  function actEnv() {
    return {
      makeEvent: (kind, type, init) => makeEvent(kind, type, init),
      sleep: (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
      watch: () => {
        let changed = false;
        const href = location.href;
        const observer = new MutationObserver(() => {
          changed = true;
        });
        observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
        return {
          changed: () => changed || location.href !== href,
          stop: () => observer.disconnect()
        };
      },
      activeElement: () => deepActive(),
      focusable: (from, backwards) => {
        const all = Array.from(document.querySelectorAll(FOCUSABLE)).filter((e) => !isHidden(e) && e.tabIndex >= 0 && !e.disabled);
        const at = from ? all.indexOf(from) : -1;
        const i = backwards ? at <= 0 ? all.length - 1 : at - 1 : at + 1;
        return all[i] ?? null;
      },
      setValue: (el, value) => {
        const set = nativeSetter(el);
        if (set) set(value);
        else el.value = value;
      },
      insertText: (el, text) => {
        el.focus({ preventScroll: true });
        return document.execCommand("insertText", false, text);
      },
      selectAll: (el) => {
        const e = el;
        if (e.tagName === "INPUT" || e.tagName === "TEXTAREA") {
          e.select();
          return;
        }
        e.focus({ preventScroll: true });
        const range = document.createRange();
        range.selectNodeContents(e);
        const sel = window.getSelection();
        sel?.removeAllRanges();
        sel?.addRange(range);
      },
      isEditor: (el) => isEditingHost(el),
      optionsFor: (el) => {
        const e = el;
        const outline = env();
        const ids = `${e.getAttribute("aria-controls") ?? ""} ${e.getAttribute("aria-owns") ?? ""}`.trim().split(/\s+/).filter(Boolean);
        const roots = ids.map((id) => byId(id, e)).filter((x) => !!x);
        if (e.getAttribute("role") === "listbox") roots.push(e);
        const pool = roots.length ? roots.flatMap((r) => Array.from(r.querySelectorAll("[role=option]"))) : Array.from(document.querySelectorAll("[role=option]"));
        return pool.filter((o) => !isHidden(o)).map((o) => ({ el: o, name: textOf(o, outline) })).filter((o) => o.name);
      },
      scrollPosition: (el) => {
        const s = scroller(el);
        return s ? { x: s.scrollLeft, y: s.scrollTop } : { x: window.scrollX, y: window.scrollY };
      },
      scrollBy: (el, dx, dy) => {
        const s = scroller(el);
        if (s) s.scrollBy({ left: dx, top: dy, behavior: "instant" });
        else window.scrollBy({ left: dx, top: dy, behavior: "instant" });
      },
      describe: (el) => describe(el, env())
    };
  }
  function scroller(el) {
    for (let e = el; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
      const style = getComputedStyle(e);
      const scrolls = /(auto|scroll|overlay)/.test(style.overflowY + style.overflowX);
      if (scrolls && (e.scrollHeight > e.clientHeight || e.scrollWidth > e.clientWidth)) return e;
    }
    return null;
  }
  function createAgent() {
    let refs = /* @__PURE__ */ new Map();
    const pageId = Math.random().toString(36).slice(2, 10);
    return {
      pageId,
      snapshot(opts) {
        const outline = buildOutline(document, env(), { ...opts, title: document.title || location.hostname });
        refs = outline.refs;
        return {
          url: location.href,
          title: document.title,
          text: outline.text,
          refs: outline.refs.size,
          truncated: outline.truncated,
          pageId
        };
      },
      async act(args) {
        try {
          const ref = typeof args.ref === "string" && args.ref ? args.ref : null;
          let el = null;
          if (ref) {
            const entry = refs.get(ref);
            if (!entry) throw new BridgeError("not_found", `There is no ${ref} in the last snapshot of this page.`);
            const node = entry.el;
            if (!node.isConnected) {
              throw new BridgeError("changed", `The page changed since the snapshot (${ref} is gone). Take a new snapshot.`);
            }
            if (!sameAs(entry, env())) {
              throw new BridgeError(
                "changed",
                `The page changed since the snapshot (${ref} is no longer ${entry.role} "${entry.name}"). Take a new snapshot.`
              );
            }
            el = entry.el;
          }
          const result = await perform(el, {
            action: String(args.action ?? ""),
            text: typeof args.text === "string" ? args.text : void 0,
            option: typeof args.option === "string" ? args.option : void 0,
            key: typeof args.key === "string" ? args.key : void 0,
            direction: typeof args.direction === "string" ? args.direction : void 0,
            amount: typeof args.amount === "number" || typeof args.amount === "string" ? args.amount : void 0
          }, actEnv());
          return { effect: result.effect, detail: result.detail };
        } catch (err) {
          if (err instanceof BridgeError) {
            return { __error: { kind: err.kind, message: err.message, reason: err.reason } };
          }
          return { __error: { kind: "app_error", message: err instanceof Error ? err.message : String(err) } };
        }
      }
    };
  }
  if (!window.__palPage) window.__palPage = createAgent();
})();
